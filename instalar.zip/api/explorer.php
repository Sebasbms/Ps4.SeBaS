<?php
/**
 * ARCHIVO: api/explorer.php
 * Motor de Exploración FTP (Lógica rápida por extensiones)
 */
header('Content-Type: application/json');
set_time_limit(0);

// 1. DESCARGA DIRECTA (Streaming al celular)
if (isset($_GET['action']) && $_GET['action'] === 'download') {
    $host_ip = $_GET['host_ip'] ?? '';
    $path = $_GET['path'] ?? '';
    if ($host_ip && $path) {
        $conn = @ftp_connect($host_ip, 2121, 10);
        if ($conn) {
            @ftp_login($conn, "anonymous", "");
            ftp_pasv($conn, true);
            $filename = basename($path);
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            @ftp_get($conn, "php://output", $path, FTP_BINARY);
            @ftp_close($conn);
        }
    }
    exit;
}

$action = $_POST['action'] ?? '';
$host_ip = $_POST['host_ip'] ?? '';

if (!$host_ip) { echo json_encode(['status' => 'error', 'message' => 'Falta IP de PS4']); exit; }

$conn = @ftp_connect($host_ip, 2121, 10);
if (!$conn) { echo json_encode(['status' => 'error', 'message' => 'No conecta a FTP']); exit; }
@ftp_login($conn, "anonymous", ""); ftp_pasv($conn, true);

if ($action === 'list_dir') {
    $path = $_POST['path'] ?? '/';
    $folders_and_files = @ftp_nlist($conn, $path);
    $items = [];
    
    if (is_array($folders_and_files)) {
        foreach ($folders_and_files as $item) {
            $name = basename($item);
            if ($name === '.' || $name === '..') continue;
            
            // LA REGLA DEL USUARIO:
            // Si tiene extensión (.pkg, .bin, .elf, .ini) = Archivo
            // Si no tiene extensión = Carpeta
            $ext = pathinfo($name, PATHINFO_EXTENSION);
            $is_dir = ($ext === '');

            $items[] = ['name' => $name, 'is_dir' => $is_dir];
        }
    }
    
    // Ordenar: Primero carpetas, luego archivos (alfabéticamente)
    usort($items, function($a, $b) {
        if ($a['is_dir'] && !$b['is_dir']) return -1;
        if (!$a['is_dir'] && $b['is_dir']) return 1;
        return strcasecmp($a['name'], $b['name']);
    });
    
    echo json_encode(['status' => 'success', 'data' => $items]);
}
elseif ($action === 'delete_item') {
    $path = $_POST['path'];
    $is_dir = $_POST['is_dir'] === 'true' || $_POST['is_dir'] === '1';
    
    // El borrado en cadena también usa tu regla de extensiones para no fallar
    function deleteDir($conn, $dir) {
        $files = @ftp_nlist($conn, $dir);
        if(is_array($files)){
            foreach ($files as $file) {
                $name = basename($file);
                if ($name == '.' || $name == '..') continue;
                
                $abs_path = rtrim($dir, '/') . '/' . $name;
                $ext = pathinfo($name, PATHINFO_EXTENSION);
                
                if ($ext === '') {
                    deleteDir($conn, $abs_path); // Es subcarpeta
                } else {
                    @ftp_delete($conn, $abs_path); // Es archivo
                }
            }
        }
        return @ftp_rmdir($conn, $dir);
    }

    if ($is_dir) { $res = deleteDir($conn, $path); } 
    else { $res = @ftp_delete($conn, $path); }
    echo json_encode(['status' => $res ? 'success' : 'error']);
}
elseif ($action === 'rename') {
    $old = $_POST['old_path'];
    $new = $_POST['new_path'];
    $res = @ftp_rename($conn, $old, $new);
    echo json_encode(['status' => $res ? 'success' : 'error']);
}
elseif ($action === 'mkdir') {
    $path = $_POST['path'];
    $res = @ftp_mkdir($conn, $path);
    echo json_encode(['status' => $res ? 'success' : 'error']);
}
elseif ($action === 'read_file') {
    $path = $_POST['path'];
    $tempHandle = fopen('php://temp', 'r+');
    if (@ftp_fget($conn, $tempHandle, $path, FTP_BINARY, 0)) {
        rewind($tempHandle);
        $content = stream_get_contents($tempHandle);
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        
        if (in_array($ext, ['png', 'jpg', 'jpeg', 'gif', 'bmp'])) {
            $base64 = base64_encode($content);
            $mime = 'image/' . ($ext === 'jpg' ? 'jpeg' : $ext);
            echo json_encode(['status' => 'success', 'type' => 'image', 'data' => "data:$mime;base64,$base64"]);
        } else {
            $text = htmlspecialchars($content, ENT_QUOTES, 'UTF-8');
            echo json_encode(['status' => 'success', 'type' => 'text', 'data' => $text]);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No se pudo leer el archivo.']);
    }
    fclose($tempHandle);
}

@ftp_close($conn);
exit;
?>
