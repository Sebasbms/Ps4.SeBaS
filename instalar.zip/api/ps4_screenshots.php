<?php
/**
 * ARCHIVO: api/ps4_screenshots.php
 * Buscador DEFINITIVO con Corrección de Formato (JPG/PNG dinámico)
 */
$action = $_REQUEST['action'] ?? '';
$host_ip = $_REQUEST['host_ip'] ?? '';
$cusa = $_REQUEST['cusa_id'] ?? '';

// MODO STREAMING: Muestra la foto directo en tu celular
if ($action === 'stream') {
    $path = $_GET['path'] ?? '';
    if (!$host_ip || !$path) exit;
    
    // Evitamos que se corte la descarga si la imagen pesa mucho (Ej: 4K PNG)
    set_time_limit(0); 
    
    $conn = @ftp_connect($host_ip, 2121, 5);
    if ($conn) {
        @ftp_login($conn, "anonymous", "");
        ftp_pasv($conn, true);
        
        // Verificamos la extensión real para no confundir al navegador del celular
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if ($ext === 'png') {
            header('Content-Type: image/png');
        } else {
            header('Content-Type: image/jpeg');
        }
        
        $temp = fopen('php://output', 'w');
        @ftp_fget($conn, $temp, $path, FTP_BINARY, 0);
        @ftp_close($conn);
    }
    exit;
}

// MODO LISTAR: Escáner directo a la Bóveda
header('Content-Type: application/json');
set_time_limit(30);

if (!$host_ip || !$cusa) {
    echo json_encode(['status' => 'error', 'message' => 'Faltan datos de conexión.']);
    exit;
}

$conn = @ftp_connect($host_ip, 2121, 5);
if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'No conecta a PS4.']);
    exit;
}
@ftp_login($conn, "anonymous", "");
ftp_pasv($conn, true);

$capturas = [];

// Función Taladro
function excavar_fotos($conn, $dir, &$capturas, $profundidad = 0) {
    if ($profundidad > 5) return; 
    
    $items = @ftp_nlist($conn, $dir);
    if (is_array($items)) {
        foreach ($items as $item) {
            $base_item = basename($item);
            if ($base_item === '.' || $base_item === '..') continue;
            
            $ruta_completa = (strpos($item, '/') === 0) ? $item : rtrim($dir, '/') . '/' . $base_item;
            $ext = strtolower(pathinfo($base_item, PATHINFO_EXTENSION));
            
            if ($ext === 'jpg' || $ext === 'jpeg' || $ext === 'png') {
                $capturas[] = $ruta_completa;
            } else if (empty($ext)) {
                excavar_fotos($conn, $ruta_completa, $capturas, $profundidad + 1);
            }
        }
    }
}

$rutas_cusa = [];
$base_photo = "/user/av_contents/photo";

// 1. Buscamos la carpeta del juego
$nivel1 = @ftp_nlist($conn, $base_photo);
if (is_array($nivel1)) {
    foreach ($nivel1 as $n1) {
        $base1 = basename($n1);
        if ($base1 === '.' || $base1 === '..') continue;
        
        $ruta1 = (strpos($n1, '/') === 0) ? $n1 : "$base_photo/$base1";

        if (stripos($base1, $cusa) !== false) {
            $rutas_cusa[] = $ruta1; 
        } else {
            $nivel2 = @ftp_nlist($conn, $ruta1);
            if (is_array($nivel2)) {
                foreach ($nivel2 as $n2) {
                    $base2 = basename($n2);
                    if (stripos($base2, $cusa) !== false) {
                        $rutas_cusa[] = (strpos($n2, '/') === 0) ? $n2 : "$ruta1/$base2";
                    }
                }
            }
        }
    }
}

// 2. Excavamos en TODAS las carpetas encontradas
foreach ($rutas_cusa as $ruta) {
    excavar_fotos($conn, $ruta, $capturas);
}

@ftp_close($conn);

if (empty($capturas)) {
    echo json_encode(['status' => 'error', 'message' => "No se encontraron fotos del juego.<br><br><span class='text-[10px]'>Intenta abrir el juego y sacar una captura nueva.</span>"]);
} else {
    sort($capturas);
    echo json_encode(['status' => 'success', 'data' => array_reverse($capturas)]);
}
?>
