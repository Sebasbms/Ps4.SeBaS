<?php
/**
 * ARCHIVO: api/saves.php
 * Motor de Backup de Partidas Guardadas (Con cálculo de peso e info)
 */
header('Content-Type: application/json');
set_time_limit(300); // 5 minutos de tiempo límite

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$host_ip = $_POST['host_ip'] ?? $_GET['host_ip'] ?? '';
$cusa = $_POST['cusa_id'] ?? $_GET['cusa_id'] ?? '';

// 1. Descarga el ZIP creado
if ($action === 'download') {
    $file = $_GET['file'] ?? '';
    $path = "../cache_biblioteca/" . basename($file);
    if (file_exists($path) && strpos($file, '.zip') !== false) {
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="'.basename($path).'"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
    exit;
}

if (!$host_ip || !$cusa) {
    echo json_encode(['status' => 'error', 'message' => 'Faltan datos de conexión.']);
    exit;
}

$conn = @ftp_connect($host_ip, 2121, 5);
if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'No conecta a PS4.']);
    exit;
}
@ftp_login($conn, "anonymous", "");
ftp_pasv($conn, true);

// Función para calcular peso sin colgar la consola
function getDirStats($conn, $remote_dir, &$fileCount) {
    $size = 0;
    $files = @ftp_nlist($conn, $remote_dir);
    if (is_array($files)) {
        foreach ($files as $file) {
            $base = basename($file);
            if ($base == '.' || $base == '..') continue;
            
            $remote_path = rtrim($remote_dir, '/') . '/' . $base;
            $s = @ftp_size($conn, $remote_path);
            
            // En PS4 FTP, si el size es -1, significa que es una carpeta
            if ($s == -1) {
                $size += getDirStats($conn, $remote_path, $fileCount);
            } else {
                $size += $s;
                $fileCount++;
            }
        }
    }
    return $size;
}

// Función para meter archivos al ZIP sin cambiar de directorio (Evita el ZIP vacío)
function addFolderToZip($conn, $remote_dir, $zip, $zip_dir) {
    $files = @ftp_nlist($conn, $remote_dir);
    if (is_array($files)) {
        $zip->addEmptyDir($zip_dir); 
        foreach ($files as $file) {
            $base = basename($file);
            if ($base == '.' || $base == '..') continue;
            
            $remote_path = rtrim($remote_dir, '/') . '/' . $base;
            $local_zip_path = $zip_dir . '/' . $base;
            
            $size = @ftp_size($conn, $remote_path);
            
            if ($size == -1) {
                addFolderToZip($conn, $remote_path, $zip, $local_zip_path); 
            } else {
                $temp = fopen('php://temp', 'r+');
                if (@ftp_fget($conn, $temp, $remote_path, FTP_BINARY, 0)) {
                    rewind($temp);
                    $zip->addFromString($local_zip_path, stream_get_contents($temp)); 
                }
                fclose($temp);
            }
        }
    }
}

// 2. Acción: Revisar y calcular peso ANTES de descargar
if ($action === 'check_saves') {
    $users = @ftp_nlist($conn, "/user/home");
    $total_size = 0;
    $total_files = 0;
    $found_users = [];

    if (is_array($users)) {
        foreach ($users as $u) {
            $user_id = basename($u);
            if ($user_id === '.' || $user_id === '..') continue;
            
            $target = "/user/home/$user_id/savedata/$cusa";
            
            // Verificamos si la carpeta existe
            $check = @ftp_nlist($conn, $target);
            if (is_array($check) && count($check) > 0) {
                $count = 0;
                $size = getDirStats($conn, $target, $count);
                if ($count > 0) {
                    $total_size += $size;
                    $total_files += $count;
                    $found_users[] = $user_id;
                }
            }
        }
    }
    @ftp_close($conn);

    if (empty($found_users)) {
        echo json_encode(['status' => 'error', 'message' => 'No se encontraron partidas (Saves) en la consola para este juego.']);
    } else {
        $mb = number_format($total_size / (1024 * 1024), 2);
        echo json_encode([
            'status' => 'success', 
            'files' => $total_files,
            'size_mb' => $mb,
            'users' => implode(", ", $found_users)
        ]);
    }
    exit;
}

// 3. Acción: Crear el ZIP real
if ($action === 'backup') {
    $users = @ftp_nlist($conn, "/user/home");
    $save_paths = [];
    
    if (is_array($users)) {
        foreach ($users as $u) {
            $user_id = basename($u);
            if ($user_id === '.' || $user_id === '..') continue;
            
            $target = "/user/home/$user_id/savedata/$cusa";
            $check = @ftp_nlist($conn, $target);
            if (is_array($check) && count($check) > 0) {
                $save_paths[] = $target; 
            }
        }
    }

    $cache_dir = '../cache_biblioteca';
    if (!file_exists($cache_dir)) { @mkdir($cache_dir, 0777, true); }
    
    $zip_filename = "{$cusa}_SAVES.zip";
    $zip_path = "$cache_dir/$zip_filename";
    
    if (file_exists($zip_path)) { @unlink($zip_path); }

    $zip = new ZipArchive();
    if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
        foreach ($save_paths as $path) {
            // Extrae el ID del usuario de la ruta para nombrar la carpeta dentro del ZIP
            $user_folder = basename(dirname(dirname($path))); 
            addFolderToZip($conn, $path, $zip, "Saves_Usuario_$user_folder");
        }
        $zip->close();
        echo json_encode(['status' => 'success', 'download_url' => "api/saves.php?action=download&file=$zip_filename"]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error al comprimir el archivo ZIP en el servidor local.']);
    }
    @ftp_close($conn);
    exit;
}
?>
