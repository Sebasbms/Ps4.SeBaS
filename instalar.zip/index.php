<?php
/**
 * ====================================================================
 * GOLDHEN MANAGER V2.0 (PS5)
 * DEVELOPED *By SeBaS* 
====================================================================
 */
error_reporting(0);
@ini_set('display_errors', 0);
@ini_set('memory_limit', '512M'); // Límite seguro para KSWEB

// Firma Anti-Robo en cabeceras HTTP oculta
$firma = chr(83).chr(101).chr(66).chr(97).chr(83); // SeBaS
header('X-Author: ' . $firma);

// 1. AUTO-CREACIÓN PWA E ICONO
$manifest_content = '{
  "name": "GoldHen Manager", "short_name": "GoldHen Manager",
  "start_url": "./index.php", "display": "standalone", "background_color": "#0b0c10",
  "theme_color": "#0b0c10", "orientation": "portrait-primary",
  "icons": [{"src": "icon-512.png?v=7", "sizes": "512x512", "type": "image/png", "purpose": "any"}]
}';
if (!file_exists('manifest.json')) { @file_put_contents('manifest.json', $manifest_content); }

$sw_content = "self.addEventListener('install', (e) => self.skipWaiting());\nself.addEventListener('activate', (e) => self.clients.claim());\nself.addEventListener('fetch', (e) => e.respondWith(fetch(e.request)));";
if (!file_exists('sw.js')) { @file_put_contents('sw.js', $sw_content); }

if (!file_exists('icon-512.png')) {
    // Ofuscación de URL de Github (ElNoNo26 / Ps4-SeBaS)
    $u = chr(69).chr(108).chr(78).chr(111).chr(78).chr(111).chr(50).chr(54);
    $r = chr(80).chr(115).chr(52).chr(45).chr(83).chr(101).chr(66).chr(97).chr(83);
    $icon_url = 'https://raw.githubusercontent.com/'.$u.'/'.$r.'/main/icon-512.png';
    if (ini_get('allow_url_fopen')) { @file_put_contents('icon-512.png', file_get_contents($icon_url)); }
}

// 2. AUTO-DESCUBRIMIENTO Y PROTECCIÓN DE GALERÍA (.nomedia)
$directorios = ['iconos', 'backup_icons', 'payloads', 'cache_biblioteca', 'servidor_rpi', 'rpi_cache'];
foreach ($directorios as $dir) {
    if (!file_exists($dir)) { @mkdir($dir, 0777, true); }
    if (!file_exists($dir . '/.nomedia')) { @file_put_contents($dir . '/.nomedia', ''); }
}

$iconos_locales = [];
$archivos_ic = glob('iconos/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
if (is_array($archivos_ic)) { foreach($archivos_ic as $a) { $iconos_locales[] = ['nombre' => basename($a), 'url' => $a]; } }

$backups_locales = [];
$archivos_bk = glob('backup_icons/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
if (is_array($archivos_bk)) { foreach($archivos_bk as $a) { $backups_locales[] = ['nombre' => basename($a), 'url' => $a]; } }

$payloads_locales = [];
$archivos_bin = glob('payloads/*.bin');
if (is_array($archivos_bin)) { foreach($archivos_bin as $a) { $payloads_locales[] = ['nombre' => basename($a), 'url' => $a]; } }

// 3. DETECCIÓN DE IP LOCAL (CELULAR - BYPASS ANDROID TERMUX)
function getLocalIP() {
    $ip = '127.0.0.1';
    
    // Intento 1: Comando específico para la antena Wi-Fi en Android (wlan0)
    exec("ip -4 addr show wlan0 2>/dev/null", $out_ip);
    if (!empty($out_ip)) {
        foreach ($out_ip as $line) {
            if (preg_match('/inet\s+([0-9\.]+)\//i', $line, $matches)) {
                return $matches[1]; // Si lo encuentra, retorna inmediatamente la IP real
            }
        }
    }
    
    // Intento 2: Búsqueda general clásica
    if (strpos(strtoupper(PHP_OS), 'WIN') === 0) {
        exec("ipconfig", $out);
        foreach ($out as $line) {
            if (preg_match('/IPv4.*?:\s+([0-9\.]+)/i', $line, $matches)) {
                if (strpos($matches[1], '192.168.') === 0 || strpos($matches[1], '10.') === 0) { $ip = $matches[1]; break; }
            }
        }
    } else {
        exec("ifconfig 2>/dev/null", $out);
        foreach ($out as $line) {
            if (preg_match('/inet\s+([0-9\.]+)/i', $line, $matches)) {
                if ($matches[1] != '127.0.0.1' && strpos($matches[1], '127.') !== 0) { 
                    $ip = $matches[1]; 
                    if (strpos($ip, '192.168.') === 0) break; 
                }
            }
        }
    }
    return $ip;
}

$ip_servidor = getLocalIP();
$subred_partes = explode('.', $ip_servidor);
$subred_actual = isset($subred_partes[0]) ? $subred_partes[0] . '.' . $subred_partes[1] . '.' . $subred_partes[2] . '.' : '192.168.0.';

// 4. PROXY RPI SENDER (ENLACES DIRECTOS)
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (isset($_GET['rpi_proxy']) || (isset($data['ip']) && isset($data['url_pkg']))) {
    header('Content-Type: application/json');
    $ps4_ip = isset($data['ip']) ? $data['ip'] : '';
    $url_pkg = isset($data['url_pkg']) ? $data['url_pkg'] : '';
    
    if (empty($ps4_ip) || empty($url_pkg)) { 
        echo json_encode(['status' => 'fail', 'message' => 'Faltan datos IP o URL']); 
        exit; 
    }
    
    // Formato exacto que pide el RPI de PS4
    $payload = json_encode([
        "type" => "direct",
        "packages" => [$url_pkg]
    ]);
    
    $ch = curl_init('http://' . $ps4_ip . ':12800/api/install');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json', 
        'Content-Length: ' . strlen($payload)
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    $logs = [
        "Link directo: $url_pkg", 
        "P12800 -> HTTP:$httpcode | Resp:$response | Err:$error"
    ];
    
    if ($httpcode >= 200 && $httpcode < 300 && strpos($response, 'success') !== false) {
        echo json_encode(['status' => 'success', 'message' => 'Orden enviada a PS4', 'logs' => $logs]);
    } else {
        echo json_encode(['status' => 'fail', 'message' => 'El RPI rechazó la conexión', 'logs' => $logs]);
    }
    exit;
}

// 5. OBTENER LISTA DE JUEGOS RPI (SOLO METADATOS BÁSICOS PARA QUE JS ENCOLE)
if (isset($_GET['get_rpi_list'])) {
    header('Content-Type: application/json');
    $dir = __DIR__ . '/servidor_rpi';
    $pkgs = [];
    
    if (is_dir($dir)) {
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..' && strtolower(pathinfo($file, PATHINFO_EXTENSION)) === 'pkg') {
                $path = $dir . '/' . $file;
                $size = filesize($path);
                
                // Formateo de peso
                $units = ['B', 'KB', 'MB', 'GB', 'TB'];
                $bytes = max($size, 0); 
                $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
                $pow = min($pow, count($units) - 1); 
                $bytes /= pow(1024, $pow);
                $size_fmt = round($bytes, 2) . ' ' . $units[$pow];
                
                $pkgs[] = [
                    'nombre' => $file,
                    'path' => 'servidor_rpi/' . $file,
                    'size' => $size,
                    'size_fmt' => $size_fmt
                ];
            }
        }
    }
    echo json_encode(['status' => 'success', 'data' => $pkgs]);
    exit;
}

// 6. EXTRACTOR BINARIO SECUENCIAL DE PKG (PARAM.SFO & ICON0.PNG)
if (isset($_GET['extract_pkg'])) {
    header('Content-Type: application/json');
    $file = basename($_GET['extract_pkg']);
    $path = __DIR__ . '/servidor_rpi/' . $file;
    $cache_img = __DIR__ . '/rpi_cache/' . $file . '.png';
    $cache_json = __DIR__ . '/rpi_cache/' . $file . '.json';

    // Si ya existe en caché, devolverlo inmediatamente
    if (file_exists($cache_json)) {
        echo file_get_contents($cache_json);
        exit;
    }

    $title_fallback = trim(preg_replace('/(_|-|\.pkg)/i', ' ', $file));
    $meta = ['title' => $title_fallback, 'cusa' => 'UNKNOWN', 'icon' => ''];
    
    if (file_exists($path)) {
        $fp = fopen($path, 'rb');
        if ($fp) {
            // Leemos solo los primeros 5MB para no ahogar KSWEB
            $buffer = fread($fp, 5 * 1024 * 1024);
            fclose($fp);

            // Buscar firma de SFO
            $sfo_pos = strpos($buffer, "\0PSF");
            if ($sfo_pos !== false) {
                $sfo_data = substr($buffer, $sfo_pos, 65536);
                // Extraer CUSA (Regex robusto)
                if (preg_match('/(CUSA\d{5})/i', $sfo_data, $m)) {
                    $meta['cusa'] = strtoupper($m[1]);
                }
            }

            // Buscar firma PNG (ICON0.PNG)
            $png_start = strpos($buffer, "\x89PNG\r\n\x1a\n");
            if ($png_start !== false) {
                $png_end = strpos($buffer, "IEND\xae\x42\x60\x82", $png_start);
                if ($png_end !== false) {
                    $png_end += 8; // Incluir marcador final
                    $png_data = substr($buffer, $png_start, $png_end - $png_start);
                    file_put_contents($cache_img, $png_data);
                    $meta['icon'] = 'rpi_cache/' . $file . '.png';
                }
            }
        }
    }
    
    $json_output = json_encode(['status' => 'success', 'data' => $meta]);
    file_put_contents($cache_json, $json_output); // Guardar en caché
    echo $json_output;
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>GoldHen Manager</title>
    
    <link rel="manifest" href="manifest.json?v=7">
    <meta name="theme-color" content="#0b0c10">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="apple-touch-icon" href="icon-512.png?v=7">

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    
    <style>
        :root { --ps5-bg: #0b0c10; --glass-bg: rgba(255, 255, 255, 0.03); --glass-border: rgba(255, 255, 255, 0.08); }
        body { font-family: 'Outfit', sans-serif; background-color: var(--ps5-bg); color: #ffffff; overflow-x: hidden; -webkit-user-select: none; user-select: none; touch-action: pan-y; margin: 0; min-height: 100vh; padding-bottom: calc(120px + env(safe-area-inset-bottom)); }

        /* INTRO */
        #intro-screen { position: fixed; inset: 0; z-index: 200; display: flex; align-items: center; justify-content: center; background: #000; transition: opacity 1.5s ease; }
        #stardust { position: absolute; inset: 0; width: 100%; height: 100%; }
        #logo-wrapper { position: relative; z-index: 10; opacity: 0; transform: scale(0.9); filter: blur(10px); transition: all 3s ease; }
        .ps-logo-intro { font-size: 6rem; color: white; filter: drop-shadow(0 0 15px rgba(255,255,255,0.4)); }
        
        #app-ui { opacity: 0; transition: opacity 1.5s ease; width: 100%; }
        .ambient-bg { position: fixed; inset: 0; z-index: -1; overflow: hidden; background: radial-gradient(circle at 50% 50%, #111827 0%, var(--ps5-bg) 100%); transform: scale(1.2); transition: transform 2.5s cubic-bezier(0.16, 1, 0.3, 1); }
        .orb { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.4; animation: float-orb 20s infinite alternate ease-in-out; }
        .orb-1 { width: 300px; height: 300px; background: #3730a3; top: -10%; left: -10%; }
        .orb-2 { width: 400px; height: 400px; background: #1e3a8a; bottom: -20%; right: -10%; animation-delay: -5s; }
        .orb-3 { width: 250px; height: 250px; background: #0f172a; top: 40%; left: 40%; animation-delay: -10s; }
        @keyframes float-orb { 0% { transform: translate(0, 0) scale(1); } 50% { transform: translate(30px, 50px) scale(1.2); } 100% { transform: translate(-20px, 20px) scale(0.9); } }

        .glass-panel { background: var(--glass-bg); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid var(--glass-border); box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); }
        .modal-glass { background: rgba(5, 5, 8, 0.85); backdrop-filter: blur(25px); -webkit-backdrop-filter: blur(25px); }

        .btn-ps5 { background: var(--glass-bg); border: 1px solid var(--glass-border); backdrop-filter: blur(10px); transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); cursor: pointer; }
        
        /* Modificado para mayor opacidad según el parche JS previo */
        .btn-ps5-primary { background: #ffffff !important; color: black; border: none; box-shadow: 0 -5px 25px rgba(0,0,0,0.8) !important; transition: all 0.2s; cursor: pointer;}
        .btn-ps5-danger { background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.5); color: #fca5a5; transition: all 0.2s;}
        
        /* Modificado para dock sólido */
        .dock-nav { position: fixed; bottom: calc(15px + env(safe-area-inset-bottom)); left: 50%; transform: translateX(-50%); z-index: 40; display: flex; justify-content: space-between; align-items: center; width: 92%; max-width: 420px; padding: 8px 12px; border-radius: 9999px; background: #0b0c10 !important; border: 1px solid rgba(255,255,255,0.05) !important; box-shadow: 0 -15px 40px rgba(0,0,0,0.95) !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
        .dock-item { width: 42px; height: 42px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: rgba(255,255,255,0.4); font-size: 1.1rem; transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); flex-shrink: 0; cursor: pointer; position: relative; }
        .dock-item.active { color: white; background: rgba(255,255,255,0.1); transform: translateY(-8px) scale(1.1); box-shadow: 0 10px 20px rgba(0,0,0,0.5), inset 0 0 0 1px rgba(255,255,255,0.2); }
        .dock-item.active::after { content: ''; position: absolute; bottom: -8px; left: 50%; transform: translateX(-50%); width: 6px; height: 6px; border-radius: 50%; background: white; box-shadow: 0 0 10px white; }

        .dock-ripple { position: absolute; top: 0; left: 0; right: 0; bottom: 0; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 15px rgba(255,255,255,0.8); animation: ps5-burst 0.5s ease-out forwards; pointer-events: none; z-index: -1; }
        @keyframes ps5-burst { 0% { transform: scale(1); opacity: 0.8; } 100% { transform: scale(2.2); opacity: 0; } }

        #notification-area { position: fixed; top: max(20px, env(safe-area-inset-top)); right: 20px; z-index: 9999; display: flex; flex-direction: column; gap: 10px; pointer-events: none; align-items: flex-end; }
        .ps5-toast { background: rgba(20, 20, 25, 0.95); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.15); border-radius: 12px; padding: 12px 16px; display: flex; align-items: center; gap: 14px; box-shadow: 0 15px 35px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.1); color: white; min-width: 250px; max-width: calc(100vw - 40px); animation: slideInRight 0.4s cubic-bezier(0.17, 0.67, 0.32, 1) forwards; }
        .ps5-toast.hide { animation: fadeOutRight 0.4s cubic-bezier(0.17, 0.67, 0.32, 1) forwards; }
        .ps5-toast-icon { width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #ffffff 0%, #aaaaaa 100%); color: black; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; box-shadow: 0 0 10px rgba(255,255,255,0.3); }
        @keyframes slideInRight { from { transform: translateX(120%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes fadeOutRight { to { transform: translateX(120%); opacity: 0; } }

        .floating-btn-global { position: fixed; bottom: calc(90px + env(safe-area-inset-bottom)); left: 50%; transform: translateX(-50%); width: 100%; max-width: 32rem; padding: 0 1.25rem; z-index: 35; transition: opacity 0.4s, transform 0.4s cubic-bezier(0.16, 1, 0.3, 1); }
        .floating-hidden { opacity: 0; pointer-events: none; transform: translate(-50%, 30px) scale(0.95); }

        .tab-content { display: none; opacity: 0; transform: translateY(20px) scale(0.98); transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1); }
        .tab-content.active { display: block; opacity: 1; transform: translateY(0) scale(1); }
        
        .custom-scrollbar::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background-color: rgba(255,255,255,0.2); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-track { background-color: transparent; }
        
        .folder-btn.active { background: rgba(255,255,255,0.2); border-color: rgba(255,255,255,0.5); color: white; }
        .payload-item.selected { background: rgba(255,255,255,0.15); border-color: rgba(255,255,255,0.4); }
        .gallery-item { position: relative; cursor: pointer; border-radius: 12px; overflow: hidden; border: 2px solid transparent; transition: all 0.2s; background-color: #111; width: 100%; padding-bottom: 100%; }
        .gallery-item.selected { border-color: #ef4444; box-shadow: 0 0 20px rgba(239, 68, 68, 0.6); transform: scale(0.95); }
        .gallery-item img { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; display: block; pointer-events: none;}
        
        .rpi-card { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); cursor: pointer; position: relative; overflow: hidden; border: 2px solid transparent; background: rgba(255,255,255,0.02); }
        .rpi-card.selected { border-color: #3b82f6; transform: scale(0.96); box-shadow: 0 0 20px rgba(59, 130, 246, 0.5); background: rgba(59, 130, 246, 0.1); }
        .rpi-card-check { position: absolute; top: 8px; right: 8px; width: 24px; height: 24px; background: rgba(0,0,0,0.6); border: 2px solid rgba(255,255,255,0.4); border-radius: 50%; display: flex; align-items: center; justify-content: center; z-index: 20; transition: all 0.2s; }
        .rpi-card.selected .rpi-card-check { background: #3b82f6; border-color: #3b82f6; }
        .rpi-card.selected .rpi-card-check i { opacity: 1; transform: scale(1); }
        .rpi-card-check i { opacity: 0; transform: scale(0.5); transition: all 0.2s; color: white; font-size: 12px; }

        .toggle-checkbox { display: none; }
        .toggle-label { display: inline-block; position: relative; width: 50px; height: 26px; background-color: rgba(255,255,255,0.1); border-radius: 9999px; transition: background-color 0.3s ease; cursor: pointer; border: 1px solid rgba(255,255,255,0.2);}
        .toggle-label::after { content: ''; position: absolute; top: 2px; left: 3px; width: 20px; height: 20px; background-color: white; border-radius: 50%; transition: transform 0.3s cubic-bezier(0.4, 0.0, 0.2, 1); box-shadow: 0 2px 4px rgba(0,0,0,0.3); }
        .toggle-checkbox:checked + .toggle-label { background-color: #eab308; border-color: #eab308;}
        .toggle-checkbox:checked + .toggle-label::after { transform: translateX(22px); background-color: black;}

        .bottom-sheet { position: fixed; bottom: 0; left: 50%; transform: translateX(-50%) translateY(100%); width: 100%; max-width: 32rem; background: #111827; border-top-left-radius: 24px; border-top-right-radius: 24px; z-index: 60; transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1); border-top: 1px solid rgba(255,255,255,0.1); padding-bottom: env(safe-area-inset-bottom); max-height: 90vh; overflow-y: auto;}
        .bottom-sheet.open { transform: translateX(-50%) translateY(0); }
        .overlay-sheet { position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 55; opacity: 0; pointer-events: none; transition: opacity 0.3s; backdrop-filter: blur(5px); }
        .overlay-sheet.open { opacity: 1; pointer-events: auto; }

        .filter-pill { transition: all 0.3s ease; border: 1px solid rgba(255,255,255,0.05); }
        .filter-pill.active { background: white; color: black; border-color: white; box-shadow: 0 0 15px rgba(255,255,255,0.2); }

        input[type=range] { -webkit-appearance: none; background: transparent; }
        input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; height: 16px; width: 16px; border-radius: 50%; background: #ffffff; cursor: pointer; margin-top: -6px; box-shadow: 0 0 10px rgba(255,255,255,0.8); transition: transform 0.1s; }
        input[type=range]::-webkit-slider-thumb:active { transform: scale(1.3); }
        input[type=range]::-webkit-slider-runnable-track { width: 100%; height: 4px; cursor: pointer; background: rgba(255,255,255,0.2); border-radius: 2px; }

        .gallery-trash-btn { opacity: 0; pointer-events: none; transition: opacity 0.2s; }
        .gallery-item.selected .gallery-trash-btn { opacity: 1; pointer-events: auto; }

        /* FIRMA FRAGMENTADA (ANTI-ROBO) */
        .signature-box::after { content: "BY " "\53\45\42\41\53"; }
        .footer-sig::after { content: "Developed " "by " "\53\65\42\61\53"; }
        
        #rpi-pkg-list { max-height: 65vh !important; padding-bottom: 140px !important; }
        #explorer-list { padding-bottom: 140px !important; }
        .gallery-grid-fix { max-height: 65vh !important; padding-bottom: 140px !important; }
        .pb-biblioteca-fix { padding-bottom: 140px !important; }

        @media (min-width: 768px) {
            .dock-nav { max-width: 500px; padding: 12px 20px; bottom: calc(25px + env(safe-area-inset-bottom)); }
            .dock-item { width: 50px; height: 50px; font-size: 1.3rem; }
            .bottom-sheet { max-width: 40rem; }
            .floating-btn-global { max-width: 40rem; }
        }

        @media (max-width: 767px) and (orientation: landscape) {
            #landscape-warning { display: flex !important; }
            #app-ui { display: none !important; }
        }
        
        .game-card { transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); transform-origin: center; }
        .sorting-anim { transform: scale(0.9); opacity: 0.5; }
    </style>
</head>

<body>
    <div id="notification-area"></div>

    <div id="landscape-warning" class="hidden fixed inset-0 z-[999] bg-[#0b0c10] flex-col items-center justify-center text-center p-8">
        <i class="fa-solid fa-mobile-screen text-6xl text-white mb-6 animate-pulse" style="transform: rotate(-90deg);"></i>
        <h2 class="text-2xl font-black text-white mb-2 tracking-widest uppercase">Gira tu celular</h2>
        <p class="text-white/50 text-sm">Por favor, usa el dispositivo en modo vertical para una mejor experiencia.</p>
    </div>

    <div id="intro-screen">
        <canvas id="stardust"></canvas>
        <div id="logo-wrapper"><i class="fa-brands fa-playstation ps-logo-intro"></i></div>
    </div>

    <div id="app-ui">
        <div class="ambient-bg" id="ambient-bg"><div class="orb orb-1"></div><div class="orb orb-2"></div><div class="orb orb-3"></div></div>

        <header class="w-full max-w-md md:max-w-4xl mx-auto pt-8 px-5 flex justify-between items-center relative z-10 mb-4">
            <div id="badge-detectada" class="hidden flex items-center gap-3 glass-panel px-4 py-2 rounded-full border-green-500/30">
                <div id="badge-dot" class="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-[0_0_8px_#4ade80]"></div>
                <span id="badge-text" class="text-[9px] font-bold tracking-widest text-green-100 uppercase" data-i18n="ps4_detected">PS4 DETECTADA</span>
            </div>
            <div id="badge-desconectada" class="flex items-center gap-3 glass-panel px-4 py-2 rounded-full border-red-500/30">
                <div class="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]"></div>
                <span class="text-[9px] font-bold tracking-widest text-red-100 uppercase" data-i18n="ps4_disconnected">DESCONECTADA</span>
            </div>
            <div class="flex items-center gap-2.5 cursor-pointer group" onclick="cambiarNombreUsuario()">
                <div id="profile-avatar" class="w-8 h-8 rounded-full bg-[#549E43] flex items-center justify-center border border-[#386C2B] bg-cover bg-center overflow-hidden relative">
                    <span id="profile-initial" class="text-white font-bold text-[15px] relative z-10">S</span>
                </div>
                <span id="profile-name" class="signature-box text-[11px] font-black tracking-[0.15em] text-[#A1A1AA]"></span>
            </div>
        </header>

        <div class="w-full max-w-md md:max-w-4xl mx-auto px-5 relative z-10 mb-4">
            <div class="glass-panel rounded-2xl p-2 flex gap-2 items-center shadow-lg">
                <div class="flex-1 flex items-center px-3 bg-black/40 rounded-xl border border-white/5 focus-within:border-white/30 transition-colors relative">
                    <i class="fa-solid fa-network-wired text-white/40 text-xs mr-3"></i>
                    <input type="text" id="host-ip" placeholder="IP PS4 (192.168.x.x)" data-i18n-placeholder="ip_placeholder" class="bg-transparent w-full text-sm font-mono outline-none text-white py-3 placeholder-white/20" autocomplete="off">
                    <i class="fa-solid fa-xmark text-white/40 hover:text-white cursor-pointer px-3 py-2 relative z-20" onclick="clearIP()"></i>
                </div>
                <button id="btn-scan" onclick="toggleRealScan()" class="w-12 h-12 rounded-xl bg-blue-600 hover:bg-blue-500 flex items-center justify-center text-white active:scale-95"><i class="fa-solid fa-satellite-dish" id="scan-icon"></i></button>
                <button onclick="connectManualIP()" class="w-12 h-12 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white active:scale-95"><i class="fa-solid fa-plug" id="connect-icon"></i></button>
            </div>
            <p id="global-status" class="text-[11px] font-bold text-center mt-3 font-mono text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.8)] tracking-widest hidden"><i class="fa-solid fa-satellite-dish fa-fade mr-2 text-white"></i> <span id="scan-text">BUSCANDO IP...</span></p>
        </div>

        <div id="install-pwa-container" class="hidden w-full max-w-md md:max-w-4xl mx-auto px-5 relative z-10 mb-6 transition-all duration-300">
            <div class="bg-blue-600/20 border border-blue-500/30 rounded-2xl p-4 relative overflow-hidden flex items-center justify-between shadow-lg">
                <div class="absolute top-0 right-0 w-20 h-20 bg-blue-400/20 blur-[30px] rounded-full pointer-events-none"></div>
                <div class="flex items-center gap-3 relative z-10">
                    <div class="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center shrink-0 border border-blue-400/30"><i class="fa-solid fa-mobile-screen-button text-blue-400 text-lg"></i></div>
                    <div><span class="text-xs font-bold text-white block" data-i18n="install_app">Instalar App</span><span class="text-[9px] text-white/60" data-i18n="install_desc">Añadir a pantalla de inicio</span></div>
                </div>
                <div class="flex items-center gap-2 relative z-10">
                    <button onclick="installPWA()" class="bg-white text-black font-bold text-[9px] tracking-widest px-4 py-2.5 rounded-lg active:scale-95 shadow-lg" data-i18n="btn_install">INSTALAR</button>
                    <button onclick="dismissPWA()" class="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-white/50 hover:text-white flex items-center justify-center transition-colors"><i class="fa-solid fa-xmark"></i></button>
                </div>
            </div>
        </div>

        <main class="w-full max-w-md md:max-w-4xl mx-auto px-5 relative z-10">
            
            <div id="tab-biblioteca" class="tab-content active">
                <header class="flex justify-between items-start mb-2">
                    <div class="flex flex-col">
                        <h1 class="text-2xl font-black text-white tracking-wide leading-none mb-1.5" data-i18n="tab_biblio">Biblioteca</h1>
                        <div class="flex items-center gap-2 text-[9px]">
                            <div class="flex items-center gap-1.5 text-blue-400 font-bold bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                                <i class="fa-solid fa-gamepad"></i> <span class="text-[10px]" id="total-games-badge">--</span>
                            </div>
                            <span class="text-white/50 font-mono tracking-widest uppercase mt-0.5" data-i18n="titles_installed">TÍTULOS INSTALADOS</span>
                        </div>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="limpiarBibliotecaEntera()" class="w-8 h-8 rounded-full bg-red-500/20 border border-red-500/30 flex items-center justify-center text-red-400 active:scale-95 shadow-lg"><i class="fa-solid fa-trash-can text-[10px]"></i></button>
                        <button onclick="simularSincronizacion()" class="w-8 h-8 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white active:scale-95"><i class="fa-solid fa-rotate text-[10px]"></i></button>
                    </div>
                </header>

                <div class="w-full bg-black/50 rounded-full h-[3px] mb-4 flex overflow-hidden border border-white/5 relative">
                    <div class="bg-gradient-to-r from-blue-400 to-purple-500 h-full w-[65%] rounded-full relative">
                        <div class="absolute inset-0 bg-white/20 animate-[shimmer_2s_infinite] -skew-x-12"></div>
                    </div>
                </div>

                <div class="flex gap-2 w-full mb-3">
                    <div class="relative flex-1">
                        <i class="fa-solid fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40 text-[10px]"></i>
                        <input type="text" id="buscador-biblio" onkeyup="buscarEnBiblioteca(this.value)" placeholder="Buscar juego o app..." data-i18n-placeholder="search_placeholder" class="w-full bg-black/40 border border-white/10 rounded-xl pl-8 pr-3 py-2.5 text-[10px] font-bold tracking-wider text-white outline-none focus:border-white/30 transition-colors placeholder-white/30" autocomplete="off">
                    </div>
                    <button onclick="cambiarOrden()" class="glass-panel w-9 h-9 rounded-xl flex items-center justify-center text-white active:scale-95 shrink-0 transition-colors hover:bg-white/10 group">
                        <i id="icono-orden" class="fa-solid fa-arrow-down-short-wide text-xs text-blue-400 group-hover:text-white transition-colors"></i>
                    </button>
                </div>

                <div id="categoria-nav" class="flex gap-2 overflow-x-auto pb-2 mb-2 custom-scrollbar items-center"></div>
                
                <div class="overflow-y-auto custom-scrollbar pr-1 pb-biblioteca-fix">
                    <div class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5" id="grid-biblioteca"></div>
                </div>
            </div>

            <div id="tab-ftp" class="tab-content">
                <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_transfer">Transferir</h1>
                <p class="text-xs text-white/50 mb-6 font-light tracking-wide" data-i18n="desc_transfer">Envía juegos o aplicaciones a tu consola.</p>
                
                <div class="glass-panel p-1.5 rounded-2xl mb-6 flex relative">
                    <div class="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10 rounded-2xl opacity-50"></div>
                    <button id="btn-mode-rpi" onclick="switchTransferMode('rpi')" class="flex-1 py-3 text-[9px] font-black tracking-widest rounded-xl bg-white text-black shadow-lg whitespace-nowrap relative z-10 transition-all" data-i18n="rpi_sender">RPI SENDER</button>
                    <button id="btn-mode-ftp" onclick="switchTransferMode('ftp')" class="flex-1 py-3 text-[9px] font-black tracking-widest rounded-xl text-white/50 hover:text-white whitespace-nowrap relative z-10 transition-all" data-i18n="ftp_classic">FTP CLÁSICO</button>
                </div>

                <div id="box-mode-rpi" class="glass-panel rounded-[2rem] p-6 mb-6">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center border border-blue-500/30">
                            <i class="fa-solid fa-mobile-screen text-blue-400 text-xs"></i>
                        </div>
                        <h2 class="text-xs font-bold tracking-widest text-white/70" data-i18n="games_on_phone">JUEGOS EN EL CELULAR</h2>
                    </div>
                    <div id="rpi-pkg-list" class="grid grid-cols-2 md:grid-cols-3 gap-3 overflow-y-auto custom-scrollbar pr-1"></div>
                </div>

                <form id="ftp-form" onsubmit="enviarArchivoChunks(event)" class="hidden">
                    <div class="glass-panel rounded-[2rem] p-6 mb-6">
                        <h2 class="text-xs font-bold tracking-widest text-white/70 mb-4" data-i18n="dest_routes"><i class="fa-solid fa-folder-open mr-2"></i>RUTAS DE DESTINO</h2>
                        <div class="grid grid-cols-2 gap-3 mb-6" id="paths-grid">
                            <button type="button" class="folder-btn active btn-ps5 rounded-xl py-3 text-xs font-bold text-white/60 border border-white/10" onclick="selectPath(this, '/data/')">/data/</button>
                            <button type="button" class="folder-btn btn-ps5 rounded-xl py-3 text-xs font-bold text-white/60 border border-white/10" onclick="selectPath(this, '/data/pkg/')">/data/pkg/</button>
                            <button type="button" class="folder-btn btn-ps5 rounded-xl py-3 text-[11px] font-bold text-white/60 border border-white/10" onclick="selectPath(this, '/mnt/usb0/')">/mnt/usb0/</button>
                            <button type="button" id="btn-otra" class="folder-btn btn-ps5 rounded-xl py-3 text-xs font-bold text-white/60 border border-dashed border-white/20" onclick="showAddPathUI()"><i class="fa-solid fa-plus"></i></button>
                        </div>
                        <input type="hidden" id="selected-path-input" value="/data/">
                        
                        <div id="add-path-ui" class="hidden mb-6 flex gap-2">
                            <input type="text" id="new-path-input" placeholder="/ruta/" class="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 text-sm font-mono text-white outline-none">
                            <button type="button" onclick="saveNewPath()" class="bg-white text-black px-4 rounded-xl font-bold"><i class="fa-solid fa-check"></i></button>
                            <button type="button" onclick="hideAddPathUI()" class="bg-white/10 text-white px-4 rounded-xl border border-white/10"><i class="fa-solid fa-xmark"></i></button>
                        </div>

                        <h2 class="text-xs font-bold tracking-widest text-white/70 mb-4" data-i18n="files_pkg"><i class="fa-solid fa-file-circle-plus mr-2"></i>ARCHIVOS (PKG/BIN)</h2>
                        <div onclick="document.getElementById('file-upload').click()" class="w-full aspect-video border border-dashed border-white/20 rounded-3xl flex flex-col items-center justify-center cursor-pointer bg-black/20 group">
                            <div id="upload-icon-container" class="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-white mb-3 group-hover:scale-110 transition-transform"><i class="fa-solid fa-cloud-arrow-up text-2xl"></i></div>
                            <span id="file-name-display" class="text-[10px] font-bold tracking-widest text-white/50 text-center px-4" data-i18n="touch_select">TOCA PARA SELECCIONAR</span>
                            <input type="file" id="file-upload" class="hidden" multiple onchange="updateFileName(this)">
                        </div>
                    </div>
                    <button type="submit" id="ftp-form-submit" class="hidden"></button>
                </form>
            </div>

            <div id="tab-icons" class="tab-content">
                <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_mod">Modding</h1>
                <p class="text-xs text-white/50 mb-6 font-light tracking-wide" data-i18n="desc_mod">Personaliza el arte de tu biblioteca.</p>
                <form id="icon-form" onsubmit="enviarIcono(event)">
                    <div class="glass-panel rounded-[2rem] p-6 mb-6">
                        <div class="flex gap-2 mb-6 items-end">
                            <div class="flex-1 relative">
                                <label class="text-[10px] font-bold tracking-widest text-white/70 block mb-3" data-i18n="title_id">TITLE ID</label>
                                <input type="text" id="icon-cusa" placeholder="CUSA12345" oninput="this.value = this.value.toUpperCase();" class="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-4 font-mono text-center text-lg outline-none text-white uppercase">
                            </div>
                            <button type="button" onclick="respaldarOriginal()" class="h-[58px] w-[58px] bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg active:scale-95 shrink-0">
                                <i class="fa-solid fa-download text-2xl"></i>
                            </button>
                            <button type="button" onclick="respaldarTodos()" class="h-[58px] w-[58px] bg-purple-600 text-white rounded-2xl flex items-center justify-center shadow-[0_0_15px_rgba(147,51,234,0.4)] active:scale-95 shrink-0">
                                <i class="fa-solid fa-layer-group text-2xl"></i>
                            </button>
                        </div>
                        <div class="flex gap-1.5 p-1 bg-black/40 rounded-[1.2rem] mb-6 border border-white/5 overflow-x-auto custom-scrollbar">
                            <button type="button" id="btn-src-gallery" class="flex-1 py-3 px-3 text-[9px] font-bold rounded-xl bg-white text-black shadow-lg whitespace-nowrap" onclick="switchIconSource('gallery')" data-i18n="gallery">GALERÍA</button>
                            <button type="button" id="btn-src-backup" class="flex-1 py-3 px-3 text-[9px] font-bold rounded-xl text-white/50 whitespace-nowrap" onclick="switchIconSource('backup')" data-i18n="backups">BACKUPS</button>
                            <button type="button" id="btn-src-import" class="flex-1 py-3 px-3 text-[9px] font-bold rounded-xl text-white/50 whitespace-nowrap" onclick="switchIconSource('import')" data-i18n="import">IMPORTAR</button>
                            <button type="button" id="btn-src-local" class="flex-1 py-3 px-3 text-[9px] font-bold rounded-xl text-white/50 whitespace-nowrap" onclick="switchIconSource('local')" data-i18n="local">LOCAL</button>
                        </div>
                        
                        <div id="box-src-gallery" class="animate-fade-in"><div id="gallery-container"></div></div>
                        <div id="box-src-backup" class="hidden animate-fade-in"><div id="backup-container"></div></div>
                        <div id="box-src-import" class="hidden animate-fade-in">
                            <div class="bg-black/20 border border-white/5 rounded-[1.5rem] p-5 text-center h-[250px] flex flex-col justify-center">
                                <i class="fa-solid fa-cloud-arrow-down text-4xl text-white/30 mb-3"></i>
                                <p class="text-[10px] text-white/50 mb-4 px-2" data-i18n="import_desc">Pega un link directo para descargar a tu galería.</p>
                                <input type="url" id="import-url" placeholder="https://..." class="w-full bg-black/60 rounded-xl px-4 py-3 border border-white/10 font-mono text-xs text-white outline-none mb-4">
                                <button type="button" id="btn-cargar-url" onclick="importarURL()" class="w-full bg-white/10 hover:bg-white/20 border border-white/10 text-white rounded-xl py-3 font-bold text-[10px] tracking-widest transition-colors" data-i18n="btn_import">INICIAR IMPORTACIÓN</button>
                            </div>
                        </div>
                        <div id="box-src-local" class="hidden animate-fade-in">
                            <div onclick="document.getElementById('icon-file').click()" class="w-full h-[250px] bg-black/20 rounded-[1.5rem] border border-dashed border-white/20 flex flex-col items-center justify-center cursor-pointer relative overflow-hidden">
                                <i id="icon-file-placeholder" class="fa-solid fa-image text-4xl text-white/20 mb-3"></i>
                                <span id="icon-file-name" class="text-[10px] font-bold tracking-widest text-white/50 text-center px-4 z-10" data-i18n="touch_image">TOCA PARA BUSCAR IMAGEN</span>
                                <img id="preview-img-local" src="" class="hidden absolute inset-0 w-full h-full object-contain z-20 bg-black/90">
                                <input type="file" id="icon-file" accept="image/png, image/jpeg" class="hidden" onchange="previewLocal(this)">
                            </div>
                        </div>
                    </div>
                    <button type="submit" id="icon-form-submit" class="hidden"></button>
                </form>
            </div>

            <div id="tab-explorer" class="tab-content">
                <div class="flex justify-between items-end mb-6">
                    <div>
                        <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_exp">Explorador</h1>
                        <p class="text-xs text-white/50 font-light tracking-wide" data-i18n="desc_exp">Gestor de archivos interno.</p>
                    </div>
                    <div class="flex gap-1.5 flex-wrap justify-end">
                        <button onclick="addCurrentPathToShortcuts()" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white hover:bg-yellow-500/20 hover:text-yellow-400 transition-colors"><i class="fa-solid fa-star"></i></button>
                        <button onclick="promptCreateFolder()" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white transition-colors"><i class="fa-solid fa-folder-plus"></i></button>
                        <button id="btn-select-mode" onclick="toggleSelectMode()" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white transition-colors"><i class="fa-solid fa-list-check"></i></button>
                        <button onclick="if(currentExplorerPath) loadExplorerPath(currentExplorerPath)" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white transition-colors"><i class="fa-solid fa-rotate-right"></i></button>
                        <button onclick="loadExplorerPath('/')" class="w-9 h-9 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-white transition-colors"><i class="fa-solid fa-home"></i></button>
                    </div>
                </div>

                <div id="clipboard-panel" class="hidden mb-4 glass-panel rounded-xl p-3 flex justify-between items-center border-blue-500/30">
                    <div class="flex items-center gap-3 overflow-hidden pr-2">
                        <i class="fa-solid fa-scissors text-blue-400 text-sm"></i><span id="clipboard-text" class="text-[11px] text-white font-mono truncate">...</span>
                    </div>
                    <div class="flex gap-2 shrink-0">
                        <button onclick="cancelPaste()" class="text-white/50 hover:text-red-400 text-sm p-1"><i class="fa-solid fa-xmark"></i></button>
                        <button onclick="executePaste()" class="bg-white text-black px-4 py-1.5 rounded-lg text-[10px] font-bold"><i class="fa-solid fa-paste mr-1"></i> <span data-i18n="btn_paste">PEGAR</span></button>
                    </div>
                </div>

                <div id="multi-action-panel" class="hidden mb-4 glass-panel rounded-xl p-3 flex justify-between items-center border-white/20 animate-fade-in">
                    <div class="flex items-center gap-2">
                        <div class="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center"><i class="fa-solid fa-check-double text-[10px] text-blue-400"></i></div>
                        <span id="multi-select-count" class="text-[11px] text-white font-bold tracking-wide">0 seleccionados</span>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="cutSelectedItems()" class="bg-blue-500 text-white px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all"><i class="fa-solid fa-scissors mr-1"></i> <span data-i18n="opt_move_btn">MOVER</span></button>
                        <button onclick="deleteSelectedItems()" class="bg-red-500 text-white px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest shadow-lg shadow-red-500/20 active:scale-95 transition-all"><i class="fa-solid fa-trash mr-1"></i> <span data-i18n="opt_delete_btn">ELIMINAR</span></button>
                    </div>
                </div>

                <div class="glass-panel rounded-[2rem] overflow-hidden flex flex-col h-[55vh]">
                    <div class="bg-black/40 px-5 py-4 border-b border-white/10 flex items-center gap-3 shrink-0"><i class="fa-solid fa-hard-drive text-white/50"></i><span id="explorer-path-text" class="text-xs font-mono text-white/80">/</span></div>
                    <div id="explorer-shortcuts" class="hidden bg-black/60 px-4 py-2 border-b border-white/5 flex items-center gap-2 overflow-x-auto custom-scrollbar shrink-0"></div>
                    <div id="explorer-list" class="flex-1 p-2 flex flex-col gap-1 overflow-y-auto custom-scrollbar bg-black/20"><div class="text-center text-white/30 text-xs py-20" data-i18n="config_ip">Configura tu IP.</div></div>
                </div>
            </div>

            <div id="tab-payloads" class="tab-content">
                <h1 class="text-3xl font-black mb-1 text-white tracking-wide" data-i18n="tab_pay">Payloads</h1>
                <p class="text-xs text-white/50 mb-6 font-light tracking-wide" data-i18n="desc_pay">Inyección de código BinLoader.</p>
                <form id="payload-form" onsubmit="enviarPayload(event)">
                    <div class="glass-panel rounded-[2rem] p-6 mb-6">
                        <div class="flex items-center justify-between bg-black/40 border border-white/10 rounded-2xl px-5 py-4 mb-6">
                            <span class="text-[10px] font-bold tracking-widest text-white/70" data-i18n="local_port">PUERTO LOCAL</span>
                            <input type="number" id="payload-port" value="9020" class="bg-transparent text-right font-mono text-white text-lg outline-none w-20 border-b border-dashed border-white/20 focus:border-white" required>
                        </div>
                        <div class="flex gap-2 p-1 bg-black/40 rounded-[1.2rem] border border-white/5">
                            <button type="button" id="btn-pay-gallery" class="flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl bg-white text-black shadow-lg" onclick="switchPayloadSource('gallery')" data-i18n="gallery">GALERÍA</button>
                            <button type="button" id="btn-pay-local" class="flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 transition-colors" onclick="switchPayloadSource('local')" data-i18n="device">DISPOSITIVO</button>
                        </div>
                        
                        <div id="box-pay-gallery" class="mt-4 animate-fade-in"><div id="payload-gallery-container" class="min-h-[180px]"></div></div>
                        <div id="box-pay-local" class="mt-4 hidden animate-fade-in">
                            <div onclick="document.getElementById('payload-file').click()" class="w-full h-[180px] bg-black/20 rounded-[1.5rem] border border-dashed border-white/20 flex flex-col items-center justify-center cursor-pointer">
                                <div id="payload-icon-container" class="w-14 h-14 rounded-full bg-white/5 flex items-center justify-center text-white mb-3"><i class="fa-solid fa-file-code text-xl"></i></div>
                                <span id="payload-name-display" class="text-[10px] font-bold tracking-widest text-white/50 px-6 text-center" data-i18n="touch_bin">TOCA PARA BUSCAR .BIN</span>
                                <input type="file" id="payload-file" accept=".bin" class="hidden" onchange="updatePayloadName(this)">
                            </div>
                        </div>
                    </div>
                    <button type="submit" id="payload-form-submit" class="hidden"></button>
                </form>
            </div>

            <div id="tab-settings" class="tab-content pt-2 pb-24 px-6">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h2 class="text-3xl font-black text-white tracking-wider" data-i18n="tab_set">Ajustes</h2>
                        <p class="text-white/50 text-xs font-medium tracking-wide mt-1" data-i18n="desc_set">Configuración.</p>
                    </div>
                </div>

                <div class="flex flex-col w-full">
                    
                    <div class="flex items-center justify-between py-4">
                        <div class="flex items-center gap-4">
                            <i class="fa-solid fa-language text-white/50 w-5 text-center"></i>
                            <div class="flex flex-col">
                                <span class="text-sm font-bold text-white" data-i18n="set_lang_title">Idioma</span>
                                <span class="text-[10px] text-white/50" data-i18n="set_lang_desc">Cambia el idioma.</span>
                            </div>
                        </div>
                        <div class="flex bg-black/50 p-1 rounded-xl border border-white/10">
                            <button id="btn-lang-es" onclick="setLanguage('es')" class="px-4 py-2 text-[10px] font-bold rounded-lg bg-white text-black shadow-lg transition-all">ES</button>
                            <button id="btn-lang-en" onclick="setLanguage('en')" class="px-4 py-2 text-[10px] font-bold rounded-lg text-white/50 hover:text-white transition-all">EN</button>
                        </div>
                    </div>
                    <div class="h-px bg-white/10 ml-12"></div>

                    <div class="flex items-center justify-between py-4">
                        <div class="flex items-center gap-4">
                            <i class="fa-solid fa-lock text-white/50 w-5 text-center"></i>
                            <div class="flex flex-col">
                                <span class="text-sm font-bold text-white" data-i18n="set_wake_title">Pantalla Activa</span>
                                <span class="text-[10px] text-white/50" data-i18n="set_wake_desc">Evita que se apague.</span>
                            </div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" id="toggle_wakelock" class="sr-only peer" onchange="if(this.checked) requestWakeLock(); else releaseWakeLock();">
                            <div class="w-11 h-6 bg-black/50 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white/50 peer-checked:after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500 border border-white/10"></div>
                        </label>
                    </div>
                    <div class="h-px bg-white/10 ml-12"></div>

                    <div class="flex items-center justify-between py-4">
                        <div class="flex items-center gap-4">
                            <i class="fa-solid fa-message text-white/50 w-5 text-center"></i>
                            <div class="flex flex-col">
                                <span class="text-sm font-bold text-white" data-i18n="set_notif_title">Notificaciones</span>
                                <span class="text-[10px] text-white/50" data-i18n="set_notif_desc">Alertas flotantes.</span>
                            </div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" id="toggle_notifications" class="sr-only peer" checked>
                            <div class="w-11 h-6 bg-black/50 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white/50 peer-checked:after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500 border border-white/10"></div>
                        </label>
                    </div>
                    <div class="h-px bg-white/10 ml-12"></div>

                    <div class="flex items-center justify-between py-4">
                        <div class="flex items-center gap-4">
                            <i class="fa-solid fa-bell text-white/50 w-5 text-center"></i>
                            <div class="flex flex-col">
                                <span class="text-sm font-bold text-white" data-i18n="set_sound_title">Sonidos UI</span>
                                <span class="text-[10px] text-white/50" data-i18n="set_sound_desc">Efectos interactivos.</span>
                            </div>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" id="toggle_sound" class="sr-only peer" checked>
                            <div class="w-11 h-6 bg-black/50 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white/50 peer-checked:after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500 border border-white/10"></div>
                        </label>
                    </div>
                    <div class="h-px bg-white/10 ml-12"></div>

                    <div class="flex items-center justify-between py-4">
                        <div class="flex items-center gap-4 w-full">
                            <i class="fa-solid fa-volume-low text-white/50 w-5 text-center shrink-0"></i>
                            <div class="flex flex-col flex-1 pr-4">
                                <span class="text-sm font-bold text-white block" data-i18n="set_vol_title">Volumen</span>
                                <span class="text-[10px] text-white/50 mb-2" data-i18n="set_vol_desc">Ajusta la intensidad.</span>
                                <input type="range" id="volume_slider" min="0" max="1" step="0.1" value="0.5" class="w-full h-1 bg-white/20 rounded-lg appearance-none cursor-pointer" onchange="AudioEngine.updateVol(this.value)">
                            </div>
                        </div>
                    </div>
                    <div class="h-px bg-white/10 ml-12"></div>

                    <div class="flex items-center justify-between py-4 mb-2">
                        <div class="flex items-center gap-4">
                            <i class="fa-solid fa-broom text-red-500/80 w-5 text-center"></i>
                            <div class="flex flex-col">
                                <span class="text-sm font-bold text-white" data-i18n="set_temp_title">Limpiar Temporales</span>
                                <span class="text-[10px] text-white/50" data-i18n="set_temp_desc">Libera caché del servidor.</span>
                            </div>
                        </div>
                        <button onclick="limpiarTemporales()" class="w-12 h-12 rounded-xl bg-red-500/10 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all border border-red-500/20 shadow-[0_0_15px_rgba(239,68,68,0.2)] active:scale-95 shrink-0">
                            <i class="fa-solid fa-trash-can text-lg"></i>
                        </button>
                    </div>

                </div>

                <div class="flex flex-col items-center justify-center mt-6 mb-10 opacity-50">
                    <i class="fa-brands fa-playstation text-[3.5rem] mb-4 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]"></i>
                    <span class="text-[12px] font-bold tracking-widest text-white mb-1">GoldHen Manager v2.0</span>
                    <span class="footer-sig text-[10px] font-mono text-white/70 tracking-widest"></span>
                </div>
            </div>
        </main>

        <div class="floating-btn-global floating-hidden" id="floating-btn-ftp">
            <button onclick="document.getElementById('ftp-form-submit').click()" class="w-full btn-ps5-primary rounded-[1.5rem] py-5 font-black tracking-widest text-sm flex items-center justify-center gap-3"><i class="fa-brands fa-playstation text-xl"></i> <span data-i18n="btn_send_files">ENVIAR ARCHIVOS</span></button>
        </div>
        <div class="floating-btn-global floating-hidden" id="floating-btn-rpi">
            <button onclick="iniciarColaInstalacionRPI()" class="w-full btn-ps5-primary !bg-[#fbbf24] !text-black !shadow-[0_0_20px_rgba(251,191,36,0.3)] rounded-[1.5rem] py-5 font-black tracking-widest text-sm flex items-center justify-center gap-3"><i class="fa-solid fa-download text-xl"></i> <span id="rpi-install-text" data-i18n="btn_install_ps4">INSTALAR EN PS4</span></button>
        </div>
        <div class="floating-btn-global floating-hidden" id="floating-btn-aplicar">
            <button onclick="ejecutarFormIconos()" class="w-full btn-ps5-primary rounded-[1.5rem] py-5 font-black tracking-widest text-sm flex items-center justify-center gap-3"><i class="fa-solid fa-wand-magic-sparkles text-lg"></i> <span data-i18n="btn_apply_art">APLICAR PORTADA</span></button>
        </div>
        <div class="floating-btn-global floating-hidden" id="floating-btn-payload">
            <button onclick="document.getElementById('payload-form-submit').click()" class="w-full btn-ps5-primary rounded-[1.5rem] py-5 font-black tracking-widest text-sm flex items-center justify-center gap-3"><i class="fa-solid fa-bolt text-lg"></i> <span data-i18n="btn_inject">INYECTAR PAYLOAD</span></button>
        </div>

        <nav class="dock-nav">
            <button class="dock-item active" onclick="switchTab('tab-biblioteca', this, 0)" title="Biblioteca"><i class="fa-solid fa-gamepad"></i></button>
            <button class="dock-item" onclick="switchTab('tab-ftp', this, 1)" title="Transferir"><i class="fa-solid fa-exchange-alt"></i></button>
            <button class="dock-item" onclick="switchTab('tab-icons', this, 2)" title="Portadas"><i class="fa-solid fa-palette"></i></button>
            <button class="dock-item" onclick="switchTab('tab-explorer', this, 3)" title="Explorar"><i class="fa-solid fa-folder-tree"></i></button>
            <button class="dock-item" onclick="switchTab('tab-payloads', this, 4)" title="Payloads"><i class="fa-solid fa-microchip"></i></button>
            <button class="dock-item" onclick="switchTab('tab-settings', this, 5)" title="Ajustes"><i class="fa-solid fa-gear"></i></button>
        </nav>
    </div>

    <div id="overlay-global" class="overlay-sheet" onclick="cerrarTodo()"></div>
    <div id="overlay-sheet" class="overlay-sheet" onclick="closeItemOptions()"></div>

    <div id="file-viewer-modal" class="hidden fixed inset-0 z-[250] bg-black/95 flex flex-col transition-opacity duration-300 opacity-0">
        <div class="flex justify-between items-center p-4 border-b border-white/10 bg-black/50 backdrop-blur-md">
            <span id="file-viewer-title" class="text-white font-bold text-sm truncate pr-4">Archivo...</span>
            <button onclick="closeFileViewer()" class="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-red-500 transition-colors"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div id="file-viewer-content" class="flex-1 overflow-auto p-4 custom-scrollbar flex items-center justify-center relative"></div>
    </div>

    <div id="bottom-sheet" class="bottom-sheet">
        <div class="w-12 h-1 bg-white/20 rounded-full mx-auto mt-3 mb-2"></div>
        <div class="px-6 pb-6">
            <h4 id="sheet-title" class="text-white font-bold text-sm mb-4 truncate border-b border-white/10 pb-4">...</h4>
            <div class="flex flex-col gap-2">
                <button id="btn-view-file" onclick="viewCurrentFile()" class="hidden flex items-center gap-4 p-4 rounded-2xl hover:bg-blue-500/20 text-blue-400 text-left border border-blue-500/20 mb-2"><i class="fa-solid fa-eye w-5 text-center"></i> <span class="font-bold text-sm" data-i18n="opt_view">Ver Archivo</span></button>
                <button id="btn-download-file" onclick="downloadCurrentFile()" class="hidden flex items-center gap-4 p-4 rounded-2xl hover:bg-green-500/20 text-green-400 text-left border border-green-500/20 mb-2"><i class="fa-solid fa-download w-5 text-center"></i> <span class="font-bold text-sm" data-i18n="opt_download">Descargar al celular</span></button>
                <button onclick="renameCurrentItem()" class="flex items-center gap-4 p-4 rounded-2xl hover:bg-white/10 text-white text-left"><i class="fa-solid fa-pen w-5 text-center text-white/50"></i> <span class="font-medium text-sm" data-i18n="opt_rename">Renombrar</span></button>
                <button onclick="cutCurrentItem()" class="flex items-center gap-4 p-4 rounded-2xl hover:bg-white/10 text-white text-left"><i class="fa-solid fa-scissors w-5 text-center text-white/50"></i> <span class="font-medium text-sm" data-i18n="opt_move">Mover</span></button>
                <button onclick="deleteCurrentItem()" class="flex items-center gap-4 p-4 rounded-2xl hover:bg-red-500/20 text-red-400 text-left mt-2 border border-red-500/20"><i class="fa-solid fa-trash w-5 text-center"></i> <span class="font-bold text-sm" data-i18n="opt_delete">Eliminar</span></button>
            </div>
        </div>
    </div>

    <div id="sheet-opciones" class="bottom-sheet z-[60]">
        <div class="w-12 h-1 bg-white/20 rounded-full mx-auto mt-3 mb-2"></div>
        <div class="px-6 pb-6 pt-2">
            
            <div class="flex gap-4 mb-5 border-b border-white/10 pb-5">
                <img id="opt-game-img" src="" class="w-16 h-16 rounded-xl object-cover border border-white/10 shadow-lg shrink-0 bg-black/50">
                <div class="flex flex-col justify-center overflow-hidden w-full">
                    <h4 id="opt-game-title" class="text-white font-black text-sm uppercase tracking-wider truncate">...</h4>
                    <div class="flex items-center gap-2 mt-1">
                        <span id="opt-game-cusa" class="text-[9px] text-blue-400 font-mono font-bold tracking-widest bg-blue-500/10 px-1.5 py-0.5 rounded border border-blue-500/20">...</span>
                        <span id="opt-game-version" class="text-[9px] text-white/50 font-mono bg-white/5 px-1.5 py-0.5 rounded border border-white/10">...</span>
                    </div>
                    <div class="flex items-center justify-between mt-2.5">
                        <div class="flex items-center gap-1.5 text-[10px] text-white/60">
                            <i class="fa-solid fa-hard-drive"></i> <span id="opt-game-size" class="font-mono font-bold">...</span>
                        </div>
                        <div class="flex items-center gap-1.5 text-[10px] text-white/40">
                            <i class="fa-solid fa-folder-tree"></i> <span id="opt-game-loc" class="font-mono truncate max-w-[100px]">...</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-black/20 p-3 rounded-xl border border-white/5 mb-5">
                <span class="text-[8px] font-black text-white/40 uppercase tracking-widest block mb-2" data-i18n="move_category">Mover a categoría:</span>
                <div id="selector-categorias" class="flex gap-2 overflow-x-auto custom-scrollbar pb-1"></div>
            </div>

            <div class="flex flex-col gap-1">
                <button onclick="iniciarBackupSaves()" class="w-full flex items-center gap-4 p-3.5 rounded-xl hover:bg-white/10 transition-colors group">
                    <i class="fa-solid fa-floppy-disk text-white group-hover:scale-110 transition-transform w-5 text-center text-lg"></i>
                    <span class="text-xs font-bold text-white tracking-wide" data-i18n="opt_backup_saves">Backup de Partidas (Saves)</span>
                </button>
                <button onclick="abrirGaleriaJuego()" class="w-full flex items-center gap-4 p-3.5 rounded-xl hover:bg-white/10 transition-colors group">
                    <i class="fa-solid fa-images text-white group-hover:scale-110 transition-transform w-5 text-center text-lg"></i>
                    <span class="text-xs font-bold text-white tracking-wide" data-i18n="opt_gallery_caps">Galería de Capturas</span>
                </button>
                <button onclick="simularRedireccionModding()" class="w-full flex items-center gap-4 p-3.5 rounded-xl hover:bg-white/10 transition-colors group">
                    <i class="fa-solid fa-wand-magic-sparkles text-white group-hover:scale-110 transition-transform w-5 text-center text-lg"></i>
                    <span class="text-xs font-bold text-white tracking-wide" data-i18n="opt_modding">Personalizar Portada</span>
                </button>
                <button onclick="abrirMenuDLCs()" class="w-full flex items-center gap-4 p-3.5 rounded-xl hover:bg-white/10 transition-colors group">
                    <i class="fa-solid fa-puzzle-piece text-white group-hover:scale-110 transition-transform w-5 text-center text-lg"></i>
                    <span class="text-xs font-bold text-white tracking-wide" data-i18n="opt_manage_dlc">Gestionar DLCs / Updates</span>
                </button>
                
                <div class="h-px bg-white/10 my-1"></div>
                
                <button onclick="borrarJuegoDeBiblioteca()" class="w-full flex items-center gap-4 p-3.5 rounded-xl hover:bg-red-500/10 transition-colors group border border-transparent hover:border-red-500/30">
                    <i class="fa-solid fa-trash-can text-red-500 group-hover:scale-110 transition-transform w-5 text-center text-lg"></i>
                    <span class="text-xs font-bold text-red-500 tracking-wide" data-i18n="opt_remove_lib">Quitar de Biblioteca</span>
                </button>
            </div>
        </div>
    </div>

    <div id="sheet-dlcs" class="bottom-sheet z-[60]">
        <div class="w-12 h-1 bg-white/20 rounded-full mx-auto mt-3 mb-2"></div>
        <div class="px-6 pb-6">
            <div class="flex justify-between items-center mb-4 border-b border-white/10 pb-4">
                <div>
                    <h4 class="text-white font-black text-lg" data-i18n="dlc_manager_title">Gestor de DLCs & Updates</h4>
                    <span id="dlc-game-cusa" class="text-[10px] text-green-400 font-mono tracking-widest">...</span>
                </div>
                <button onclick="volverAOpcionesDesde('sheet-dlcs')" class="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/50 hover:text-white hover:bg-white/20 transition-colors"><i class="fa-solid fa-arrow-left"></i></button>
            </div>
            <div id="dlc-list-container" class="flex flex-col gap-3 max-h-[50vh] overflow-y-auto custom-scrollbar pr-1 pb-4">
            </div>
        </div>
    </div>

    <div id="sheet-capturas" class="bottom-sheet z-[60]">
        <div class="w-12 h-1 bg-white/20 rounded-full mx-auto mt-3 mb-2"></div>
        <div class="px-6 pb-6">
            <div class="flex justify-between items-center mb-4 border-b border-white/10 pb-4">
                <div>
                    <h4 class="text-white font-black text-lg" data-i18n="caps_ps4_title">Capturas PS4</h4>
                    <span id="capturas-game-cusa" class="text-[10px] text-purple-400 font-mono tracking-widest">...</span>
                </div>
                <button onclick="volverAOpcionesDesde('sheet-capturas')" class="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/50 hover:text-white hover:bg-white/20 transition-colors"><i class="fa-solid fa-arrow-left"></i></button>
            </div>
            <div id="capturas-grid" class="grid grid-cols-2 gap-3 max-h-[60vh] overflow-y-auto custom-scrollbar pr-1 pb-4">
            </div>
        </div>
    </div>

    <div id="custom-modal" class="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] hidden flex items-center justify-center transition-opacity opacity-0 px-4">
        <div id="modal-card" class="bg-[#0b0c10] border border-white/10 p-8 rounded-[2rem] shadow-2xl w-full max-w-sm text-center transform scale-95 transition-transform relative overflow-hidden">
            <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 via-purple-600 to-blue-600"></div>
            <div id="modal-icon" class="w-20 h-20 mx-auto rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(37,99,235,0.2)]"></div>
            <h3 id="modal-title" class="text-white font-black text-xl tracking-widest mb-2 uppercase" data-i18n="modal_loading">CARGANDO</h3>
            <p id="modal-text" class="text-white/60 text-xs font-medium px-4 leading-relaxed h-10 overflow-hidden text-ellipsis" data-i18n="modal_wait">Por favor espera...</p>
            <div id="modal-progress-container" class="mt-8 hidden">
                <div class="flex justify-between text-[10px] text-white/50 font-bold mb-2 tracking-wider px-1">
                    <span id="modal-percentage">0%</span>
                    <span id="modal-bytes">0 / 0 GB</span>
                </div>
                <div class="w-full bg-white/5 rounded-full h-2.5 overflow-hidden border border-white/10 p-0.5">
                    <div id="modal-progress-bar" class="bg-gradient-to-r from-blue-500 to-purple-500 h-full rounded-full transition-all duration-300 w-0 relative overflow-hidden">
                        <div class="absolute inset-0 bg-white/20 animate-[shimmer_1s_infinite] -skew-x-12"></div>
                    </div>
                </div>
                <div class="flex justify-between text-[9px] text-white/40 mt-3 font-mono tracking-widest px-1">
                    <span id="modal-speed"><i class="fa-solid fa-bolt text-white/20"></i> -- MB/s</span>
                    <span id="modal-eta"><i class="fa-solid fa-clock text-white/20"></i> ETA: --:--</span>
                </div>
            </div>
            <div id="modal-controls" class="mt-8 flex gap-3 hidden">
                <button id="modal-cancel-btn" onclick="cancelarEnvio()" class="flex-1 bg-white/5 hover:bg-red-500/20 border border-white/10 hover:border-red-500/50 text-white/60 hover:text-red-400 rounded-2xl py-3.5 font-bold text-[10px] tracking-widest transition-all active:scale-95" data-i18n="modal_cancel">CANCELAR</button>
                <button id="modal-action-btn" onclick="togglePauseResume()" class="flex-1 bg-white/10 hover:bg-white/20 border border-white/10 text-white rounded-2xl py-3.5 font-bold text-[10px] tracking-widest transition-all active:scale-95" data-i18n="modal_pause">PAUSAR</button>
            </div>
            <button id="modal-close-btn" onclick="closeCustomModal()" class="mt-8 w-full bg-white/10 hover:bg-white/20 border border-white/10 text-white rounded-2xl py-3.5 font-bold text-[10px] tracking-widest transition-all active:scale-95 hidden" data-i18n="modal_close">CERRAR</button>
        </div>
    </div>

    <div id="ps5-dialog" class="fixed inset-0 bg-black/90 backdrop-blur-md z-[110] hidden flex items-center justify-center transition-opacity opacity-0 px-4">
        <div id="ps5-dialog-card" class="bg-[#111] border border-white/10 p-6 rounded-3xl shadow-2xl w-full max-w-sm transform scale-95 transition-transform">
            <div class="flex items-start gap-4 mb-4">
                <div id="ps5-dialog-icon" class="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center shrink-0"></div>
                <div>
                    <h3 id="ps5-dialog-title" class="text-white font-black text-sm tracking-widest uppercase mb-1">Título</h3>
                    <p id="ps5-dialog-text" class="text-white/60 text-[11px] leading-relaxed">Mensaje</p>
                </div>
            </div>
            <input type="text" id="ps5-dialog-input" class="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white text-xs mb-6 hidden focus:outline-none focus:border-blue-500 transition-colors" autocomplete="off">
            <div class="flex gap-2 mt-6">
                <button id="ps5-dialog-btn-cancel" class="flex-1 bg-white/5 hover:bg-white/10 text-white/60 rounded-xl py-3.5 font-bold text-[10px] tracking-widest transition-all hidden" data-i18n="modal_cancel">CANCELAR</button>
                <button id="ps5-dialog-btn-confirm" class="flex-1 bg-white text-black rounded-xl py-3.5 font-bold text-[10px] tracking-widest transition-all shadow-lg active:scale-95" data-i18n="modal_accept">ACEPTAR</button>
            </div>
        </div>
    </div>


<script>
        // ==========================================
        // PROTECCIÓN ANTI-CURIOSOS Y FIRMA
        // ==========================================
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('keydown', e => { 
            if(e.keyCode === 123 || (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || (e.ctrlKey && e.keyCode === 85)) { 
                e.preventDefault(); return false; 
            } 
        });
        console.log('%c' + atob('R29sZEhlbiBNYW5hZ2VyIFYyLjAgfCBEZXZlbG9wZWQgYnkgU2VCYVM='), 'color:#3b82f6; font-size:18px; font-weight:900; text-shadow: 0 0 10px rgba(59,130,246,0.5);');

        // ==========================================
        // PARCHE VISUAL: ELIMINA SUPERPOSICIONES Y EXPANDE LISTAS
        // ==========================================
        document.head.insertAdjacentHTML('beforeend', `<style>
            /* 1. Botón Flotante y Dock Sólidos (Ocultan lo de atrás) */
            .btn-ps5-primary { background: #ffffff !important; box-shadow: 0 -5px 25px rgba(0,0,0,0.8) !important; }
            .dock-nav { background: #0b0c10 !important; border: 1px solid rgba(255,255,255,0.05) !important; box-shadow: 0 -15px 40px rgba(0,0,0,0.95) !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
            
            /* 2. Expansión y Relleno de las Listas para que se vea más y suba por encima del botón */
            #rpi-pkg-list { max-height: 65vh !important; padding-bottom: 140px !important; }
            #explorer-list { padding-bottom: 140px !important; }
            .gallery-grid-fix { max-height: 65vh !important; padding-bottom: 140px !important; }
            .pb-biblioteca-fix { padding-bottom: 140px !important; }
            
            /* 3. Marquesina para Títulos Largos */
            .title-marquee-box { width: 100%; overflow: hidden; white-space: nowrap; }
            .title-marquee-text { display: inline-block; padding-left: 10%; animation: scroll-marquee 8s linear infinite; }
            @keyframes scroll-marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-100%); } }
        </style>`);

        // ==========================================
        // 1. INTRO PS5 & PARTICULAS
        // ==========================================
        const canvas = document.getElementById('stardust'); const ctx = canvas.getContext('2d'); let particles = []; let isExploding = false;
        function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
        window.addEventListener('resize', resize); resize();
        class Particle {
            constructor() { this.reset(); }
            reset() { this.x = Math.random() * canvas.width; this.y = Math.random() * canvas.height; this.size = Math.random() * 1.5 + 0.1; this.speedX = (Math.random() - 0.5) * 0.4; this.speedY = (Math.random() - 0.5) * 0.4; this.opacity = Math.random() * 0.5; }
            update() { if (isExploding) { let dx = this.x - canvas.width / 2; let dy = this.y - canvas.height / 2; this.x += dx * 0.08; this.y += dy * 0.08; this.size *= 1.02; this.opacity -= 0.015; } else { this.x += this.speedX; this.y += this.speedY; if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) this.reset(); } }
            draw() { ctx.fillStyle = `rgba(255, 255, 255, ${Math.max(0, this.opacity)})`; ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2); ctx.fill(); }
        }
        for (let i = 0; i < 150; i++) particles.push(new Particle());
        function animateParticles() { ctx.clearRect(0, 0, canvas.width, canvas.height); particles.forEach(p => { p.update(); p.draw(); }); if(!isExploding || particles.some(p => p.opacity > 0)) requestAnimationFrame(animateParticles); }

        // ==========================================
        // 1.5 INSTALACIÓN PWA
        // ==========================================
        let deferredPrompt;
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault(); deferredPrompt = e;
            if(!localStorage.getItem('ps4_pwa_dismissed')) { const pwaContainer = document.getElementById('install-pwa-container'); if(pwaContainer) pwaContainer.classList.remove('hidden'); }
        });
        function installPWA() {
            const pwaContainer = document.getElementById('install-pwa-container'); if(pwaContainer) pwaContainer.classList.add('hidden');
            if (deferredPrompt) { deferredPrompt.prompt(); deferredPrompt.userChoice.then((choiceResult) => { if (choiceResult.outcome === 'accepted') localStorage.setItem('ps4_pwa_dismissed', 'true'); deferredPrompt = null; }); }
        }
        function dismissPWA() { const pwaContainer = document.getElementById('install-pwa-container'); if(pwaContainer) pwaContainer.classList.add('hidden'); localStorage.setItem('ps4_pwa_dismissed', 'true'); }

        // ==========================================
        // 2. SISTEMA MULTI-IDIOMA TOTAL & AUDIO 
        // ==========================================
        const i18n = {
            es: {
                ps4_detected: "PS4 DETECTADA", ps4_disconnected: "DESCONECTADA", searching: "BUSCANDO...",
                tab_transfer: "Transferir", desc_transfer: "Envía juegos o aplicaciones a tu consola.",
                dest_routes: '<i class="fa-solid fa-folder-open mr-2"></i>RUTAS DE DESTINO',
                files_pkg: '<i class="fa-solid fa-file-circle-plus mr-2"></i>ARCHIVOS (PKG/BIN)',
                touch_select: "TOCA PARA SELECCIONAR", btn_send_files: "ENVIAR ARCHIVOS",
                tab_mod: "Modding", desc_mod: "Personaliza el arte de tu biblioteca.",
                gallery: "GALERÍA", backups: "BACKUPS", import: "IMPORTAR", local: "LOCAL",
                btn_apply_art: "APLICAR PORTADA", import_desc: "Pega un link directo para descargar a tu galería.",
                btn_import: "INICIAR IMPORTACIÓN", touch_image: "TOCA PARA BUSCAR IMAGEN",
                tab_exp: "Explorador", desc_exp: "Gestor de archivos interno.",
                btn_paste: "PEGAR", btn_delete: "ELIMINAR", config_ip: "Configura tu IP.",
                tab_pay: "Payloads", desc_pay: "Inyección de código BinLoader.",
                local_port: "PUERTO LOCAL", device: "DISPOSITIVO", touch_bin: "TOCA PARA BUSCAR .BIN", btn_inject: "INYECTAR PAYLOAD",
                tab_set: "Ajustes", desc_set: "Configuración.",
                install_app: "Instalar App", install_desc: "Añadir a pantalla de inicio", btn_install: "INSTALAR",
                opt_rename: "Renombrar", opt_move: "Mover", opt_delete: "Eliminar",
                modal_pause: "PAUSAR", modal_close: "CERRAR", modal_cancel: "CANCELAR", modal_accept: "ACEPTAR",
                j_err_ip: "FALTA IP", j_err_ip_m: "Escribe la IP.", j_err_file: "FALTA ARCHIVO", j_err_file_m: "Elige un archivo.",
                j_prep: "PREPARANDO", j_prep_m: "Analizando...", j_resume: "REANUDAR", j_resume_m: "Reanudar subida?",
                j_exist: "EXISTE", j_exist_m: "Ya existe. ¿Sobrescribir?", j_cancel: "CANCELADO", j_cancel_m: "Abortado.",
                j_comp: "COMPLETADO", j_comp_m: "Éxito.", j_inj: "INYECCIÓN", j_inj_m: "Conectando...", j_succ: "ÉXITO", j_err: "ERROR",
                j_del_sel: "ELIMINAR SELECCIÓN", j_del_m1: "¿Eliminar", j_elem: "elementos",
                j_warn: "⚠️ ADVERTENCIA", j_warn_m: "Esta acción NO se puede deshacer.",
                j_ren: "RENOMBRAR", j_ren_m: "Nuevo nombre:", j_del1: "¿Eliminar",
                j_new_fold: "NUEVA CARPETA", j_new_fold_m: "Nombre:", j_scan_fail: "FALLO", j_scan_fail_m: "PS4 no encontrada.",
                j_del_route: "ELIMINAR RUTA", j_del_route_m: "¿Quitar ruta?", j_files_sel: "ARCHIVOS", j_empty: "Vacía", j_sel: "seleccionados",
                empty_gal_title: "Coloca tus imágenes <b class='text-white/70'>512x512 .png</b> dentro de la carpeta <br><span class='font-mono text-white/70 bg-black/50 px-1.5 py-0.5 rounded'>htdocs/{folder}/</span><br>en tu Android.",
                empty_pay_title: "Coloca tus archivos <b class='text-white/70'>.bin</b> en la carpeta <br><span class='font-mono text-white/70 bg-black/50 px-1.5 py-0.5 rounded'>htdocs/payloads/</span>.",
                del_all: "BORRAR TODAS", tab_biblio: "Biblioteca", titles_installed: "TÍTULOS INSTALADOS", search_placeholder: "Buscar juego o app...",
                rpi_sender: "RPI SENDER", ftp_classic: "FTP CLÁSICO", games_on_phone: "JUEGOS EN EL CELULAR",
                title_id: "TITLE ID", opt_view: "Ver Archivo", opt_download: "Descargar al celular", move_category: "Mover a categoría:",
                opt_backup_saves: "Backup de Partidas (Saves)", opt_gallery_caps: "Galería de Capturas", opt_modding: "Personalizar Portada",
                opt_manage_dlc: "Gestionar DLCs / Updates", opt_remove_lib: "Quitar de Biblioteca", dlc_manager_title: "Gestor de DLCs & Updates",
                caps_ps4_title: "Capturas PS4", modal_loading: "CARGANDO", modal_wait: "Por favor espera...",
                opt_move_btn: "MOVER", opt_delete_btn: "ELIMINAR", btn_install_ps4: "INSTALAR EN PS4",
                set_lang_title: "Idioma", set_lang_desc: "Cambia el idioma.", set_wake_title: "Pantalla Activa", set_wake_desc: "Evita que se apague.",
                set_notif_title: "Notificaciones", set_notif_desc: "Alertas flotantes.", set_sound_title: "Sonidos UI", set_sound_desc: "Efectos interactivos.",
                set_vol_title: "Volumen", set_vol_desc: "Ajusta la intensidad.",
                set_temp_title: "Limpiar Temporales", set_temp_desc: "Libera caché del servidor.", ip_placeholder: "IP PS4 (192.168.x.x)"
            },
            en: {
                ps4_detected: "PS4 DETECTED", ps4_disconnected: "DISCONNECTED", searching: "SEARCHING...",
                tab_transfer: "Transfer", desc_transfer: "Send games or apps to your console.",
                dest_routes: '<i class="fa-solid fa-folder-open mr-2"></i>DESTINATION PATHS',
                files_pkg: '<i class="fa-solid fa-file-circle-plus mr-2"></i>FILES (PKG/BIN)',
                touch_select: "TAP TO SELECT", btn_send_files: "SEND FILES",
                tab_mod: "Modding", desc_mod: "Customize your library artwork.",
                gallery: "GALLERY", backups: "BACKUPS", import: "IMPORT", local: "LOCAL",
                btn_apply_art: "APPLY ARTWORK", import_desc: "Paste a direct image link to download.",
                btn_import: "START IMPORT", touch_image: "TAP TO BROWSE IMAGE",
                tab_exp: "Explorer", desc_exp: "Internal file manager.",
                btn_paste: "PASTE", btn_delete: "DELETE", config_ip: "Set your IP to explore.",
                tab_pay: "Payloads", desc_pay: "BinLoader code injection.",
                local_port: "LOCAL PORT", device: "DEVICE", touch_bin: "TAP TO BROWSE .BIN", btn_inject: "INJECT PAYLOAD",
                tab_set: "Settings", desc_set: "System configuration.",
                install_app: "Install App", install_desc: "Add to home screen", btn_install: "INSTALL",
                opt_rename: "Rename", opt_move: "Move", opt_delete: "Delete",
                modal_pause: "PAUSE", modal_close: "CLOSE", modal_cancel: "CANCEL", modal_accept: "ACCEPT",
                j_err_ip: "MISSING IP", j_err_ip_m: "Please type your PS4 IP.", j_err_file: "MISSING FILE", j_err_file_m: "Choose a file.",
                j_prep: "PREPARING", j_prep_m: "Analyzing...", j_resume: "RESUME", j_resume_m: "Resume upload?",
                j_exist: "FILE EXISTS", j_exist_m: "already exists.<br>Overwrite?", j_cancel: "CANCELED", j_cancel_m: "Transfer aborted.",
                j_comp: "COMPLETED", j_comp_m: "Success.", j_inj: "INJECTING", j_inj_m: "Connecting...", j_succ: "SUCCESS", j_err: "ERROR",
                j_del_sel: "DELETE SELECTION", j_del_m1: "Delete", j_elem: "items",
                j_warn: "⚠️ FINAL WARNING", j_warn_m: "This cannot be undone.",
                j_ren: "RENAME", j_ren_m: "Enter a new name:", j_del1: "Delete",
                j_new_fold: "NEW FOLDER", j_new_fold_m: "Name:", j_scan_fail: "SCAN FAILED", j_scan_fail_m: "PS4 not found.",
                j_del_route: "DELETE PATH", j_del_route_m: "Remove path?", j_files_sel: "FILES", j_empty: "Empty", j_sel: "selected",
                empty_gal_title: "Place your <b class='text-white/70'>512x512 .png</b> images inside the folder <br><span class='font-mono text-white/70 bg-black/50 px-1.5 py-0.5 rounded'>htdocs/{folder}/</span><br>in your Android.",
                empty_pay_title: "Place your <b class='text-white/70'>.bin</b> files inside the folder <br><span class='font-mono text-white/70 bg-black/50 px-1.5 py-0.5 rounded'>htdocs/payloads/</span>.",
                del_all: "DELETE ALL", tab_biblio: "Library", titles_installed: "INSTALLED TITLES", search_placeholder: "Search game or app...",
                rpi_sender: "RPI SENDER", ftp_classic: "CLASSIC FTP", games_on_phone: "GAMES ON PHONE",
                title_id: "TITLE ID", opt_view: "View File", opt_download: "Download to phone", move_category: "Move to category:",
                opt_backup_saves: "Save Game Backup", opt_gallery_caps: "Screenshots Gallery", opt_modding: "Customize Cover",
                opt_manage_dlc: "Manage DLCs / Updates", opt_remove_lib: "Remove from Library", dlc_manager_title: "DLC & Updates Manager",
                caps_ps4_title: "PS4 Screenshots", modal_loading: "LOADING", modal_wait: "Please wait...",
                opt_move_btn: "MOVE", opt_delete_btn: "DELETE", btn_install_ps4: "INSTALL ON PS4",
                set_lang_title: "Language", set_lang_desc: "Change language.", set_wake_title: "Keep Screen On", set_wake_desc: "Prevents device sleep.",
                set_notif_title: "Notifications", set_notif_desc: "Floating alerts.", set_sound_title: "UI Sounds", set_sound_desc: "Interactive effects.",
                set_vol_title: "Volume", set_vol_desc: "Adjust intensity.",
                set_temp_title: "Clear Temp Files", set_temp_desc: "Free up server cache.", ip_placeholder: "PS4 IP (192.168.x.x)"
            }
        };
        let currentLang = 'es';
        function setLanguage(lang) { 
            currentLang = lang; localStorage.setItem('ps4_ui_lang', lang); 
            const btnEs = document.getElementById('btn-lang-es'); const btnEn = document.getElementById('btn-lang-en'); 
            if(lang === 'es') { if(btnEs) btnEs.className = "px-4 py-2 text-[10px] font-bold rounded-lg bg-white text-black shadow-lg transition-all"; if(btnEn) btnEn.className = "px-4 py-2 text-[10px] font-bold rounded-lg text-white/50 hover:text-white transition-all"; } 
            else { if(btnEn) btnEn.className = "px-4 py-2 text-[10px] font-bold rounded-lg bg-white text-black shadow-lg transition-all"; if(btnEs) btnEs.className = "px-4 py-2 text-[10px] font-bold rounded-lg text-white/50 hover:text-white transition-all"; } 
            document.querySelectorAll('[data-i18n]').forEach(el => { const key = el.getAttribute('data-i18n'); if (i18n[lang][key]) el.innerHTML = i18n[lang][key]; }); 
            document.querySelectorAll('[data-i18n-placeholder]').forEach(el => { const key = el.getAttribute('data-i18n-placeholder'); if (i18n[lang][key]) el.setAttribute('placeholder', i18n[lang][key]); });
            if (typeof actualizarGaleria === 'function') actualizarGaleria(); if (typeof actualizarPayloads === 'function') actualizarPayloads(); 
        }
        function t(key) { return i18n[currentLang][key] || key; }

        const AudioEngine = {
            ctx: null, globalVol: 0.5,
            init: function() { if (!this.ctx) { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } if (this.ctx.state === 'suspended') this.ctx.resume(); },
            loadSettings: function() { 
                let savedVol = localStorage.getItem('ps4_ui_vol'); if(savedVol !== null) { this.globalVol = parseFloat(savedVol); let slider = document.getElementById('volume_slider'); if(slider) slider.value = this.globalVol; } 
                let snd = localStorage.getItem('ps4_ui_sound'); let t = document.getElementById('toggle_sound'); if(t && snd !== null) { t.checked = (snd === 'true'); }
            },
            updateVol: function(v) { this.globalVol = parseFloat(v); localStorage.setItem('ps4_ui_vol', this.globalVol); this.playClick(); },
            playTone: function(freq, type, duration, vol=0.5) { const t = document.getElementById('toggle_sound'); if (t && !t.checked) return; this.init(); if (!this.ctx) return; const finalVol = vol * this.globalVol; if (finalVol <= 0) return; const osc = this.ctx.createOscillator(); const gain = this.ctx.createGain(); osc.type = type; osc.frequency.setValueAtTime(freq, this.ctx.currentTime); gain.gain.setValueAtTime(0, this.ctx.currentTime); gain.gain.linearRampToValueAtTime(finalVol, this.ctx.currentTime + 0.02); gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration); osc.connect(gain); gain.connect(this.ctx.destination); osc.start(); osc.stop(this.ctx.currentTime + duration); },
            playClick: function() { const t = document.getElementById('toggle_sound'); if (t && !t.checked) return; this.init(); if (!this.ctx) return; const finalVol = 0.8 * this.globalVol; if (finalVol <= 0) return; const duration = 0.04; const osc = this.ctx.createOscillator(); const gain = this.ctx.createGain(); osc.type = 'sine'; osc.frequency.setValueAtTime(1800, this.ctx.currentTime); osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + duration); gain.gain.setValueAtTime(0, this.ctx.currentTime); gain.gain.linearRampToValueAtTime(finalVol, this.ctx.currentTime + 0.002); gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration); osc.connect(gain); gain.connect(this.ctx.destination); osc.start(); osc.stop(this.ctx.currentTime + duration); },     
            playSuccess: function() { this.playTone(523.25, 'sine', 0.8, 0.6); setTimeout(() => this.playTone(659.25, 'sine', 0.8, 0.6), 80); setTimeout(() => this.playTone(783.99, 'sine', 1.2, 0.7), 160); },
            playError: function() { this.playTone(200, 'triangle', 0.2, 0.9); setTimeout(() => this.playTone(200, 'triangle', 0.3, 0.9), 180); },
            playDisconnect: function() { this.playTone(350, 'triangle', 0.3, 0.7); setTimeout(() => this.playTone(200, 'sawtooth', 0.5, 0.8), 250); },
            playToast: function() { this.playTone(750, 'sine', 0.1, 0.4); setTimeout(() => this.playTone(950, 'sine', 0.2, 0.5), 100); }, 
            playPS5Boot: function() { const t = document.getElementById('toggle_sound'); if (t && !t.checked) return; this.init(); if (!this.ctx) return; const freqs = [150, 225, 300, 450]; freqs.forEach((freq, i) => { const osc = this.ctx.createOscillator(); const gain = this.ctx.createGain(); osc.type = i % 2 === 0 ? 'sine' : 'triangle'; osc.frequency.setValueAtTime(freq, this.ctx.currentTime); gain.gain.setValueAtTime(0, this.ctx.currentTime); gain.gain.linearRampToValueAtTime(0.12 * this.globalVol, this.ctx.currentTime + 1.5); gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 4.5); osc.connect(gain); gain.connect(this.ctx.destination); osc.start(); osc.stop(this.ctx.currentTime + 5); }); }
        };
        
        document.body.addEventListener('click', () => AudioEngine.init(), {once:true});
        document.addEventListener('touchstart', () => AudioEngine.init(), {once:true});
        document.addEventListener('change', e => { if(e.target.id === 'toggle_sound') localStorage.setItem('ps4_ui_sound', e.target.checked); });
        document.addEventListener('click', (e) => { const isBtn = e.target.closest('button, .dock-item, .gallery-item, .folder-btn, .cursor-pointer, input[type="checkbox"]'); const t = document.getElementById('toggle_sound'); if(isBtn && t && t.checked && e.target.id !== 'volume_slider') AudioEngine.playClick(); });

        // ==========================================
        // MODALES Y NOTIFICACIONES
        // ==========================================
        function showPS5Dialog(title, message, type = 'alert', iconClass = 'fa-info', inputValue = '', confirmColor = 'bg-white text-black') {
            return new Promise((resolve) => {
                const dialogEl = document.getElementById('ps5-dialog');
                if(!dialogEl) {
                    let cleanMsg = message.replace(/<[^>]*>?/gm, ''); 
                    if(type === 'alert') { alert(title + ": " + cleanMsg); resolve(true); }
                    else if(type === 'confirm') { resolve(confirm(title + "\n" + cleanMsg)); }
                    else if(type === 'prompt') { resolve(prompt(title + "\n" + cleanMsg, inputValue)); }
                    return;
                }
                const dialogCard = document.getElementById('ps5-dialog-card'), dialogTitle = document.getElementById('ps5-dialog-title'), dialogText = document.getElementById('ps5-dialog-text'), dialogIcon = document.getElementById('ps5-dialog-icon'), dialogInput = document.getElementById('ps5-dialog-input'), dialogBtnCancel = document.getElementById('ps5-dialog-btn-cancel'), dialogBtnConfirm = document.getElementById('ps5-dialog-btn-confirm');
                if(type === 'alert' && iconClass.includes('text-red')) AudioEngine.playError(); else if (type === 'confirm' && confirmColor.includes('bg-red')) AudioEngine.playError();
                if(dialogTitle) dialogTitle.innerText = title; if(dialogText) dialogText.innerHTML = message; if(dialogIcon) dialogIcon.innerHTML = `<i class="fa-solid ${iconClass} text-2xl text-white"></i>`;
                if(dialogInput) dialogInput.classList.add('hidden'); 
                if(dialogBtnCancel) { dialogBtnCancel.classList.add('hidden'); dialogBtnCancel.innerText = t('modal_cancel'); }
                if(dialogBtnConfirm) { dialogBtnConfirm.className = `flex-1 rounded-xl py-3.5 font-bold text-[10px] tracking-widest transition-all shadow-lg active:scale-95 ${confirmColor}`; dialogBtnConfirm.innerText = t('modal_accept'); }
                if (type === 'prompt' && dialogInput && dialogBtnCancel) { dialogInput.classList.remove('hidden'); dialogInput.value = inputValue; dialogBtnCancel.classList.remove('hidden'); setTimeout(() => dialogInput.focus(), 300); } else if (type === 'confirm' && dialogBtnCancel) { dialogBtnCancel.classList.remove('hidden'); }
                const closeDialog = (result) => { if(dialogEl) dialogEl.classList.add('opacity-0'); if(dialogCard) dialogCard.classList.add('scale-95'); setTimeout(() => { if(dialogEl) dialogEl.classList.add('hidden'); resolve(result); }, 300); };
                if(dialogBtnConfirm) dialogBtnConfirm.onclick = () => { if (type === 'prompt') closeDialog(dialogInput ? dialogInput.value.trim() : ''); else closeDialog(true); };
                if(dialogBtnCancel) dialogBtnCancel.onclick = () => closeDialog(false);
                if(dialogEl) { dialogEl.classList.remove('hidden'); setTimeout(() => { dialogEl.classList.remove('opacity-0'); if(dialogCard) dialogCard.classList.remove('scale-95'); }, 10); }
            });
        }
        const ps5Alert = (title, msg, icon='fa-info') => showPS5Dialog(title, msg, 'alert', icon);
        const ps5Confirm = (title, msg, icon='fa-circle-question', confirmColor='bg-white text-black') => showPS5Dialog(title, msg, 'confirm', icon, '', confirmColor);
        const ps5Prompt = (title, msg, defaultVal='') => showPS5Dialog(title, msg, 'prompt', 'fa-pen', defaultVal);

        function ps5Notification(title, message, iconClass = 'fa-check') {
            const toggle = document.getElementById('toggle_notifications'); if (toggle && !toggle.checked) return; 
            const area = document.getElementById('notification-area'); if(!area) return;
            const toast = document.createElement('div'); toast.className = 'ps5-toast';
            toast.innerHTML = `<div class="ps5-toast-icon"><i class="fa-solid ${iconClass}"></i></div><div class="flex flex-col"><span class="text-[9px] font-black tracking-widest text-white/60 uppercase mb-0.5">${title}</span><span class="text-[11px] font-medium text-white">${message}</span></div>`;
            area.appendChild(toast); try { AudioEngine.playToast(); } catch(e) {}
            setTimeout(() => { toast.classList.add('hide'); setTimeout(() => toast.remove(), 400); }, 3500);
        }

        // ==========================================
        // INICIO DE LA APP
        // ==========================================
        window.addEventListener('load', () => {
            setLanguage(localStorage.getItem('ps4_ui_lang') || 'es'); AudioEngine.loadSettings(); animateParticles();
            const introScreen = document.getElementById('intro-screen'), logoWrap = document.getElementById('logo-wrapper'), appUi = document.getElementById('app-ui'), ambientBg = document.getElementById('ambient-bg');
            if(logoWrap) setTimeout(() => { logoWrap.style.opacity = '1'; logoWrap.style.transform = 'scale(1)'; logoWrap.style.filter = 'blur(0px)'; }, 500);
            setTimeout(() => { try { AudioEngine.playPS5Boot(); } catch(e) {} }, 500);
            setTimeout(() => {
                isExploding = true; if(logoWrap) { logoWrap.style.transform = 'scale(1.5)'; logoWrap.style.opacity = '0'; logoWrap.style.filter = 'blur(20px)'; }
                setTimeout(() => { if(introScreen) introScreen.style.opacity = '0'; if(appUi) appUi.style.opacity = '1'; if(ambientBg) ambientBg.style.transform = 'scale(1)'; setTimeout(() => { if(introScreen) introScreen.remove(); }, 1500); }, 800);
            }, 3000);
            
            // INICIAR EN MODO FTP COMO PRINCIPAL
            switchTransferMode('ftp');
            
            // Limpia la clase que limitaba la altura de la biblioteca para aplicar la nueva (más alta)
            const gridBiblio = document.getElementById('grid-biblioteca');
            if(gridBiblio && gridBiblio.parentElement) gridBiblio.parentElement.className = "overflow-y-auto custom-scrollbar pr-1 pb-biblioteca-fix";
        });

        // ==========================================
        // 3. TABS Y NAVEGACIÓN
        // ==========================================
        const tabsOrder = ['tab-biblioteca', 'tab-ftp', 'tab-icons', 'tab-explorer', 'tab-payloads', 'tab-settings']; let currentTabIndex = 0;
        let touchstartX = 0, touchendX = 0, touchstartY = 0, touchendY = 0; 
        document.addEventListener('touchstart', e => { touchstartX = e.changedTouches[0].screenX; touchstartY = e.changedTouches[0].screenY; }, {passive: true});
        document.addEventListener('touchend', e => { touchendX = e.changedTouches[0].screenX; touchendY = e.changedTouches[0].screenY; handleSwipe(); }, {passive: true});
        
        function handleSwipe() {
            if((document.getElementById('custom-modal') && !document.getElementById('custom-modal').classList.contains('hidden')) || (document.getElementById('ps5-dialog') && !document.getElementById('ps5-dialog').classList.contains('hidden')) || (document.getElementById('bottom-sheet') && document.getElementById('bottom-sheet').classList.contains('open')) || (document.getElementById('sheet-opciones') && document.getElementById('sheet-opciones').classList.contains('open')) || (document.getElementById('sheet-capturas') && document.getElementById('sheet-capturas').classList.contains('open'))) return;
            const deltaX = touchendX - touchstartX; const deltaY = touchendY - touchstartY;
            if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 60) {
                const navButtons = document.querySelectorAll('.dock-item');
                if (deltaX < 0) { if (currentTabIndex < tabsOrder.length - 1) { currentTabIndex++; switchTab(tabsOrder[currentTabIndex], navButtons[currentTabIndex], currentTabIndex); } } 
                else { if (currentTabIndex > 0) { currentTabIndex--; switchTab(tabsOrder[currentTabIndex], navButtons[currentTabIndex], currentTabIndex); } }
            }
        }

        function switchTab(tabId, btnElement, targetIndex = null) {
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active')); document.querySelectorAll('.dock-item').forEach(b => b.classList.remove('active'));
            const targetView = document.getElementById(tabId); if(btnElement) btnElement.classList.add('active'); window.scrollTo({ top: 0, behavior: 'smooth' });
            if(targetIndex !== null) currentTabIndex = targetIndex; else currentTabIndex = tabsOrder.indexOf(tabId);
            if(targetView) setTimeout(() => { targetView.classList.add('active'); }, 50);
            
            const btnFtp = document.getElementById('floating-btn-ftp'), btnRpi = document.getElementById('floating-btn-rpi'), btnAplicar = document.getElementById('floating-btn-aplicar'), btnPayload = document.getElementById('floating-btn-payload');
            if(btnFtp) btnFtp.classList.add('floating-hidden'); 
            if(btnRpi) btnRpi.classList.add('floating-hidden'); 
            if(btnAplicar) btnAplicar.classList.add('floating-hidden'); 
            if(btnPayload) btnPayload.classList.add('floating-hidden');
            
            if (tabId === 'tab-ftp') { 
                if (currentTransferMode === 'rpi') {
                    if(currentTabIndex === 1 && rpiQueue && rpiQueue.length > 0 && btnRpi) btnRpi.classList.remove('floating-hidden');
                } else {
                    if(btnFtp) btnFtp.classList.remove('floating-hidden');
                }
            } else if (tabId === 'tab-icons' && currentIconSource !== 'import') { 
                if(btnAplicar && selectedIconValue) btnAplicar.classList.remove('floating-hidden'); 
            } else if (tabId === 'tab-payloads') { 
                if(btnPayload) btnPayload.classList.remove('floating-hidden'); 
            }
            if (tabId === 'tab-explorer' && currentExplorerPath === '') { if (typeof loadExplorerPath === 'function') loadExplorerPath('/'); }
        }

        // ==========================================
        // VARIABLES GLOBALES (ESTADO)
        // ==========================================
        let currentTitle = "", currentCusa = "", currentVersion = "1.00";
        let isTransferring = false, uploadAbortController = null, isPaused = false, currentFileName = ""; 
        const CHUNK_SIZE = 20 * 1024 * 1024; 
        let currentExplorerPath = '', optionsPath = '', optionsName = '', optionsIsDir = false, clipboardItems = [], isCutMode = false, currentExplorerItems = [], isSelectMode = false, selectedItems = [];
        let PAYLOADS_LOCALES = [], selectedPayloadValue = null, currentPayloadSource = 'gallery';
        let ICONOS_LOCALES = [], BACKUPS_LOCALES = [], selectedIconValue = null, currentIconSource = 'gallery';
        let cachedAvatar = null, customUserName = localStorage.getItem('ps4_custom_username') || 'USUARIO PS4';
        let isScanning = false, abortController = null, radarAnimInterval = null, connectionMonitorInterval = null, wasConnected = false, failedPings = 0; 
        let wakeLock = null, timeoutModalClose = null;

        // ==========================================
        // RPI SENDER Y FTP (MODIFICADO - SELECCIÓN MÚLTIPLE Y EXTRACCIÓN SECUENCIAL)
        // ==========================================
        let currentTransferMode = 'ftp';
        let rpiQueue = []; 
        let rpiRawList = []; 

        function switchTransferMode(mode) {
            currentTransferMode = mode;
            let btnRpi = document.getElementById('btn-mode-rpi'), btnFtp = document.getElementById('btn-mode-ftp');
            let boxRpi = document.getElementById('box-mode-rpi'), boxFtp = document.getElementById('ftp-form');
            let floatingFtp = document.getElementById('floating-btn-ftp'), floatingRpi = document.getElementById('floating-btn-rpi');
            
            let classInactive = "flex-1 py-3 text-[9px] font-black tracking-widest rounded-xl text-white/50 hover:text-white whitespace-nowrap relative z-10 transition-all";
            let classActive = "flex-1 py-3 text-[9px] font-black tracking-widest rounded-xl bg-white text-black shadow-lg whitespace-nowrap relative z-10 transition-all";

            if(btnRpi) btnRpi.className = classInactive;
            if(btnFtp) btnFtp.className = classInactive;
            if(boxRpi) boxRpi.classList.add('hidden');
            if(boxFtp) boxFtp.classList.add('hidden');
            if(floatingFtp) floatingFtp.classList.add('floating-hidden');
            if(floatingRpi) floatingRpi.classList.add('floating-hidden');
            
            let activeBtn = document.getElementById('btn-mode-' + mode);
            if(activeBtn) activeBtn.className = classActive;
            
            if(mode === 'rpi') {
                if(boxRpi) boxRpi.classList.remove('hidden');
                if(currentTabIndex === 1 && rpiQueue.length > 0 && floatingRpi) floatingRpi.classList.remove('floating-hidden');
                renderRpiList();
            } else {
                if(boxFtp) boxFtp.classList.remove('hidden');
                if(currentTabIndex === 1 && floatingFtp) floatingFtp.classList.remove('floating-hidden');
            }
        }

        async function actualizarIpCelular() {
            let actual = localStorage.getItem('ps4_phone_ip') || '<?php echo $ip_servidor; ?>';
            let nuevaIp = await ps5Prompt('IP DE TU CELULAR', 'Escribe la IP actual de tu Wi-Fi (Ej: 192.168.0.21):', actual);
            if (nuevaIp && nuevaIp.trim() !== '') {
                localStorage.setItem('ps4_phone_ip', nuevaIp.trim());
                ps5Notification("IP ACTUALIZADA", "IP guardada exitosamente.", "fa-network-wired");
                renderRpiList(); 
            }
        }

        async function renderRpiList() {
            const container = document.getElementById('rpi-pkg-list');
            if(!container) return;
            container.innerHTML = `<div class="col-span-full text-center py-6"><i class="fa-solid fa-circle-notch fa-spin text-3xl text-white/30 mb-4"></i><p class="text-[10px] text-white/50 tracking-widest font-bold">CARGANDO LISTA...</p></div>`;
            rpiQueue = [];
            document.getElementById('floating-btn-rpi').classList.add('floating-hidden');
            
            try {
                let res = await fetch('index.php?get_rpi_list=1&_t=' + new Date().getTime());
                let data = await res.json();
                
                if (data.status === 'success') {
                    rpiRawList = data.data;
                    if (rpiRawList.length === 0) {
                        container.innerHTML = `<div class="col-span-full flex flex-col items-center justify-center min-h-[150px] bg-black/20 rounded-[1.5rem] border border-dashed border-white/10 p-6 text-center"><i class="fa-solid fa-box-open text-4xl mb-4 text-white/20"></i><p class="text-[10px] text-white/50 leading-relaxed">No hay juegos .pkg en la carpeta<br><span class="font-mono text-white/70 bg-black/50 px-1.5 py-0.5 rounded mt-1 inline-block">htdocs/servidor_rpi/</span></p><button onclick="renderRpiList()" class="mt-4 bg-white/10 px-4 py-2 rounded-lg text-[9px] font-bold text-white active:scale-95 transition-transform"><i class="fa-solid fa-rotate mr-1"></i> REFRESCAR</button></div>`;
                        return;
                    }
                    
                    let htmlControls = `<div class="col-span-full flex justify-end gap-2 mb-2">
                        <button onclick="mostrarAyudaRPI()" class="bg-green-600/20 text-green-400 hover:bg-green-600 hover:text-white px-3 py-1.5 rounded-lg text-[9px] font-black tracking-widest transition-colors active:scale-95"><i class="fa-solid fa-circle-question mr-1"></i> AYUDA</button>
                        <button onclick="actualizarIpCelular()" class="bg-yellow-600/20 text-yellow-400 hover:bg-yellow-600 hover:text-white px-3 py-1.5 rounded-lg text-[9px] font-black tracking-widest transition-colors active:scale-95"><i class="fa-solid fa-pen mr-1"></i> EDITAR IP</button>
                        <button onclick="renderRpiList()" class="bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white px-3 py-1.5 rounded-lg text-[9px] font-black tracking-widest transition-colors active:scale-95"><i class="fa-solid fa-rotate mr-1"></i> REFRESCAR</button>
                    </div>`;
                    
                    let htmlCards = '';
                    rpiRawList.forEach((pkg, idx) => {
                        let idCard = 'rpi-card-' + idx;
                        htmlCards += `
                        <div id="${idCard}" class="rpi-card rounded-2xl p-2 aspect-[3/4] flex flex-col relative group" onclick="selectRpiPkg('${pkg.nombre}', '${idCard}')">
                            <div class="rpi-card-check"><i class="fa-solid fa-check"></i></div>
                            <div class="w-full flex-1 rounded-xl bg-black/50 border border-white/5 flex items-center justify-center overflow-hidden mb-2 relative">
                                <i id="icon-${idCard}" class="fa-solid fa-spinner fa-spin text-white/20 text-3xl z-0"></i>
                                <img id="img-${idCard}" src="" class="absolute inset-0 w-full h-full object-cover hidden z-10">
                            </div>
                            <div class="px-1 flex flex-col items-center text-center w-full overflow-hidden">
                                <div id="title-container-${idCard}" class="w-full mb-1">
                                    <h3 class="text-[10px] font-black text-white leading-tight truncate w-full">Cargando...</h3>
                                </div>
                                <div class="flex items-center gap-1 justify-center w-full">
                                    <span id="cusa-${idCard}" class="text-[8px] text-blue-400 font-mono font-bold tracking-widest bg-blue-500/10 px-1 py-0.5 rounded border border-blue-500/20 truncate">----</span>
                                    <span class="text-[8px] text-white/50 font-mono tracking-widest">${pkg.size_fmt}</span>
                                </div>
                            </div>
                        </div>`;
                    });
                    
                    container.innerHTML = htmlControls + htmlCards;
                    procesarColaMetadatosRPI([...rpiRawList]);
                }
            } catch(e) {
                container.innerHTML = `<div class="col-span-full text-center text-red-400 text-xs font-bold py-6">Error al cargar la lista.</div>`;
            }
        }

        async function procesarColaMetadatosRPI(cola) {
            if (cola.length === 0) return;
            let pkg = cola.shift();
            let idx = rpiRawList.findIndex(p => p.nombre === pkg.nombre);
            let idCard = 'rpi-card-' + idx;
            
            try {
                let res = await fetch('index.php?extract_pkg=' + encodeURIComponent(pkg.nombre));
                let data = await res.json();
                
                if (data.status === 'success') {
                    let titleContainer = document.getElementById('title-container-' + idCard);
                    let cusaEl = document.getElementById('cusa-' + idCard);
                    let iconEl = document.getElementById('icon-' + idCard);
                    let imgEl = document.getElementById('img-' + idCard);
                    
                    if (titleContainer) {
                        let safeTitle = data.data.title.replace(/</g, "<").replace(/>/g, ">");
                        if (safeTitle.length > 15) {
                            titleContainer.innerHTML = `<marquee behavior="alternate" scrollamount="1"><h3 class="text-[10px] font-black text-white leading-tight inline">${safeTitle}</h3></marquee>`;
                        } else {
                            titleContainer.innerHTML = `<h3 class="text-[10px] font-black text-white leading-tight truncate">${safeTitle}</h3>`;
                        }
                    }
                    if (cusaEl) cusaEl.innerText = data.data.cusa;
                    
                    if (data.data.icon !== '') {
                        if (imgEl) {
                            imgEl.src = data.data.icon + '?v=' + new Date().getTime();
                            imgEl.onload = () => { imgEl.classList.remove('hidden'); if(iconEl) iconEl.classList.add('hidden'); };
                        }
                    } else {
                        if (iconEl) { iconEl.classList.remove('fa-spinner', 'fa-spin'); iconEl.classList.add('fa-gamepad'); }
                    }
                }
            } catch (e) {
                let iconEl = document.getElementById('icon-' + idCard);
                if (iconEl) { iconEl.classList.remove('fa-spinner', 'fa-spin'); iconEl.classList.add('fa-triangle-exclamation', 'text-yellow-500/50'); }
            }
            
            procesarColaMetadatosRPI(cola);
        }

        function selectRpiPkg(filename, cardId) {
            const card = document.getElementById(cardId);
            const index = rpiQueue.indexOf(filename);
            
            if (index > -1) {
                rpiQueue.splice(index, 1);
                card.classList.remove('selected');
            } else {
                rpiQueue.push(filename);
                card.classList.add('selected');
            }
            
            const floatingBtn = document.getElementById('floating-btn-rpi');
            const installText = document.getElementById('rpi-install-text');
            
            if (rpiQueue.length > 0) {
                installText.innerText = `INSTALAR (${rpiQueue.length})`;
                floatingBtn.classList.remove('floating-hidden');
            } else {
                floatingBtn.classList.add('floating-hidden');
            }
        }

        function mostrarAyudaRPI() {
            const mensaje = `
            <div class="text-left space-y-3 mt-2 max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
                <div class="bg-white/5 p-3 rounded-xl border border-white/10">
                    <h4 class="text-red-400 font-bold text-[10px] mb-1"><i class="fa-solid fa-stopwatch mr-1"></i> TIMEOUT / NO CONECTA</h4>
                    <p class="text-white/70 text-[9px] leading-relaxed">Celular y PS4 deben estar en la misma Subred (ej: 192.168.0.xx). Solución: Usa el Hotspot de tu celular o IP estática.</p>
                </div>
                <div class="bg-white/5 p-3 rounded-xl border border-white/10">
                    <h4 class="text-yellow-400 font-bold text-[10px] mb-1"><i class="fa-solid fa-triangle-exclamation mr-1"></i> ERROR 0x80990004</h4>
                    <p class="text-white/70 text-[9px] leading-relaxed">El nombre del archivo PKG es inválido. Solución: Quita los espacios y símbolos (Ej: MiJuego.pkg).</p>
                </div>
                <div class="bg-white/5 p-3 rounded-xl border border-white/10">
                    <h4 class="text-blue-400 font-bold text-[10px] mb-1"><i class="fa-solid fa-download mr-1"></i> ERROR 0x80990015</h4>
                    <p class="text-white/70 text-[9px] leading-relaxed">Cola llena o juego instalado. Solución: Borra los errores en Notificaciones -> Descargas en la PS4.</p>
                </div>
            </div>`;
            ps5Alert("GUÍA DEL INSTALADOR", mensaje, "fa-life-ring");
        }
        async function iniciarColaInstalacionRPI() {
            if(rpiQueue.length === 0) { await ps5Alert(t('j_err_file'), "Selecciona al menos un juego de la lista.", "fa-hand-pointer"); return; }
            const ps4Ip = document.getElementById('host-ip').value;
            if(!ps4Ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), "fa-network-wired"); return; }
            
            let phoneIp = '<?php echo $ip_servidor; ?>';
            let storedIp = localStorage.getItem('ps4_phone_ip');
            
            if (storedIp && storedIp.trim() !== '') {
                phoneIp = storedIp.trim();
            }
            
            let getSubnet = (ip) => ip.split('.').slice(0, 3).join('.');
            
            if (getSubnet(ps4Ip) !== getSubnet(phoneIp) || phoneIp === '127.0.0.1' || phoneIp === 'localhost' || phoneIp === '::1' || phoneIp.startsWith('fe80:')) {
                let advertencia = await ps5Confirm("ADVERTENCIA DE RED", `Detectamos que tu celular y la PS4 están en redes diferentes o Android bloqueó la IP automática.<br><br>Celular (Wi-Fi): <b class="text-yellow-400">${phoneIp}</b><br>PS4: <b class="text-blue-400">${ps4Ip}</b><br><br>Para evitar que el envío falle, toca "CANCELAR", luego ve al botón "EDITAR IP" y coloca tu IP Wi-Fi actual. ¿O quieres forzar el envío de todos modos?`, "fa-network-wired", "bg-yellow-500 text-black");
                if (!advertencia) return;
            }

            let port = window.location.port ? ':' + window.location.port : '';
            let baseUrl = window.location.protocol + '//' + phoneIp + port + window.location.pathname.replace(/index\.php$/, '').replace(/\/$/, '');

            // Mostrar Modal de Progreso Múltiple
            document.getElementById('custom-modal').classList.remove('hidden', 'opacity-0'); 
            document.getElementById('modal-card').classList.remove('scale-95');
            document.getElementById('modal-progress-container').classList.remove('hidden'); 
            document.getElementById('modal-controls').classList.add('hidden'); 
            document.getElementById('modal-close-btn').classList.add('hidden');
            document.getElementById('modal-icon').innerHTML = '<div class="absolute inset-0 rounded-full border border-blue-500/30 animate-ping"></div><i class="fa-solid fa-satellite-dish text-4xl text-blue-400 relative z-10 animate-pulse"></i>';
            
            let exitos = 0;
            let errores = [];
            
            for (let i = 0; i < rpiQueue.length; i++) {
                let selectedPkg = rpiQueue[i];
                let urlToSend = baseUrl + '/servidor_rpi/' + encodeURIComponent(selectedPkg);
                
                document.getElementById('modal-title').innerText = `ENVIANDO (${i+1}/${rpiQueue.length})`;
                document.getElementById('modal-text').innerHTML = `Instalando:<br><b class="text-white text-[10px] break-all">${selectedPkg}</b>`;
                
                let pct = ((i) / rpiQueue.length) * 100;
                document.getElementById('modal-progress-bar').style.width = pct + '%';
                document.getElementById('modal-percentage').innerText = pct.toFixed(0) + '%';
                
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 12000); // 12 seg por PKG

                try {
                    let res = await fetch('index.php?rpi_proxy=1', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ ip: ps4Ip, url_pkg: urlToSend }),
                        signal: controller.signal
                    });
                    clearTimeout(timeoutId);
                    let data = await res.json();
                    
                    if(data.status === 'success') {
                        exitos++;
                        // Pequeña pausa de seguridad para no ahogar al Remote Package Installer
                        await new Promise(r => setTimeout(r, 1500)); 
                    } else {
                        errores.push(`${selectedPkg}: Rechazado por la consola.`);
                    }
                } catch(e) {
                    clearTimeout(timeoutId);
                    if (e.name === 'AbortError') {
                        errores.push(`${selectedPkg}: Tiempo agotado (Timeout).`);
                    } else {
                        errores.push(`${selectedPkg}: Error de red local.`);
                    }
                }
            }
            
            document.getElementById('modal-progress-bar').style.width = '100%';
            document.getElementById('modal-percentage').innerText = '100%';
            closeCustomModal();
            
            setTimeout(() => {
                if (errores.length === 0) {
                    AudioEngine.playSuccess();
                    ps5Notification("INSTALACIÓN", `Se enviaron ${exitos} juegos a la consola.`, "fa-check-double");
                    renderRpiList(); // Limpia la selección visualmente
                } else {
                    AudioEngine.playError();
                    let logErrores = errores.join('\n');
                    ps5Alert("COMPLETADO CON ERRORES", `Se enviaron ${exitos} juegos, pero fallaron ${errores.length}.<br><textarea class="w-full h-24 bg-black text-red-400 font-mono text-[9px] mt-2 p-2 rounded border border-red-500/30 custom-scrollbar" readonly>${logErrores}</textarea>`, "fa-triangle-exclamation");
                }
            }, 400);
        }

        // ==========================================
        // MODALES DE CARGA Y CERRADO GENERAL
        // ==========================================
        function mostrarCarga(titulo, subtitulo, iconClass="fa-circle-notch fa-spin") { 
            const modal = document.getElementById('custom-modal');
            if(!modal) return;

            if(timeoutModalClose) clearTimeout(timeoutModalClose); 
            document.getElementById('modal-title').innerText = titulo; 
            document.getElementById('modal-text').innerHTML = subtitulo; 
            const mIcon = document.getElementById('modal-icon');
            if(iconClass.includes('fa-playstation')) {
                mIcon.innerHTML = `<div class="absolute inset-0 rounded-full border border-white/30 animate-ping"></div><i class="${iconClass} text-3xl text-white relative z-10 animate-pulse"></i>`;
            } else {
                mIcon.innerHTML = `<div class="absolute inset-0 rounded-full border border-white/30 animate-ping"></div><i class="fa-solid ${iconClass} text-3xl text-white relative z-10"></i>`;
            }
            document.getElementById('modal-progress-container').classList.add('hidden'); 
            document.getElementById('modal-controls').classList.add('hidden'); 
            document.getElementById('modal-close-btn').classList.add('hidden'); 
            
            modal.classList.remove('hidden'); 
            setTimeout(() => { modal.classList.remove('opacity-0'); document.getElementById('modal-card').classList.remove('scale-95'); }, 10); 
        }
        function closeCustomModal() { 
            const modal = document.getElementById('custom-modal');
            if(!modal) return;
            modal.classList.add('opacity-0'); document.getElementById('modal-card').classList.add('scale-95'); 
            timeoutModalClose = setTimeout(() => modal.classList.add('hidden'), 300); 
        }
        function mostrarErrorFinal(titulo, msg) { 
            const modal = document.getElementById('custom-modal');
            if(!modal) { alert("ERROR: " + msg); return; }

            if(timeoutModalClose) clearTimeout(timeoutModalClose); 
            AudioEngine.playError(); 
            
            modal.classList.remove('hidden', 'opacity-0'); document.getElementById('modal-card').classList.remove('scale-95'); 
            document.getElementById('modal-progress-container').classList.add('hidden'); document.getElementById('modal-controls').classList.add('hidden'); 
            document.getElementById('modal-close-btn').classList.remove('hidden'); 
            document.getElementById('modal-title').innerText = titulo; document.getElementById('modal-text').innerHTML = msg; 
            document.getElementById('modal-icon').innerHTML = '<i class="fa-solid fa-triangle-exclamation text-4xl text-red-500"></i>'; 
            document.getElementById('modal-icon').className = "w-20 h-20 mx-auto rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(239,68,68,0.2)]"; 
            if (titulo === t('j_cancel')) { const fUp = document.getElementById('file-upload'); if(fUp) { fUp.value = ''; updateFileName(fUp); } } 
        }
        
        async function requestWakeLock() { if (!document.getElementById('toggle_wakelock') || !document.getElementById('toggle_wakelock').checked) return; try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (err) {} }
        function releaseWakeLock() { if (wakeLock !== null) { wakeLock.release().then(() => wakeLock = null); } }

        function cerrarTodo() { document.querySelectorAll('.bottom-sheet').forEach(s => s.classList.remove('open')); const overlay = document.getElementById('overlay-global'); if(overlay) overlay.classList.remove('open'); }

        // ==========================================
        // MENU DE OPCIONES Y GESTOR DE JUEGOS
        // ==========================================
        function abrirPanelSecundario(id) { document.getElementById('sheet-opciones').classList.remove('open'); setTimeout(() => { document.getElementById(id).classList.add('open'); }, 100); }
        function volverAOpcionesDesde(id) { document.getElementById(id).classList.remove('open'); setTimeout(() => { document.getElementById('sheet-opciones').classList.add('open'); }, 100); }
        function abrirMenuInstalar() { const navButtons = document.querySelectorAll('.dock-item'); switchTab('tab-ftp', navButtons[1], 1); }
        function simularRedireccionModding() { const navButtons = document.querySelectorAll('.dock-item'); switchTab('tab-icons', navButtons[2], 2); document.getElementById('icon-cusa').value = currentCusa; cerrarTodo(); }

        function renderizarCategoriasModal(cusa) {
            const container = document.getElementById('selector-categorias');
            if (!container) return;

            let customCats = JSON.parse(localStorage.getItem('ps4_custom_categories')) || [];
            let categorias = [{id:'juegos', name:'Juegos'}, {id:'apps', name:'Apps'}, ...customCats];
            
            let savedCats = JSON.parse(localStorage.getItem('ps4_game_categories')) || {};
            let categoriaActual = savedCats[cusa] || 'juegos'; 

            let html = '';
            categorias.forEach(cat => {
                let esActivo = (cat.id === categoriaActual);
                let clasesColor = esActivo ? 'bg-blue-600 text-white border-blue-500 shadow-[0_0_15px_rgba(37,99,235,0.4)]' : 'bg-white/5 text-white/40 border-white/10 hover:bg-white/10 hover:text-white/80';
                html += `<button onclick="moverAGrupo('${cat.id}')" class="px-5 py-2.5 rounded-xl border text-[10px] font-black tracking-widest uppercase transition-all shrink-0 ${clasesColor}">${cat.name}</button>`;
            });
            container.innerHTML = html;
        }

        async function abrirOpciones(titulo, cusa, imgSrc, version) {
            currentTitle = titulo; currentCusa = cusa; currentVersion = version || "1.00";
            document.getElementById('opt-game-title').innerText = titulo; document.getElementById('opt-game-cusa').innerText = cusa; document.getElementById('opt-game-img').src = imgSrc; document.getElementById('opt-game-version').innerText = 'v' + currentVersion;
            renderizarCategoriasModal(currentCusa);
            document.getElementById('opt-game-size').innerHTML = '<i class="fa-solid fa-spinner fa-spin text-white/50"></i>'; document.getElementById('opt-game-loc').innerText = '...';
            document.getElementById('overlay-global').classList.add('open'); document.getElementById('sheet-opciones').classList.add('open');
            const ip = document.getElementById('host-ip') ? document.getElementById('host-ip').value : '';
            if(!ip) { document.getElementById('opt-game-size').innerText = "Falta IP"; return; }
            const fd = new FormData(); fd.append('host_ip', ip); fd.append('cusa_id', currentCusa);
            try {
                let res = await fetch('api/tech_info.php', { method: 'POST', body: fd });
                let data = await res.json();
                if (data.status === 'success') { document.getElementById('opt-game-size').innerText = data.size; document.getElementById('opt-game-loc').innerText = data.location; } else { document.getElementById('opt-game-size').innerText = "Error"; }
            } catch(e) { document.getElementById('opt-game-size').innerText = "Error red"; }
        }

        // --- GESTOR DE DLCS Y UPDATES ---
        async function abrirMenuDLCs() {
            document.getElementById('dlc-game-cusa').innerText = `${currentCusa} - ${currentTitle}`; abrirPanelSecundario('sheet-dlcs');
            const container = document.getElementById('dlc-list-container');
            container.innerHTML = `<div class="text-center py-12"><i class="fa-solid fa-circle-notch fa-spin text-3xl text-white/30 mb-4 block"></i><p class="text-[10px] text-white/50 font-bold tracking-widest uppercase">Calculando pesos en PS4...</p></div>`;
            const ip = document.getElementById('host-ip') ? document.getElementById('host-ip').value : '';
            if(!ip) { container.innerHTML = `<div class="text-center py-10 text-red-400 text-xs font-bold">Falta conectar la IP de PS4.</div>`; return; }
            const fd = new FormData(); fd.append('action', 'scan'); fd.append('host_ip', ip); fd.append('cusa_id', currentCusa);
            try {
                let res = await fetch('api/dlc_manager.php', { method: 'POST', body: fd }); let data = await res.json();
                if (data.status === 'success') {
                    if (data.items.length === 0) { container.innerHTML = `<div class="text-center py-10 bg-black/20 rounded-2xl border border-white/5"><i class="fa-solid fa-ghost text-4xl text-white/10 mb-3 block"></i><p class="text-[10px] text-white/40 font-bold tracking-widest uppercase">Juego Base Limpio</p><p class="text-[9px] text-white/30 mt-1">No hay Updates ni DLCs que borrar.</p></div>`; return; }
                    let html = '';
                    data.items.forEach(item => {
                        let icon = item.type === 'update' ? 'fa-arrow-up-right-dots text-blue-400' : 'fa-puzzle-piece text-purple-400';
                        let bg = item.type === 'update' ? 'bg-blue-500/10 border-blue-500/20' : 'bg-purple-500/10 border-purple-500/20';
                        let title = item.type === 'update' ? 'UPDATE (PARCHE)' : 'EXPANSIÓN / DLC';
                        html += `<div class="flex items-center justify-between p-4 rounded-2xl border ${bg} group cursor-pointer hover:bg-white/5 transition-colors"><div class="flex items-center gap-4 overflow-hidden"><div class="w-11 h-11 rounded-xl bg-black/50 flex items-center justify-center shrink-0 border border-white/5 shadow-lg"><i class="fa-solid ${icon} text-lg"></i></div><div class="flex flex-col overflow-hidden pr-2"><span class="text-[9px] font-black tracking-widest text-white/50 uppercase mb-0.5">${title}</span><span class="text-xs font-bold text-white truncate">${item.name}</span><span class="text-[11px] font-mono text-green-400 font-bold mt-1 tracking-wider"><i class="fa-solid fa-weight-hanging text-[9px] mr-1 text-white/30"></i>${item.size_formatted}</span></div></div><button onclick="eliminarDLCUpdate('${item.path}', '${item.type}', '${item.size_formatted}')" class="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-500 flex items-center justify-center shrink-0 hover:bg-red-600 hover:text-white transition-all shadow-[0_0_15px_rgba(239,68,68,0.2)] active:scale-95"><i class="fa-solid fa-trash-can text-lg"></i></button></div>`;
                    });
                    container.innerHTML = html;
                } else { container.innerHTML = `<div class="text-center py-10 text-red-400 text-xs font-bold">${data.message}</div>`; }
            } catch(e) { container.innerHTML = `<div class="text-center py-10 text-red-400 text-xs font-bold">Error de conexión al escanear.</div>`; }
        }

        async function eliminarDLCUpdate(path, type, size) {
            let tipoNombre = type === 'update' ? 'la Actualización' : 'este DLC';
            const seguro = await ps5Confirm("LIBERAR ESPACIO", `¿Estás seguro de eliminar <b>${tipoNombre}</b>?<br><br>Se liberarán <b class="text-green-400">${size}</b>.<br><span class="text-[9px] text-red-400 block mt-2">No se borrará el juego base.</span>`, "fa-dumpster-fire", "bg-red-600 text-white shadow-[0_0_15px_rgba(220,38,38,0.5)]");
            if (!seguro) return;
            mostrarCarga("BORRANDO", `Desinstalando...<br><span class='text-[10px] font-bold text-green-400 block mt-1'>Liberando ${size}</span>`, "fa-trash fa-bounce text-red-500");
            const ip = document.getElementById('host-ip') ? document.getElementById('host-ip').value : '';
            const fd = new FormData(); fd.append('action', 'delete'); fd.append('host_ip', ip); fd.append('path', path);
            try {
                let res = await fetch('api/dlc_manager.php', { method: 'POST', body: fd }); let data = await res.json();
                closeCustomModal(); await new Promise(r => setTimeout(r, 350));
                if (data.status === 'success') { if(typeof AudioEngine !== 'undefined') AudioEngine.playSuccess(); ps5Notification("ESPACIO RECUPERADO", `Se han liberado ${size}.`, "fa-broom"); abrirMenuDLCs(); } else { mostrarErrorFinal("ERROR", data.message); }
            } catch(e) { mostrarErrorFinal("ERROR", "Falló la conexión al intentar borrar."); }
        }

        async function iniciarBackupSaves() {
            const ip = document.getElementById('host-ip') ? document.getElementById('host-ip').value : '';
            if (!ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), 'fa-network-wired'); return; }
            cerrarTodo();
            mostrarCarga("ANALIZANDO", "Buscando partidas en la PS4...", "fa-magnifying-glass fa-bounce text-blue-400");
            const fdCheck = new FormData(); fdCheck.append('action', 'check_saves'); fdCheck.append('host_ip', ip); fdCheck.append('cusa_id', currentCusa);
            try {
                let res = await fetch('api/saves.php', { method: 'POST', body: fdCheck }); let data = await res.json();
                closeCustomModal(); await new Promise(r => setTimeout(r, 350));
                if (data.status === 'success') {
                    const msg = `Se encontraron <b>${data.files} archivos</b> de guardado.<br>Peso total: <b>${data.size_mb} MB</b><br>Perfiles: <b>${data.users}</b><br><br>¿Deseas comprimir todo y descargar el ZIP a tu celular?`;
                    const confirmar = await ps5Confirm("PARTIDAS ENCONTRADAS", msg, "fa-floppy-disk", "bg-blue-600 text-white");
                    if (confirmar) {
                        mostrarCarga("CREANDO BACKUP", "Comprimiendo y descargando...<br><span class='text-[9px] text-white/50 mt-1 block'>No cierres la app.</span>", "fa-file-zipper fa-bounce text-blue-400");
                        const fdBackup = new FormData(); fdBackup.append('action', 'backup'); fdBackup.append('host_ip', ip); fdBackup.append('cusa_id', currentCusa);
                        let resBackup = await fetch('api/saves.php', { method: 'POST', body: fdBackup }); let dataBackup = await resBackup.json();
                        if (dataBackup.status === 'success') { closeCustomModal(); ps5Notification("BACKUP", "Descarga iniciada.", "fa-check"); window.location.href = dataBackup.download_url; } else { mostrarErrorFinal("ERROR DE ZIP", dataBackup.message); }
                    }
                } else { ps5Alert("SIN PARTIDAS", data.message, "fa-ghost"); }
            } catch(e) { mostrarErrorFinal("ERROR", "Falló la conexión."); }
        }

        async function abrirGaleriaJuego() {
            document.getElementById('capturas-game-cusa').innerText = `${currentCusa} - ${currentTitle}`; abrirPanelSecundario('sheet-capturas');
            const grid = document.getElementById('capturas-grid'); grid.innerHTML = `<div class="col-span-2 flex flex-col items-center justify-center py-12"><i class="fa-solid fa-circle-notch fa-spin text-purple-500 text-4xl mb-4"></i><p class="text-white/50 text-[10px] tracking-widest font-bold uppercase">Buscando fotos de ${currentTitle}...</p></div>`;
            const ip = document.getElementById('host-ip') ? document.getElementById('host-ip').value : '';
            if(!ip) { grid.innerHTML = `<div class="col-span-2 text-center py-10 text-red-400 text-xs font-bold">Conecta la IP de tu PS4 primero.</div>`; return; }
            const fd = new FormData(); fd.append('host_ip', ip); fd.append('cusa_id', currentCusa); fd.append('game_title', currentTitle); 
            try {
                let res = await fetch('api/ps4_screenshots.php', { method: 'POST', body: fd }); let data = await res.json();
                if (data.status === 'success') {
                    let html = '';
                    data.data.forEach((path, index) => {
                        let filename = path.split('/').pop(); let imgUrl = `api/ps4_screenshots.php?action=stream&host_ip=${ip}&path=${encodeURIComponent(path)}`;
                        html += `<div class="relative group aspect-video rounded-xl overflow-hidden bg-black/50 border border-white/10 shadow-lg"><div id="loader-${index}" class="absolute inset-0 flex items-center justify-center bg-black/80 z-10"><i class="fa-solid fa-spinner fa-spin text-white/30 text-2xl"></i></div><img id="img-${index}" data-src="${imgUrl}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-0"><div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-2 z-20"><span class="text-[8px] text-white/50 font-mono truncate max-w-[70%]">${filename}</span><a href="${imgUrl}" download="${filename}" target="_blank" class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-[0_0_15px_rgba(37,99,235,0.6)] active:scale-95"><i class="fa-solid fa-download text-[10px]"></i></a></div></div>`;
                    });
                    grid.innerHTML = html;
                    const cargarEnFila = async () => {
                        for (let i = 0; i < data.data.length; i++) {
                            const img = document.getElementById(`img-${i}`);
                            if (img) { await new Promise(resolve => { img.onload = () => { img.classList.remove('opacity-0'); let ldr = document.getElementById(`loader-${i}`); if(ldr) ldr.style.display = 'none'; resolve(); }; img.onerror = () => { let ldr = document.getElementById(`loader-${i}`); if(ldr) ldr.innerHTML = '<i class="fa-solid fa-image-slash text-white/20 text-2xl"></i>'; resolve(); }; img.src = img.getAttribute('data-src'); }); }
                        }
                    };
                    cargarEnFila();
                } else { grid.innerHTML = `<div class="col-span-2 flex flex-col items-center justify-center py-12"><i class="fa-solid fa-image text-white/10 text-6xl mb-4"></i><p class="text-white/50 text-[10px] px-4 text-center leading-relaxed">${data.message}</p></div>`; }
            } catch (e) { grid.innerHTML = `<div class="col-span-2 text-center py-10 text-red-400 text-xs font-bold">Error de red.</div>`; }
        }

        // ==========================================
        // BIBLIOTECA CORE Y CATEGORIAS 
        // ==========================================
        function buscarEnBiblioteca(q) {
            q = q.toLowerCase(); const items = document.querySelectorAll('.item-biblio');
            const activeFilterBtn = document.querySelector('.filter-pill.active'); const activeCat = activeFilterBtn ? activeFilterBtn.dataset.cat : 'todos';
            items.forEach(item => {
                const title = item.querySelector('h3').innerText.toLowerCase(); const cusa = item.querySelector('span.font-mono').innerText.toLowerCase(); const itemCat = item.getAttribute('data-category');
                const matchesSearch = title.includes(q) || cusa.includes(q); const matchesCat = activeCat === 'todos' || itemCat === activeCat;
                if (matchesSearch && matchesCat) { item.style.display = ''; } else { item.style.display = 'none'; }
            });
        }

        function renderCategorias() {
            let customCats = JSON.parse(localStorage.getItem('ps4_custom_categories')) || []; const nav = document.getElementById('categoria-nav'); 
            if(nav) {
                let htmlNav = `<button onclick="crearNuevaCategoria()" class="w-8 h-8 shrink-0 rounded-full bg-blue-600 hover:bg-blue-500 border border-blue-400/30 flex items-center justify-center text-white active:scale-95 shadow-lg transition-colors mr-1"><i class="fa-solid fa-folder-plus text-[10px]"></i></button>`;
                htmlNav += `<button data-cat="todos" onclick="filtrarCategoria('todos', this)" class="filter-pill active border border-white px-4 py-1.5 rounded-full text-[9px] font-bold tracking-widest uppercase whitespace-nowrap bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]">Todos</button>`;
                htmlNav += `<button data-cat="juegos" onclick="filtrarCategoria('juegos', this)" class="filter-pill bg-white/5 text-white/60 border border-white/5 px-4 py-1.5 rounded-full text-[9px] font-bold tracking-widest uppercase whitespace-nowrap">Juegos</button>`;
                htmlNav += `<button data-cat="apps" onclick="filtrarCategoria('apps', this)" class="filter-pill bg-white/5 text-white/60 border border-white/5 px-4 py-1.5 rounded-full text-[9px] font-bold tracking-widest uppercase whitespace-nowrap">Apps</button>`;
                customCats.forEach(c => { htmlNav += `<div class="relative group flex items-center shrink-0"><button data-cat="${c.id}" onclick="filtrarCategoria('${c.id}', this)" class="filter-pill bg-white/5 text-white/60 pl-3 pr-6 py-1.5 rounded-full text-[9px] font-bold tracking-widest uppercase whitespace-nowrap border border-white/5">${c.name}</button><div onclick="eliminarCategoria('${c.id}')" class="absolute right-1 w-4 h-4 bg-red-500/80 hover:bg-red-600 rounded-full flex items-center justify-center text-white cursor-pointer transition-colors z-10 shadow-lg"><i class="fa-solid fa-xmark text-[8px]"></i></div></div>`; });
                nav.innerHTML = htmlNav;
            }
        }

        async function crearNuevaCategoria() {
            const nombre = await ps5Prompt("NUEVA CATEGORÍA", "Escribe el nombre:");
            if(nombre && nombre.trim() !== "") {
                const catId = nombre.trim().toLowerCase().replace(/[^a-z0-9]/g, '-');
                if(catId === 'todos' || catId === 'juegos' || catId === 'apps') return; 
                let customCats = JSON.parse(localStorage.getItem('ps4_custom_categories')) || [];
                if(!customCats.find(c => c.id === catId)) { customCats.push({id: catId, name: nombre}); localStorage.setItem('ps4_custom_categories', JSON.stringify(customCats)); renderCategorias(); ps5Notification("ÉXITO", `Categoría creada.`, "fa-folder-plus"); }
            }
        }

        async function eliminarCategoria(catId) {
            const seguro = await ps5Confirm("ELIMINAR CATEGORÍA", "¿Borrar esta categoría? Los juegos volverán a su sección por defecto.", "fa-trash", "bg-red-500 text-white");
            if(!seguro) return;
            let customCats = JSON.parse(localStorage.getItem('ps4_custom_categories')) || []; customCats = customCats.filter(c => c.id !== catId); localStorage.setItem('ps4_custom_categories', JSON.stringify(customCats));
            let savedCats = JSON.parse(localStorage.getItem('ps4_game_categories')) || {}; for(let cusa in savedCats) { if(savedCats[cusa] === catId) delete savedCats[cusa]; } localStorage.setItem('ps4_game_categories', JSON.stringify(savedCats));
            renderCategorias(); cargarBibliotecaLocal(); ps5Notification("ELIMINADA", "Categoría borrada.", "fa-trash");
        }

        function moverAGrupo(cat) { 
            const items = document.querySelectorAll('.item-biblio');
            items.forEach(item => { if(item.querySelector('h3') && item.querySelector('h3').innerText === currentTitle) { item.setAttribute('data-category', cat); let savedCats = JSON.parse(localStorage.getItem('ps4_game_categories')) || {}; savedCats[currentCusa] = cat; localStorage.setItem('ps4_game_categories', JSON.stringify(savedCats)); } });
            ps5Notification("MOVIDO", "Juego reubicado con éxito.", "fa-check"); renderizarCategoriasModal(currentCusa); const activeFilter = document.querySelector('.filter-pill.active'); if(activeFilter) filtrarCategoria(activeFilter.dataset.cat, activeFilter);
        }

        function filtrarCategoria(cat, btn) {
            document.querySelectorAll('.filter-pill').forEach(b => { b.classList.remove('active', 'bg-white', 'text-black', 'border-white', 'shadow-[0_0_15px_rgba(255,255,255,0.2)]'); b.classList.add('bg-white/5', 'text-white/60', 'border-white/5'); }); 
            if(btn) { btn.classList.remove('bg-white/5', 'text-white/60', 'border-white/5'); btn.classList.add('active', 'bg-white', 'text-black', 'border-white', 'shadow-[0_0_15px_rgba(255,255,255,0.2)]'); }
            const items = document.querySelectorAll('.item-biblio'); 
            items.forEach(item => { let itemCat = item.getAttribute('data-category'); if (cat === 'todos' || itemCat === cat) { item.style.display = ''; } else { item.style.display = 'none'; } });
        }

        async function borrarJuegoDeBiblioteca() {
            const seguro = await ps5Confirm("QUITAR JUEGO", `¿Ocultar de la biblioteca local?<br><br><span class="text-[9px] text-white/50 block mt-2">Solo borra la portada del celular, no borra el juego de tu PS4.</span>`, "fa-trash-can", "bg-red-600 text-white");
            if (!seguro) return;
            const fd = new FormData(); fd.append('action', 'delete_game'); fd.append('cusa_id', currentCusa);
            try { await fetch('api/library.php', { method: 'POST', body: fd }); ps5Notification("OCULTO", "Juego removido de la vista.", "fa-eye-slash"); cerrarTodo(); cargarBibliotecaLocal(); } catch(e) {}
        }

        async function limpiarBibliotecaEntera() {
            const seguro = await ps5Confirm("VACIAR CACHÉ", "¿Estás seguro de limpiar por completo la biblioteca local?<br><br><span class='text-[9px] text-white/50 block mt-2'>Tendrás que volver a sincronizar la consola para que aparezcan tus juegos.</span>", "fa-dumpster-fire", "bg-red-600 text-white shadow-[0_0_20px_rgba(220,38,38,0.5)]");
            if(!seguro) return;
            mostrarCarga("LIMPIANDO", "Borrando portadas...", "fa-trash fa-bounce text-red-500");
            const items = document.querySelectorAll('.item-biblio');
            for(let item of items) { let cusaSpan = item.querySelector('span.font-mono'); if(cusaSpan) { const fdDel = new FormData(); fdDel.append('action', 'delete_game'); fdDel.append('cusa_id', cusaSpan.innerText); try { await fetch('api/library.php', { method: 'POST', body: fdDel }); } catch(e){} } }
            localStorage.removeItem('ps4_game_categories'); closeCustomModal(); ps5Notification("LIMPIEZA", "Biblioteca formateada.", "fa-broom"); cargarBibliotecaLocal();
        }

        function agregarJuegoHTML(game, index) {
            let tipoCorregido = game.type === 'game' ? 'juegos' : (game.type === 'app' ? 'apps' : game.type);
            let savedCats = JSON.parse(localStorage.getItem('ps4_game_categories')) || {}; let catAsignada = savedCats[game.id] || tipoCorregido || 'juegos';
            let iconSrc = game.icon ? game.icon + '?_t=' + new Date().getTime() : 'https://via.placeholder.com/256/111827/FFFFFF?text=' + game.id;
            let bgGrad = catAsignada === 'apps' ? 'blue-900/80' : 'black/95'; let imgClass = catAsignada === 'apps' ? 'grayscale opacity-50' : '';
            let safeTitle = game.title.replace(/'/g, "\\'").replace(/"/g, "&quot;"); let version = game.version || "1.00";
            let scrollAm = game.title.length > 15 ? "1" : "0";
            return `<div class="item-biblio game-card glass-panel rounded-2xl overflow-hidden relative group cursor-pointer aspect-square border-white/5 active:scale-95 shadow-lg animate-fade-in bg-white/5" data-category="${catAsignada}" data-name="${safeTitle}" data-id="${index}" onclick="abrirOpciones('${safeTitle}', '${game.id}', '${iconSrc}', '${version}')"><div class="absolute inset-0 flex items-center justify-center z-0"><i class="fa-solid fa-spinner fa-spin text-white/20 text-2xl"></i></div><img src="${iconSrc}" loading="lazy" onload="this.previousElementSibling.style.display='none'" class="w-full h-full object-cover relative z-10 ${imgClass}" onerror="this.src='https://via.placeholder.com/256/111827/FFFFFF?text=${game.id}'; this.previousElementSibling.style.display='none';"><div class="absolute inset-0 bg-gradient-to-t from-${bgGrad} via-black/40 to-transparent pointer-events-none z-20"></div><div class="absolute bottom-0 left-0 right-0 p-2 pointer-events-none z-30"><marquee behavior="alternate" scrollamount="${scrollAm}" class="w-full mt-1"><h3 class="text-[10px] font-black text-white leading-tight inline">${game.title}</h3></marquee><div class="flex items-center gap-1 mt-0.5"><i class="fa-solid fa-compact-disc text-[8px] text-white/70"></i><span class="text-[8px] text-white/80 font-mono">${game.id}</span></div></div></div>`;
        }

        async function cargarBibliotecaLocal() {
            const grid = document.getElementById('grid-biblioteca'); if(!grid) return;
            try {
                let res = await fetch('api/library.php?action=get_cached_games&_t=' + new Date().getTime()); let data = await res.json();
                if(data.status === 'success') {
                    let html = ''; data.data.forEach((game, index) => { html += agregarJuegoHTML(game, index); });
                    html += `<div onclick="abrirMenuInstalar()" class="game-card glass-panel rounded-2xl overflow-hidden relative cursor-pointer aspect-square border border-dashed border-white/20 active:scale-95 flex flex-col items-center justify-center bg-black/20" data-id="9999"><div class="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white mb-2"><i class="fa-solid fa-plus text-sm"></i></div><span class="text-[8px] font-bold tracking-widest text-white/50 text-center px-4 uppercase">Instalar Nuevo</span></div>`;
                    grid.innerHTML = html; 
                    let dashCount = document.getElementById('total-games-badge'); if(dashCount) dashCount.innerText = `${data.data.length}`;
                    const activeFilter = document.querySelector('.filter-pill.active'); if(activeFilter) filtrarCategoria(activeFilter.dataset.cat, activeFilter);
                }
            } catch(e) {}
        }

        let ordenActual = 0; 
        function cambiarOrden() {
            ordenActual++; if (ordenActual > 2) ordenActual = 0;
            const grid = document.getElementById('grid-biblioteca'); if(!grid) return;
            const cards = Array.from(grid.querySelectorAll('.game-card')).filter(card => card.dataset.id !== "9999");
            const btnInstalar = grid.querySelector('[data-id="9999"]'); const icono = document.getElementById('icono-orden');
            cards.forEach(card => card.classList.add('sorting-anim')); if(btnInstalar) btnInstalar.classList.add('sorting-anim');
            setTimeout(() => {
                if (ordenActual === 0) { icono.className = "fa-solid fa-arrow-down-short-wide text-xs text-blue-400 group-hover:text-white transition-colors"; cards.sort((a, b) => parseInt(a.dataset.id) - parseInt(b.dataset.id)); if(typeof ps5Notification === 'function') ps5Notification("ORDEN", "Instalación (Por Defecto)", "fa-clock"); } 
                else if (ordenActual === 1) { icono.className = "fa-solid fa-arrow-down-a-z text-xs text-green-400 group-hover:text-white transition-colors"; cards.sort((a, b) => a.dataset.name.localeCompare(b.dataset.name)); if(typeof ps5Notification === 'function') ps5Notification("ORDEN", "Alfabético (A-Z)", "fa-font"); } 
                else if (ordenActual === 2) { icono.className = "fa-solid fa-arrow-up-z-a text-xs text-purple-400 group-hover:text-white transition-colors"; cards.sort((a, b) => b.dataset.name.localeCompare(a.dataset.name)); if(typeof ps5Notification === 'function') ps5Notification("ORDEN", "Alfabético inverso (Z-A)", "fa-font"); }
                grid.innerHTML = ''; cards.forEach(card => grid.appendChild(card)); if(btnInstalar) grid.appendChild(btnInstalar);
                setTimeout(() => { const newCards = grid.querySelectorAll('.game-card'); newCards.forEach(c => c.classList.remove('sorting-anim')); const activeFilter = document.querySelector('.filter-pill.active'); if(activeFilter) filtrarCategoria(activeFilter.dataset.cat, activeFilter); }, 50);
            }, 200); 
        }

        let isSyncCanceled = false;
        function cancelarEnvio() { if (uploadAbortController) uploadAbortController.abort(); isSyncCanceled = true; const fUp = document.getElementById('file-upload'); if(fUp) { fUp.value = ''; updateFileName(fUp); } }

        async function simularSincronizacion() {
            const ip = document.getElementById('host-ip').value; if (!ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), 'fa-network-wired'); return; }
            mostrarCarga("SINCRONIZANDO", "Buscando en PS4...", "fa-brands fa-playstation"); isTransferring = true; isSyncCanceled = false; 
            try {
                const fd = new FormData(); fd.append('action', 'scan_list'); fd.append('host_ip', ip);
                let res = await fetch('api/library.php?_t=' + new Date().getTime(), { method: 'POST', body: fd }); let data = await res.json();
                if (data.status === 'success') {
                    const missing = data.missing; 
                    if (missing.length === 0) { AudioEngine.playSuccess(); closeCustomModal(); ps5Notification("AL DÍA", "Biblioteca sincronizada.", "fa-check-double"); cargarBibliotecaLocal(); isTransferring = false; return; }
                    document.getElementById('modal-progress-container').classList.remove('hidden'); document.getElementById('modal-controls').classList.remove('hidden'); document.getElementById('modal-action-btn').classList.add('hidden'); document.getElementById('modal-cancel-btn').classList.remove('hidden'); 
                    let count = 0;
                    for (let game of missing) {
                        if (isSyncCanceled) break; count++; 
                        document.getElementById('modal-title').innerText = `LEYENDO (${count}/${missing.length})`; let pct = (count / missing.length) * 100; document.getElementById('modal-progress-bar').style.width = pct + '%'; document.getElementById('modal-percentage').innerText = pct.toFixed(0) + '%'; document.getElementById('modal-text').innerText = game.id;
                        const fdData = new FormData(); fdData.append('action', 'get_game_data'); fdData.append('host_ip', ip); fdData.append('cusa_id', game.id);
                        try { await fetch('api/library.php', { method: 'POST', body: fdData }); } catch(e) {}
                    }
                    if (isSyncCanceled) { mostrarErrorFinal("CANCELADO", "Sincronización detenida."); cargarBibliotecaLocal(); } 
                    else { AudioEngine.playSuccess(); closeCustomModal(); ps5Notification("NUEVOS", `${count} títulos cargados.`, "fa-gamepad"); cargarBibliotecaLocal(); }
                } else { mostrarErrorFinal("ERROR", data.message || "No se pudo leer la biblioteca."); }
            } catch (e) { mostrarErrorFinal("ERROR", "Falló la conexión al escanear."); } finally { isTransferring = false; }
        }
        // ==========================================
        // FTP Y CARGA DE ARCHIVOS
        // ==========================================
        function selectPath(btn, path) { document.querySelectorAll('.folder-btn').forEach(el => el.classList.remove('active')); btn.classList.add('active'); document.getElementById('selected-path-input').value = path; }
        function showAddPathUI() { document.getElementById('add-path-ui').classList.remove('hidden'); }
        function hideAddPathUI() { document.getElementById('add-path-ui').classList.add('hidden'); document.getElementById('new-path-input').value = ''; }
        function saveNewPath() { let inputPath = document.getElementById('new-path-input').value.trim(); if (!inputPath) return; if (!inputPath.startsWith('/')) inputPath = '/' + inputPath; if (!inputPath.endsWith('/')) inputPath = inputPath + '/'; crearBotonCarpeta(inputPath, true); hideAddPathUI(); }
        function crearBotonCarpeta(path, isNew = false) { const grid = document.getElementById('paths-grid'); const btnAdd = document.getElementById('btn-otra'); const btnContainer = document.createElement('div'); btnContainer.className = 'relative group h-full flex'; btnContainer.innerHTML = `<button type="button" class="folder-btn btn-ps5 rounded-xl py-3 w-full text-[10px] font-bold text-white/60 border border-white/10 break-all px-2 pr-6" onclick="selectPath(this, '${path}')">${path}</button><div onclick="deleteCustomFolder('${path}', this.parentElement)" class="absolute top-1 right-1 w-5 h-5 flex items-center justify-center bg-red-500/80 rounded-full text-white cursor-pointer opacity-80 hover:opacity-100 z-10 transition-opacity"><i class="fa-solid fa-xmark text-[10px]"></i></div>`; grid.insertBefore(btnContainer, btnAdd); if (isNew) { selectPath(btnContainer.querySelector('.folder-btn'), path); let savedFolders = JSON.parse(localStorage.getItem('ps4_custom_folders')) || []; if (!savedFolders.includes(path)) { savedFolders.push(path); localStorage.setItem('ps4_custom_folders', JSON.stringify(savedFolders)); } } }
        async function deleteCustomFolder(path, containerDiv) { const confirmado = await ps5Confirm(t('j_del_route'), `${t('j_del_route_m')} <br><b class="text-white font-mono mt-2 block">${path}</b>?`, 'fa-folder-minus', 'bg-red-500 text-white border border-red-400'); if(!confirmado) return; containerDiv.remove(); let savedFolders = JSON.parse(localStorage.getItem('ps4_custom_folders')) || []; savedFolders = savedFolders.filter(p => p !== path); localStorage.setItem('ps4_custom_folders', JSON.stringify(savedFolders)); if (document.getElementById('selected-path-input').value === path) { document.querySelector('.folder-btn').click(); } ps5Notification(t('j_comp'), "Ruta borrada.", "fa-trash"); }
        function updateFileName(input) { const display = document.getElementById('file-name-display'); const iconContainer = document.getElementById('upload-icon-container'); if (input.files.length > 0) { display.innerText = input.files.length === 1 ? input.files[0].name : input.files.length + " " + t('j_files_sel'); display.classList.replace('text-white/50', 'text-white'); iconContainer.innerHTML = '<i class="fa-solid fa-check text-2xl text-black"></i>'; iconContainer.classList.replace('bg-white/5', 'bg-white'); iconContainer.classList.replace('text-white', 'text-black'); } else { display.innerText = t('touch_select'); display.classList.replace('text-white', 'text-white/50'); iconContainer.innerHTML = '<i class="fa-solid fa-cloud-arrow-up text-2xl"></i>'; iconContainer.classList.replace('bg-white', 'bg-white/5'); iconContainer.classList.replace('text-black', 'text-white'); } }

        function togglePauseResume(forceErrorState = false, errorMsg = "") { const btn = document.getElementById('modal-action-btn'); if (forceErrorState) { isPaused = true; btn.className = "flex-1 btn-ps5-primary rounded-2xl py-3.5 font-bold text-[10px] tracking-widest"; btn.innerText = 'REINTENTAR'; document.getElementById('modal-text').innerHTML = `Error: ${errorMsg}`; return; } isPaused = !isPaused; if (isPaused) { btn.innerText = t('j_resume'); document.getElementById('modal-text').innerHTML = 'EN PAUSA'; document.getElementById('modal-speed').innerHTML = '<i class="fa-solid fa-bolt"></i> -- MB/s'; document.getElementById('modal-eta').innerHTML = '<i class="fa-solid fa-clock"></i> ETA: Pausado'; } else { btn.innerText = t('modal_pause'); document.getElementById('modal-text').innerHTML = currentFileName; } }
        function formatETA(seconds) { if (!isFinite(seconds) || seconds < 0) return "--:--"; let m = Math.floor(seconds / 60); let s = Math.floor(seconds % 60); return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`; }

        async function enviarArchivoChunks(event) {
            event.preventDefault(); 
            const ip = document.getElementById('host-ip').value; const files = document.getElementById('file-upload').files; 
            if (!ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), 'fa-network-wired'); return; }
            if (files.length === 0) { await ps5Alert(t('j_err_file'), t('j_err_file_m'), 'fa-file-circle-xmark'); return; }
            await requestWakeLock(); uploadAbortController = new AbortController(); const signal = uploadAbortController.signal; isTransferring = true;
            mostrarCarga(t('j_prep'), t('j_prep_m'), "fa-hard-drive fa-fade"); let isCanceled = false, filesSuccess = 0; isPaused = false; 
            document.getElementById('modal-action-btn').innerText = t('modal_pause');
            for (let f = 0; f < files.length; f++) {
                if (signal.aborted) { isCanceled = true; break; }
                const file = files[f]; currentFileName = file.name; let fileTotalGB = (file.size / (1024 * 1024 * 1024)); let remoteSize = 0, isResume = false, promptAction = '';
                try {
                    let fdCheck = new FormData(); fdCheck.append('action', 'check_file'); fdCheck.append('host_ip', ip); fdCheck.append('path', document.getElementById('selected-path-input').value); fdCheck.append('file_name', file.name);
                    let resCheck = await fetch('api/upload.php', { method: 'POST', body: fdCheck, signal }); 
                    if(resCheck.ok) { let dataCheck = await resCheck.json(); if (dataCheck.size > 0 && dataCheck.size < file.size) promptAction = 'resume'; else if (dataCheck.size >= file.size) promptAction = 'exist'; if (promptAction !== '') { closeCustomModal(); await new Promise(r => setTimeout(r, 350)); if (promptAction === 'resume') { let reanudar = await ps5Confirm(t('j_resume'), `${t('j_resume_m')} <br><b class="text-white mt-1 block">${file.name}</b>?`, 'fa-clock-rotate-left', 'bg-blue-500 text-white'); if (reanudar) { remoteSize = dataCheck.size; isResume = true; } } else { let sobreescribir = await ps5Confirm(t('j_exist'), `<b class="text-white">${file.name}</b><br>${t('j_exist_m')}`, 'fa-copy', 'bg-yellow-500 text-black'); if(!sobreescribir) { filesSuccess++; continue; } } } }
                } catch (e) {}
                
                if(timeoutModalClose) clearTimeout(timeoutModalClose); 
                document.getElementById('custom-modal').classList.remove('hidden', 'opacity-0'); document.getElementById('modal-card').classList.remove('scale-95'); 
                document.getElementById('modal-icon').innerHTML = '<i class="fa-solid fa-cloud-arrow-up text-4xl text-white"></i>'; 
                document.getElementById('modal-progress-container').classList.remove('hidden'); document.getElementById('modal-controls').classList.remove('hidden'); 
                let uploadedBytes = remoteSize; document.getElementById('modal-title').innerText = `(${f + 1}/${files.length})`; document.getElementById('modal-text').innerHTML = file.name;
                
                while (uploadedBytes < file.size) {
                    if (signal.aborted) { isCanceled = true; break; }
                    while (isPaused) { if (signal.aborted) { isCanceled = true; break; } await new Promise(r => setTimeout(r, 500)); }
                    if (isCanceled) break;
                    let currentChunkSize = Math.min(CHUNK_SIZE, file.size - uploadedBytes); let chunk = file.slice(uploadedBytes, uploadedBytes + currentChunkSize); let isFirstRequest = (uploadedBytes === 0 && !isResume);
                    const formData = new FormData(); formData.append('action', 'upload_chunk'); formData.append('host_ip', ip); formData.append('selected_path', document.getElementById('selected-path-input').value); formData.append('file_name', file.name); formData.append('is_first_chunk', isFirstRequest ? 'true' : 'false'); formData.append('archivo_subida', chunk);
                    let chunkStartTime = Date.now(), retries = 0, maxRetries = 3, chunkSuccess = false;
                    while (!chunkSuccess && retries < maxRetries && !isCanceled) {
                        try {
                            let res = await new Promise((resolve, reject) => {
                                const xhr = new XMLHttpRequest(); xhr.open("POST", 'api/upload.php', true); const abortHandler = () => { xhr.abort(); reject(new DOMException("Aborted", "AbortError")); };
                                if (signal) { if (signal.aborted) return abortHandler(); signal.addEventListener("abort", abortHandler); }
                                xhr.upload.onprogress = (e) => { 
                                    if (!e.lengthComputable || isPaused) return; 
                                    let actualLoaded = uploadedBytes + e.loaded; let pct = (actualLoaded / file.size) * 100; 
                                    document.getElementById('modal-progress-bar').style.width = pct + '%'; document.getElementById('modal-percentage').innerText = pct.toFixed(0) + '%'; document.getElementById('modal-bytes').innerText = `${(actualLoaded / (1024 * 1024 * 1024)).toFixed(2)} / ${fileTotalGB.toFixed(2)} GB`; 
                                    let timeTaken = Math.max((Date.now() - chunkStartTime) / 1000, 0.001); 
                                    if (timeTaken > 0.5 && e.loaded > 0) { let speedMBps = (e.loaded / timeTaken) / (1024 * 1024); document.getElementById('modal-speed').innerHTML = `<i class="fa-solid fa-bolt text-white/40"></i> ${speedMBps.toFixed(1)} MB/s`; let remainingBytes = file.size - actualLoaded; let remainingSecs = speedMBps > 0 ? (remainingBytes / (speedMBps * 1024 * 1024)) : 0; document.getElementById('modal-eta').innerHTML = `<i class="fa-solid fa-clock text-white/40"></i> ETA: ${formatETA(remainingSecs)}`; } 
                                };
                                xhr.onload = () => { if (signal) signal.removeEventListener("abort", abortHandler); if (xhr.status >= 200 && xhr.status < 300) { try { resolve(JSON.parse(xhr.responseText)); } catch(err) { reject(new Error("Invalid JSON")); } } else { reject(new Error(`Server error: ${xhr.status}`)); } }; xhr.onerror = () => { if (signal) signal.removeEventListener("abort", abortHandler); reject(new Error("Network error")); }; xhr.send(formData);
                            });
                            if (res.status !== 'success') throw new Error(res.message); uploadedBytes += currentChunkSize; chunkSuccess = true;
                        } catch (error) { if (error.name === 'AbortError') { isCanceled = true; break; } retries++; if (retries >= maxRetries) { togglePauseResume(true, "Red inestable. Toca REINTENTAR."); break; } await new Promise(r => setTimeout(r, 2000)); } 
                    }
                    if(!chunkSuccess && !isCanceled) continue; 
                }
                if (isCanceled) break; filesSuccess++;
            }
            releaseWakeLock(); isTransferring = false;
            if (isCanceled) { mostrarErrorFinal(t('j_cancel'), t('j_cancel_m')); } else if (filesSuccess === files.length) { 
                AudioEngine.playSuccess(); document.getElementById('modal-progress-container').classList.add('hidden'); document.getElementById('modal-controls').classList.add('hidden'); document.getElementById('modal-close-btn').classList.remove('hidden'); document.getElementById('modal-title').innerText = t('j_comp'); document.getElementById('modal-text').innerHTML = t('j_comp_m'); document.getElementById('modal-icon').innerHTML = '<i class="fa-solid fa-check text-4xl text-white"></i>'; document.getElementById('modal-icon').className = "w-20 h-20 mx-auto rounded-full bg-white/20 border border-white flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(255,255,255,0.4)]"; document.getElementById('file-upload').value = ''; updateFileName(document.getElementById('file-upload')); ps5Notification(t('j_comp'), "Archivos enviados correctamente.", "fa-check");
            }
        }

        // ==========================================
        // GALERÍAS Y MODDING (PARCHE VISUAL INCLUIDO)
        // ==========================================
        function cargarGaleria(lista, containerId, folder) {
            const container = document.getElementById(containerId); container.innerHTML = '';
            if (!lista || lista.length === 0) { container.innerHTML = `<div class="flex flex-col items-center justify-center min-h-[220px] bg-black/20 rounded-[1.5rem] border border-dashed border-white/10 p-6 text-center"><i class="fa-solid fa-folder text-6xl mb-4 text-white/20"></i><p class="text-[11px] text-white/50 leading-relaxed max-w-[250px] mx-auto">${t('empty_gal_title').replace('{folder}', folder)}</p></div>`; return; }
            
            const topBar = document.createElement('div'); 
            topBar.className = 'flex justify-between items-center mb-3 px-1'; 
            topBar.innerHTML = `<span class="text-[10px] text-white/50 font-bold tracking-widest uppercase">${lista.length} PORTADAS</span><button onclick="eliminarTodasLasImagenes('${folder}')" class="text-red-500 hover:text-red-400 text-[10px] font-black tracking-widest transition-colors active:scale-95"><i class="fa-solid fa-trash-can mr-1"></i> ${t('del_all')}</button>`; 
            container.appendChild(topBar);
            
            const grid = document.createElement('div'); 
            grid.className = 'grid grid-cols-3 gap-2 overflow-y-auto custom-scrollbar pr-1 gallery-grid-fix'; 
            
            const deseleccionarEnScroll = () => {
                const items = grid.querySelectorAll('.gallery-item.selected');
                if(items.length > 0) {
                    items.forEach(el => el.classList.remove('selected'));
                    selectedIconValue = null;
                    const btnAplicar = document.getElementById('floating-btn-aplicar');
                    if(btnAplicar) btnAplicar.classList.add('floating-hidden');
                }
            };
            grid.addEventListener('scroll', deseleccionarEnScroll, { passive: true });
            grid.addEventListener('touchmove', deseleccionarEnScroll, { passive: true });
            
            lista.forEach(img => { 
                const item = document.createElement('div'); item.className = 'gallery-item group'; 
                item.onclick = function() { document.querySelectorAll(`#${containerId} .gallery-item`).forEach(el => el.classList.remove('selected')); this.classList.add('selected'); selectedIconValue = folder + '/' + img.nombre; document.getElementById('floating-btn-aplicar').classList.remove('floating-hidden'); }; 
                item.innerHTML = `<img src="${img.url}" loading="lazy"><div onclick="eliminarImagenGaleria('${img.nombre}', '${folder}', event)" class="absolute top-1 right-1 w-7 h-7 bg-red-600 rounded-full flex items-center justify-center text-white z-10 cursor-pointer shadow-lg gallery-trash-btn"><i class="fa-solid fa-trash text-[10px]"></i></div>`; 
                grid.appendChild(item); 
            });
            container.appendChild(grid);
        }
        
        async function eliminarImagenGaleria(nombre, folder, e) { e.stopPropagation(); const seguro = await ps5Confirm(t('opt_delete'), `¿Borrar la imagen <b>${nombre}</b> del servidor?`, "fa-trash", "bg-red-500 text-white"); if(!seguro) return; const fd = new FormData(); fd.append('action', 'delete_image'); fd.append('folder', folder); fd.append('file_name', nombre); try { let res = await fetch('api/gallery.php', { method:'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { if(folder === 'iconos') actualizarGaleria(); else actualizarBackups(); ps5Notification(t('j_comp'), "Imagen borrada del servidor.", "fa-trash"); document.getElementById('floating-btn-aplicar').classList.add('floating-hidden'); } else { ps5Alert(t('j_err'), data.message, "fa-triangle-exclamation"); } } catch(err) {} }
        async function eliminarTodasLasImagenes(folder) { const seguro = await ps5Confirm(t('del_all'), `¿Estás seguro de eliminar <b class="text-white">TODAS</b> las imágenes?`, "fa-skull-crossbones", "bg-red-600 text-white"); if(!seguro) return; mostrarCarga(t('j_del_sel'), "Eliminando imágenes...", "fa-trash fa-bounce text-red-500"); let list = folder === 'iconos' ? ICONOS_LOCALES : BACKUPS_LOCALES; for(let img of list) { const fd = new FormData(); fd.append('action', 'delete_image'); fd.append('folder', folder); fd.append('file_name', img.nombre); try { await fetch('api/gallery.php', { method:'POST', body: fd }); } catch(e){} } closeCustomModal(); if(folder === 'iconos') actualizarGaleria(); else actualizarBackups(); ps5Notification(t('j_comp'), "Carpeta vaciada completamente.", "fa-trash-can"); document.getElementById('floating-btn-aplicar').classList.add('floating-hidden'); }
        function previewLocal(input) { if (input.files && input.files[0]) { const reader = new FileReader(); reader.onload = function(e) { document.getElementById('preview-img-local').src = e.target.result; document.getElementById('preview-img-local').classList.remove('hidden'); document.getElementById('icon-file-placeholder').classList.add('hidden'); document.getElementById('icon-file-name').innerText = input.files[0].name; document.getElementById('floating-btn-aplicar').classList.remove('floating-hidden'); }; reader.readAsDataURL(input.files[0]); } }
        function ejecutarFormIconos() { const form = document.getElementById('icon-form'); if (form.reportValidity()) document.getElementById('icon-form-submit').click(); }
        function switchIconSource(type) { currentIconSource = type; ['btn-src-gallery', 'btn-src-backup', 'btn-src-import', 'btn-src-local'].forEach(id => document.getElementById(id).className = "flex-1 py-3 px-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors whitespace-nowrap"); ['box-src-gallery', 'box-src-backup', 'box-src-import', 'box-src-local'].forEach(id => document.getElementById(id).classList.add('hidden')); document.getElementById(`btn-src-${type}`).className = "flex-1 py-3 px-3 text-[9px] font-bold tracking-widest rounded-xl bg-white text-black shadow-lg whitespace-nowrap"; document.getElementById(`box-src-${type}`).classList.remove('hidden'); if(type === 'import') document.getElementById('floating-btn-aplicar').classList.add('floating-hidden'); else document.getElementById('floating-btn-aplicar').classList.remove('floating-hidden'); if(type === 'gallery') actualizarGaleria(); if(type === 'backup') actualizarBackups(); }
        async function importarURL() { const urlInput = document.getElementById('import-url').value.trim(); if (!urlInput) return; mostrarCarga("IMPORTANDO", "Descargando imágenes...", "fa-cloud-arrow-down fa-bounce"); isTransferring = true; const fd = new FormData(); fd.append('action', 'import_url'); fd.append('url', urlInput); try { let res = await fetch('api/gallery.php', { method: 'POST', body: fd }); let data = await res.json(); if (data.status === 'success') { AudioEngine.playSuccess(); closeCustomModal(); document.getElementById('import-url').value = ''; await actualizarGaleria(); switchIconSource('gallery'); ps5Notification(t('j_comp'), "Imágenes guardadas.", "fa-download"); } else { mostrarErrorFinal(t('j_err'), data.message); } } catch (e) { mostrarErrorFinal(t('j_err'), "Error de red."); } finally { isTransferring = false; } }
        async function actualizarGaleria() { try { let res = await fetch('api/gallery.php?action=get_gallery&_t=' + new Date().getTime()); let data = await res.json(); if (data.status === 'success') { ICONOS_LOCALES = data.data; cargarGaleria(ICONOS_LOCALES, 'gallery-container', 'iconos'); } } catch(e) {} }
        async function actualizarBackups() { try { let res = await fetch('api/gallery.php?action=get_backups&_t=' + new Date().getTime()); let data = await res.json(); if (data.status === 'success') { BACKUPS_LOCALES = data.data; cargarGaleria(BACKUPS_LOCALES, 'backup-container', 'backup_icons'); } } catch(e) {} }
        async function respaldarOriginal() { const ip = document.getElementById('host-ip').value, cusa = document.getElementById('icon-cusa').value.trim().toUpperCase(); if (!ip || !cusa) return; mostrarCarga("EXTRAYENDO", "Descargando portada...", "fa-download fa-bounce"); isTransferring = true; const fd = new FormData(); fd.append('action', 'backup_original'); fd.append('host_ip', ip); fd.append('cusa_id', cusa); try { let res = await fetch('api/modding.php', { method: 'POST', body: fd }); let data = await res.json(); if (data.status === 'success') { AudioEngine.playSuccess(); closeCustomModal(); switchIconSource('backup'); ps5Notification(t('j_comp'), `Portada guardada.`, "fa-download"); } else { mostrarErrorFinal(t('j_err'), data.message); } } catch (e) { mostrarErrorFinal(t('j_err'), "Error de red."); } finally { isTransferring = false; } }
        async function respaldarTodos() { const ip = document.getElementById('host-ip').value; if (!ip) return; mostrarCarga("ESCANEO", "Leyendo biblioteca...", "fa-brands fa-playstation"); isTransferring = true; try { const fd = new FormData(); fd.append('action', 'get_all_cusa'); fd.append('host_ip', ip); let res = await fetch('api/modding.php', { method: 'POST', body: fd }); let data = await res.json(); if (data.status === 'success' && data.juegos.length > 0) { await actualizarBackups(); let existentes = BACKUPS_LOCALES.map(b => b.nombre.split('_')[0]); let juegosFaltantes = data.juegos.filter(c => !existentes.includes(c)); if(juegosFaltantes.length === 0) { closeCustomModal(); ps5Notification(t('j_comp'), "Todas respaldadas.", "fa-check-double"); isTransferring = false; return; } let exitos = 0; document.getElementById('modal-progress-container').classList.remove('hidden'); document.getElementById('modal-controls').classList.add('hidden'); for(let i=0; i < juegosFaltantes.length; i++) { let cusa = juegosFaltantes[i]; document.getElementById('modal-title').innerText = `SAQUEO (${i+1}/${juegosFaltantes.length})`; let pct = ((i) / juegosFaltantes.length) * 100; document.getElementById('modal-progress-bar').style.width = pct + '%'; document.getElementById('modal-percentage').innerText = pct.toFixed(0) + '%'; const fdBak = new FormData(); fdBak.append('action', 'backup_original'); fdBak.append('host_ip', ip); fdBak.append('cusa_id', cusa); try { let r = await fetch('api/modding.php', { method: 'POST', body: fdBak }); let d = await r.json(); if (d.status === 'success') exitos++; if (exitos % 2 === 0) actualizarBackups(); } catch(e) {} } document.getElementById('modal-progress-bar').style.width = '100%'; document.getElementById('modal-percentage').innerText = '100%'; AudioEngine.playSuccess(); closeCustomModal(); switchIconSource('backup'); ps5Notification(t('j_comp'), "Completado.", "fa-layer-group"); } else { mostrarErrorFinal(t('j_err'), "No se encontraron juegos."); } } catch(e) { mostrarErrorFinal(t('j_err'), "Falló la conexión."); } finally { isTransferring = false; } }
        async function enviarIcono(e) { e.preventDefault(); const ip = document.getElementById('host-ip').value, cusa = document.getElementById('icon-cusa').value.trim().toUpperCase(); if (!ip || !cusa) return; const formData = new FormData(); formData.append('action', 'upload_icon'); formData.append('host_ip', ip); formData.append('cusa_id', cusa); if (currentIconSource === 'gallery' || currentIconSource === 'backup') { if (!selectedIconValue) { await ps5Alert(t('j_err_file'), "Selecciona una imagen.", 'fa-image'); return; } formData.append('source_type', 'local_gallery'); formData.append('icon_path', selectedIconValue); } else { const fileInput = document.getElementById('icon-file'); if (!fileInput || !fileInput.files || fileInput.files.length === 0) { await ps5Alert(t('j_err_file'), "Busca una imagen.", 'fa-folder-open'); return; } formData.append('source_type', 'local'); formData.append('local_icon', fileInput.files[0]); } mostrarCarga("MODDING", "Inyectando portada...", "fa-wand-magic-sparkles fa-bounce"); isTransferring = true; try { let res = await fetch('api/modding.php', { method: 'POST', body: formData }); let data = await res.json(); if (data.status === 'success') { AudioEngine.playSuccess(); document.getElementById('modal-title').innerText = t('j_succ'); document.getElementById('modal-text').innerHTML = "Portada inyectada."; document.getElementById('modal-close-btn').classList.remove('hidden'); document.getElementById('modal-icon').innerHTML = '<div class="absolute inset-0 rounded-full border border-white/30 animate-ping"></div><i class="fa-solid fa-palette text-4xl text-white relative z-10"></i>'; ps5Notification("MODDING", "Arte aplicado.", "fa-palette"); } else { mostrarErrorFinal(t('j_err'), data.message); } } catch (error) { mostrarErrorFinal(t('j_err'), "Error de conexión."); } finally { isTransferring = false; } }

        // ==========================================
        // PAYLOADS (PARCHE VISUAL INCLUIDO)
        // ==========================================
        function cargarPayloads(lista, containerId) { 
            const container = document.getElementById(containerId); container.innerHTML = ''; 
            if (!lista || lista.length === 0) { container.innerHTML = `<div class="flex flex-col items-center justify-center min-h-[220px] bg-black/20 rounded-[1.5rem] border border-dashed border-white/10 p-6 text-center"><i class="fa-solid fa-folder text-6xl mb-4 text-white/20"></i><p class="text-[11px] text-white/50 leading-relaxed max-w-[250px] mx-auto">${t('empty_pay_title')}</p></div>`; return; } 
            
            const topBar = document.createElement('div'); 
            topBar.className = 'flex justify-between items-center mb-4 pr-1 bg-black/40 rounded-xl p-2 border border-white/5'; 
            topBar.innerHTML = `<span class="text-[10px] text-white/50 font-bold tracking-widest pl-2 uppercase">${lista.length} PAYLOADS</span><button class="bg-transparent px-4 py-2"></button>`; 
            container.appendChild(topBar);

            const grid = document.createElement('div'); 
            grid.className = 'flex flex-col gap-2 overflow-y-auto custom-scrollbar pr-1 gallery-grid-fix'; 
            
            lista.forEach(bin => { 
                const item = document.createElement('div'); item.className = 'payload-item flex items-center justify-between p-3 rounded-xl cursor-pointer bg-black/40 hover:bg-white/10 border border-white/5 transition-colors group'; 
                item.onclick = function() { document.querySelectorAll(`#${containerId} .payload-item`).forEach(el => el.classList.remove('selected')); this.classList.add('selected'); selectedPayloadValue = 'payloads/' + bin.nombre; }; 
                item.innerHTML = `<div class="flex items-center gap-3"><i class="fa-solid fa-file-code text-white/40 text-lg"></i><span class="text-xs font-mono text-white tracking-wide">${bin.nombre}</span></div><button type="button" onclick="eliminarPayloadServidor('${bin.nombre}', event)" class="w-8 h-8 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors z-10 shrink-0"><i class="fa-solid fa-trash text-xs"></i></button>`; 
                grid.appendChild(item); 
            }); 
            container.appendChild(grid); 
        }
        
        async function eliminarPayloadServidor(nombre, e) { e.stopPropagation(); const seguro = await ps5Confirm(t('opt_delete'), `¿Borrar <b>${nombre}</b>?`, "fa-trash", "bg-red-500 text-white"); if(!seguro) return; const fd = new FormData(); fd.append('action', 'delete_payload'); fd.append('file_name', nombre); try { let res = await fetch('api/payload.php', { method:'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { actualizarPayloads(); ps5Notification(t('j_comp'), "Payload borrado.", "fa-trash"); } else ps5Alert(t('j_err'), data.message, "fa-triangle-exclamation"); } catch(err) {} }
        async function actualizarPayloads() { try { let res = await fetch('api/payload.php?action=get_payloads&_t=' + new Date().getTime()); let data = await res.json(); if (data.status === 'success') { PAYLOADS_LOCALES = data.data; } } catch(e) {} cargarPayloads(PAYLOADS_LOCALES, 'payload-gallery-container'); }
        function switchPayloadSource(type) { currentPayloadSource = type; document.getElementById('btn-pay-gallery').className = "flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors"; document.getElementById('btn-pay-local').className = "flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl text-white/50 hover:text-white transition-colors"; document.getElementById('box-pay-gallery').classList.add('hidden'); document.getElementById('box-pay-local').classList.add('hidden'); if(type === 'gallery') { document.getElementById('btn-pay-gallery').className = "flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl bg-white text-black shadow-lg"; document.getElementById('box-pay-gallery').classList.remove('hidden'); actualizarPayloads(); } else { document.getElementById('btn-pay-local').className = "flex-1 py-3 text-[9px] font-bold tracking-widest rounded-xl bg-white text-black shadow-lg"; document.getElementById('box-pay-local').classList.remove('hidden'); } }
        function updatePayloadName(input) { const display = document.getElementById('payload-name-display'), iconContainer = document.getElementById('payload-icon-container'); if (input.files.length > 0) { display.innerText = input.files[0].name; display.classList.replace('text-white/50', 'text-white'); iconContainer.innerHTML = '<i class="fa-solid fa-check text-2xl text-black"></i>'; iconContainer.classList.replace('bg-white/5', 'bg-white'); iconContainer.classList.replace('text-white', 'text-black'); } else { display.innerText = t('touch_bin'); display.classList.replace('text-white', 'text-white/50'); iconContainer.innerHTML = '<i class="fa-solid fa-file-code text-2xl"></i>'; iconContainer.classList.replace('bg-white', 'bg-white/5'); iconContainer.classList.replace('text-black', 'text-white'); } }
        async function enviarPayload(e) { e.preventDefault(); const ip = document.getElementById('host-ip').value, port = document.getElementById('payload-port').value; if (!ip) { await ps5Alert(t('j_err_ip'), t('j_err_ip_m'), 'fa-network-wired'); return; } const formData = new FormData(); formData.append('action', 'send_payload'); formData.append('host_ip', ip); formData.append('port', port); if (currentPayloadSource === 'gallery') { if (!selectedPayloadValue) { await ps5Alert(t('j_err_file'), t('j_err_file_m'), 'fa-microchip'); return; } formData.append('source_type', 'gallery'); formData.append('payload_path', selectedPayloadValue); } else { const fileInput = document.getElementById('payload-file'); if (!fileInput.files.length) { await ps5Alert(t('j_err_file'), t('j_err_file_m'), 'fa-file-code'); return; } formData.append('source_type', 'local'); formData.append('payload_file', fileInput.files[0]); } mostrarCarga(t('j_inj'), t('j_inj_m'), "fa-microchip fa-bounce"); isTransferring = true; try { let res = await fetch('api/payload.php', { method: 'POST', body: formData }); let data = await res.json(); if (data.status === 'success') { AudioEngine.playSuccess(); document.getElementById('modal-title').innerText = t('j_succ'); document.getElementById('modal-text').innerHTML = data.message; document.getElementById('modal-close-btn').classList.remove('hidden'); document.getElementById('modal-icon').innerHTML = '<i class="fa-solid fa-check text-4xl text-white"></i>'; document.getElementById('modal-icon').className = "w-20 h-20 mx-auto rounded-full bg-white/20 border border-white flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(255,255,255,0.4)]"; if(currentPayloadSource === 'local') { document.getElementById('payload-file').value = ''; updatePayloadName(document.getElementById('payload-file')); } ps5Notification("INYECCIÓN", "Payload enviado.", "fa-bolt"); } else { mostrarErrorFinal(t('j_err'), data.message); } } catch (error) { mostrarErrorFinal(t('j_err'), t('j_err_net')); } finally { isTransferring = false; } }

        // ==========================================
        // EXPLORADOR FTP: VISOR, DESCARGA Y MULTI-MOVER
        // ==========================================
        function renderShortcuts() { let shortcuts = JSON.parse(localStorage.getItem('ps4_explorer_shortcuts')) || []; const container = document.getElementById('explorer-shortcuts'); if(shortcuts.length === 0) { container.classList.add('hidden'); return; } container.classList.remove('hidden'); let html = '<i class="fa-solid fa-star text-yellow-500/50 text-[10px] mr-1 shrink-0"></i>'; shortcuts.forEach(path => { let name = path === '/' ? 'RAÍZ' : path.split('/').filter(Boolean).pop(); html += `<div class="flex items-center gap-1 bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-full text-[10px] font-bold text-white cursor-pointer whitespace-nowrap group"><span onclick="loadExplorerPath('${path}')" class="truncate max-w-[80px]">${name}</span><div onclick="removeShortcut('${path}', event)" class="w-4 h-4 rounded-full bg-black/40 hover:bg-red-500/80 flex items-center justify-center ml-1 transition-colors"><i class="fa-solid fa-xmark text-[10px] text-white/50 group-hover:text-white"></i></div></div>`; }); container.innerHTML = html; }
        function addCurrentPathToShortcuts() { if(!currentExplorerPath) return; let shortcuts = JSON.parse(localStorage.getItem('ps4_explorer_shortcuts')) || []; if(!shortcuts.includes(currentExplorerPath)) { shortcuts.push(currentExplorerPath); localStorage.setItem('ps4_explorer_shortcuts', JSON.stringify(shortcuts)); renderShortcuts(); ps5Notification(t('j_comp'), "Ruta añadida.", "fa-star"); } }
        async function removeShortcut(path, e) { e.stopPropagation(); const seguro = await ps5Confirm(t('opt_delete'), `¿Quitar acceso a <br><b class="text-white mt-1 block">${path}</b>?`, 'fa-star-half-stroke', 'bg-red-500 text-white'); if(!seguro) return; let shortcuts = JSON.parse(localStorage.getItem('ps4_explorer_shortcuts')) || []; shortcuts = shortcuts.filter(p => p !== path); localStorage.setItem('ps4_explorer_shortcuts', JSON.stringify(shortcuts)); renderShortcuts(); ps5Notification(t('j_comp'), "Removido.", "fa-trash"); }
        function toggleSelectMode() { isSelectMode = !isSelectMode; selectedItems = []; const btn = document.getElementById('btn-select-mode'), panel = document.getElementById('multi-action-panel'); if (isSelectMode) { btn.classList.add('bg-blue-600', 'border-blue-500'); panel.classList.remove('hidden'); } else { btn.classList.remove('bg-blue-600', 'border-blue-500'); panel.classList.add('hidden'); } if(currentExplorerItems) renderExplorer(currentExplorerItems, currentExplorerPath); }
        function toggleSelectItem(path, isDir, name) { let idx = selectedItems.findIndex(i => i.path === path); if(idx > -1) { selectedItems.splice(idx, 1); } else { selectedItems.push({path, isDir, name}); } document.getElementById('multi-select-count').innerText = `${selectedItems.length} ${t('j_sel')}`; renderExplorer(currentExplorerItems, currentExplorerPath); }
        async function deleteSelectedItems() { if (selectedItems.length === 0) return; const seguro1 = await ps5Confirm(t('j_del_sel'), `${t('j_del_m1')} <b class="text-white">${selectedItems.length} ${t('j_elem')}</b>?`, 'fa-trash', 'bg-red-500 text-white'); if(!seguro1) return; const seguro2 = await ps5Confirm(t('j_warn'), t('j_warn_m'), 'fa-triangle-exclamation', 'bg-red-600 text-white border border-red-400'); if(!seguro2) return; mostrarCarga(t('j_del_sel'), `Borrando...`, "fa-trash fa-bounce text-red-500"); let successCount = 0; const ip = document.getElementById('host-ip').value; isTransferring = true; for (let i = 0; i < selectedItems.length; i++) { let item = selectedItems[i]; const fd = new FormData(); fd.append('action', 'delete_item'); fd.append('host_ip', ip); fd.append('path', item.path); fd.append('is_dir', item.isDir); try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') successCount++; } catch(e) {} } isTransferring = false; closeCustomModal(); toggleSelectMode(); loadExplorerPath(currentExplorerPath); ps5Notification(t('j_comp'), `${successCount} borrados.`, "fa-trash"); }
        async function loadExplorerPath(path) { const ip = document.getElementById('host-ip').value; if(!ip) return; if(isSelectMode && path !== currentExplorerPath) toggleSelectMode(); document.getElementById('explorer-path-text').innerText = path; currentExplorerPath = path; document.getElementById('explorer-list').innerHTML = `<div class="text-center text-white/50 text-xs py-10"><i class="fa-solid fa-circle-notch fa-spin text-3xl mb-3 block"></i>${t('searching')}</div>`; const fd = new FormData(); fd.append('action', 'list_dir'); fd.append('host_ip', ip); fd.append('path', path); isTransferring = true; try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if (data.status === 'success') renderExplorer(data.data, path); else document.getElementById('explorer-list').innerHTML = `<div class="text-center text-red-400 text-xs py-10">${data.message}</div>`; } catch(e) { } finally { isTransferring = false; } }
        function renderExplorer(items, currentPath) { currentExplorerItems = items; const listContainer = document.getElementById('explorer-list'); listContainer.innerHTML = ''; if (currentPath !== '/') { let parentPath = currentPath.substring(0, currentPath.lastIndexOf('/', currentPath.length - 2)) + '/'; if(parentPath === '') parentPath = '/'; listContainer.innerHTML += `<div onclick="loadExplorerPath('${parentPath}')" class="flex items-center gap-4 p-3 rounded-xl hover:bg-white/10 cursor-pointer transition-colors"><i class="fa-solid fa-level-up-alt text-xl text-white/50"></i><span class="text-sm font-medium text-white/80">Volver</span></div>`; } items.forEach(item => { let isDir = item.is_dir; let icon = isDir ? 'fa-folder text-yellow-500/80' : 'fa-file-lines text-white/40'; let nextPath = currentPath.endsWith('/') ? currentPath + item.name : currentPath + '/' + item.name; let isChecked = selectedItems.some(i => i.path === nextPath); let cleanName = item.name.replace(/'/g, "\\'"); let clickAction = isSelectMode ? `onclick="toggleSelectItem('${nextPath}', ${isDir}, '${cleanName}')"` : (isDir ? `onclick="loadExplorerPath('${nextPath}')"` : ''); let checkboxHTML = isSelectMode ? `<div class="w-5 h-5 rounded border border-white/30 flex items-center justify-center shrink-0 mr-1 ${isChecked ? 'bg-blue-500 border-blue-500' : ''}"><i class="fa-solid fa-check text-[10px] text-white ${isChecked ? 'opacity-100' : 'opacity-0'}"></i></div>` : ''; listContainer.innerHTML += `<div class="flex items-center justify-between p-3 rounded-xl transition-colors border ${isChecked ? 'bg-blue-500/20 border-blue-500/50' : 'hover:bg-white/10 border-transparent'}"><div class="flex items-center gap-3 flex-1 cursor-pointer overflow-hidden" ${clickAction}>${checkboxHTML}<i class="fa-solid ${icon} text-2xl w-6 text-center shrink-0"></i><div class="flex flex-col overflow-hidden"><span class="text-sm font-medium text-white tracking-wide truncate pr-2">${item.name}</span></div></div>${!isSelectMode ? `<button onclick="openItemOptions('${nextPath}', '${cleanName}', ${isDir})" class="text-white/50 hover:text-white p-2 px-3 shrink-0"><i class="fa-solid fa-ellipsis-vertical"></i></button>` : ''}</div>`; }); }
        function openItemOptions(path, name, isDir) { optionsPath = path; optionsName = name; optionsIsDir = isDir; document.getElementById('sheet-title').innerText = name; if(isDir) { document.getElementById('btn-view-file').classList.add('hidden'); document.getElementById('btn-download-file').classList.add('hidden'); } else { document.getElementById('btn-view-file').classList.remove('hidden'); document.getElementById('btn-download-file').classList.remove('hidden'); } document.getElementById('overlay-sheet').classList.add('open'); document.getElementById('bottom-sheet').classList.add('open'); }
        function closeItemOptions() { document.getElementById('overlay-sheet').classList.remove('open'); document.getElementById('bottom-sheet').classList.remove('open'); }
        async function viewCurrentFile() { closeItemOptions(); mostrarCarga("LEYENDO", "Obteniendo archivo...", "fa-file-lines fa-bounce"); const ip = document.getElementById('host-ip').value; const fd = new FormData(); fd.append('action', 'read_file'); fd.append('host_ip', ip); fd.append('path', optionsPath); try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); closeCustomModal(); if (data.status === 'success') { const viewer = document.getElementById('file-viewer-modal'), content = document.getElementById('file-viewer-content'); document.getElementById('file-viewer-title').innerText = optionsName; if (data.type === 'image') { content.innerHTML = `<img src="${data.data}" class="max-w-full max-h-full object-contain rounded-lg shadow-2xl">`; } else { content.innerHTML = `<pre class="text-[10px] text-white/80 font-mono whitespace-pre-wrap break-words w-full h-full text-left bg-black/40 p-4 rounded-xl border border-white/5">${data.data}</pre>`; } viewer.classList.remove('hidden'); setTimeout(() => viewer.classList.remove('opacity-0'), 10); } else { ps5Alert(t('j_err'), data.message, "fa-triangle-exclamation"); } } catch(e) { closeCustomModal(); ps5Alert(t('j_err'), "Error al leer.", "fa-wifi"); } }
        function closeFileViewer() { const viewer = document.getElementById('file-viewer-modal'); viewer.classList.add('opacity-0'); setTimeout(() => { viewer.classList.add('hidden'); document.getElementById('file-viewer-content').innerHTML = ''; }, 300); }
        function downloadCurrentFile() { closeItemOptions(); const ip = document.getElementById('host-ip').value; window.location.href = `api/explorer.php?action=download&host_ip=${ip}&path=${encodeURIComponent(optionsPath)}`; ps5Notification(t('j_comp'), "Iniciada.", "fa-download"); }
        async function renameCurrentItem() { closeItemOptions(); let newName = await ps5Prompt(t('j_ren'), t('j_ren_m'), optionsName); if(!newName || newName === optionsName) return; let pathParts = optionsPath.split('/').filter(Boolean); pathParts.pop(); let basePath = '/' + pathParts.join('/') + (pathParts.length > 0 ? '/' : ''); let newPath = basePath + newName + (optionsIsDir ? '/' : ''); const fd = new FormData(); fd.append('action', 'rename'); fd.append('host_ip', document.getElementById('host-ip').value); fd.append('old_path', optionsPath); fd.append('new_path', newPath); isTransferring = true; try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { loadExplorerPath(currentExplorerPath); ps5Notification(t('j_comp'), "Éxito.", "fa-pen"); } } catch(e) {} finally { isTransferring = false; } }
        function cutCurrentItem() { closeItemOptions(); clipboardItems = [{path: optionsPath, name: optionsName, isDir: optionsIsDir}]; isCutMode = true; document.getElementById('clipboard-panel').classList.remove('hidden'); document.getElementById('clipboard-text').innerText = optionsName; ps5Notification(t('j_comp'), "Listo para mover.", "fa-scissors"); }
        function cutSelectedItems() { if (selectedItems.length === 0) return; clipboardItems = [...selectedItems]; isCutMode = true; toggleSelectMode(); document.getElementById('clipboard-panel').classList.remove('hidden'); document.getElementById('clipboard-text').innerText = `${clipboardItems.length} copiados`; ps5Notification(t('j_comp'), "Listos para mover.", "fa-scissors"); }
        function cancelPaste() { clipboardItems = []; isCutMode = false; document.getElementById('clipboard-panel').classList.add('hidden'); ps5Notification(t('j_cancel'), "", "fa-xmark"); }
        async function executePaste() { if(clipboardItems.length === 0) return; const ip = document.getElementById('host-ip').value; mostrarCarga("MOVIENDO", "Reubicando...", "fa-people-carry-box fa-bounce"); let successCount = 0; isTransferring = true; for (let item of clipboardItems) { let name = item.name || item.path.split('/').filter(Boolean).pop(); let newPath = currentExplorerPath.endsWith('/') ? currentExplorerPath + name : currentExplorerPath + '/' + name; const fd = new FormData(); fd.append('action', 'rename'); fd.append('host_ip', ip); fd.append('old_path', item.path); fd.append('new_path', newPath); try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') successCount++; } catch(e) {} } isTransferring = false; cancelPaste(); closeCustomModal(); loadExplorerPath(currentExplorerPath); ps5Notification(t('j_comp'), `${successCount} reubicados.`, "fa-check"); }
        async function deleteCurrentItem() { closeItemOptions(); const seguro1 = await ps5Confirm(t('j_del1'), `${t('j_del1')} <b class="text-white">${optionsName}</b>?`, 'fa-trash', 'bg-red-500 text-white'); if(!seguro1) return; const seguro2 = await ps5Confirm(t('j_warn'), t('j_warn_m'), 'fa-triangle-exclamation', 'bg-red-600 text-white border border-red-400'); if(!seguro2) return; const fd = new FormData(); fd.append('action', 'delete_item'); fd.append('host_ip', document.getElementById('host-ip').value); fd.append('path', optionsPath); fd.append('is_dir', optionsIsDir); isTransferring = true; try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { loadExplorerPath(currentExplorerPath); ps5Notification(t('j_comp'), "Éxito.", "fa-trash"); } } catch(e) {} finally { isTransferring = false; } }
        async function promptCreateFolder() { let name = await ps5Prompt(t('j_new_fold'), t('j_new_fold_m')); if(!name) return; let newPath = currentExplorerPath.endsWith('/') ? currentExplorerPath + name : currentExplorerPath + '/' + name; const fd = new FormData(); fd.append('action', 'mkdir'); fd.append('host_ip', document.getElementById('host-ip').value); fd.append('path', newPath); isTransferring = true; try { let res = await fetch('api/explorer.php', { method: 'POST', body: fd }); let data = await res.json(); if(data.status === 'success') { loadExplorerPath(currentExplorerPath); ps5Notification(t('j_comp'), "Creada.", "fa-folder-plus"); } } catch(e) {} finally { isTransferring = false; } }

        // ==========================================
        // ESCANER DE RED Y PERFIL
        // ==========================================
        async function cambiarNombreUsuario() { if(!wasConnected) { await ps5Alert("DESCONECTADO", "Debes estar conectado.", "fa-plug-circle-xmark"); return; } let nuevoNombre = await ps5Prompt("NOMBRE DE USUARIO", "Introduce tu nombre:", customUserName); if(nuevoNombre && nuevoNombre.trim() !== "") { customUserName = nuevoNombre.trim().toUpperCase(); localStorage.setItem('ps4_custom_username', customUserName); document.getElementById('profile-name').innerText = customUserName; ps5Notification(t('j_comp'), "Actualizado.", "fa-user"); } }
        async function fetchPS4Profile(ip) { if (cachedAvatar) { aplicarAvatar(cachedAvatar, customUserName); return; } isTransferring = true; const fd = new FormData(); fd.append('action', 'get_ps4_profile'); fd.append('host_ip', ip); try { let res = await fetch('api/modding.php', { method: 'POST', body: fd }); let data = await res.json(); if (data.status === 'success' && data.avatar) { cachedAvatar = data.avatar; aplicarAvatar(cachedAvatar, customUserName); } else { aplicarAvatar(null, customUserName); } } catch(e) { aplicarAvatar(null, customUserName); } finally { isTransferring = false; } }
        function aplicarAvatar(base64Img, nombre) { const av = document.getElementById('profile-avatar'), ini = document.getElementById('profile-initial'), nm = document.getElementById('profile-name'); if(!av) return; if (base64Img) { av.style.backgroundImage = `url('${base64Img}')`; av.style.backgroundColor = 'transparent'; av.style.borderColor = 'rgba(255,255,255,0.2)'; av.classList.remove('rounded-full'); av.classList.add('rounded-xl'); if(ini) ini.classList.add('hidden'); } else { av.style.backgroundImage = ''; av.style.backgroundColor = '#2563EB'; av.style.borderColor = '#1D4ED8'; av.classList.remove('rounded-xl'); av.classList.add('rounded-full'); if(ini) { ini.innerText = nombre.charAt(0); ini.classList.remove('hidden'); } } if(nm) { nm.innerText = nombre; nm.classList.replace('text-[#A1A1AA]', 'text-white'); } }
        function resetAvatarLocal() { const av = document.getElementById('profile-avatar'), ini = document.getElementById('profile-initial'), nm = document.getElementById('profile-name'); if(!av) return; av.style.backgroundImage = ''; av.style.backgroundColor = '#549E43'; av.style.borderColor = '#386C2B'; av.classList.remove('rounded-xl'); av.classList.add('rounded-full'); if(ini) { ini.innerText = 'S'; ini.classList.remove('hidden'); } if(nm) { nm.innerText = 'BY SEBAS'; nm.classList.replace('text-white', 'text-[#A1A1AA]'); } }

        const SUBRED_PHP = "<?php echo isset($subred_actual) ? $subred_actual : ''; ?>";
        function setPS4State(isConnected) { if (wasConnected === true && isConnected === false) { AudioEngine.playDisconnect(); resetAvatarLocal(); ps5Notification(t('j_err'), "Se perdió la conexión.", "fa-plug-circle-xmark"); } wasConnected = isConnected; const badgeOn = document.getElementById('badge-detectada'), badgeOff = document.getElementById('badge-desconectada'); if(isConnected) { badgeOn.classList.remove('hidden'); badgeOn.classList.add('flex'); badgeOff.classList.add('hidden'); badgeOff.classList.remove('flex'); const ipEl = document.getElementById('host-ip'); if(ipEl && ipEl.value) fetchPS4Profile(ipEl.value); } else { badgeOff.classList.remove('hidden'); badgeOff.classList.add('flex'); badgeOn.classList.add('hidden'); badgeOn.classList.remove('flex'); resetAvatarLocal(); } }
        function startConnectionMonitor(ip) { if(connectionMonitorInterval) clearInterval(connectionMonitorInterval); failedPings = 0; setPS4State(true); connectionMonitorInterval = setInterval(async () => { if (isTransferring) return; try { const checkController = new AbortController(); const timeoutId = setTimeout(() => checkController.abort(), 6000); let res = await fetch(`api/scanner.php?ip=${ip}`, { signal: checkController.signal, cache: 'no-store' }); clearTimeout(timeoutId); let data = await res.json(); if (data.status === 'success') { failedPings = 0; setPS4State(true); } else { failedPings++; if (failedPings >= 2) setPS4State(false); } } catch(e) { failedPings++; if (failedPings >= 2) setPS4State(false); } }, 12000); }
        window.addEventListener('online', () => { const ipEl = document.getElementById('host-ip'); if(ipEl && ipEl.value) startConnectionMonitor(ipEl.value); });
        function clearIP() { if(isScanning) toggleRealScan(); document.getElementById('host-ip').value = ''; localStorage.removeItem('ps4_ip_guardada'); setPS4State(false); if(connectionMonitorInterval) clearInterval(connectionMonitorInterval); }
        function detenerUI() { isScanning = false; document.getElementById('host-ip').disabled = false; document.getElementById('global-status').classList.add('hidden'); clearInterval(radarAnimInterval); document.getElementById('btn-scan').innerHTML = '<i class="fa-solid fa-satellite-dish"></i>'; document.getElementById('btn-scan').className = 'w-12 h-12 rounded-xl bg-blue-600 hover:bg-blue-500 flex items-center justify-center text-white active:scale-95'; }
        
        async function toggleRealScan() { 
            if (isScanning) { if (abortController) abortController.abort(); detenerUI(); return; } 
            isScanning = true; document.getElementById('host-ip').value = ''; document.getElementById('host-ip').disabled = true; document.getElementById('global-status').classList.remove('hidden'); document.getElementById('btn-scan').className = 'w-12 h-12 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-[0_0_15px_rgba(239,68,68,0.4)] animate-pulse'; document.getElementById('btn-scan').innerHTML = '<i class="fa-solid fa-stop"></i>';
            radarAnimInterval = setInterval(() => { document.getElementById('scan-text').innerText = `BUSCANDO IP: 192.168.${Math.random() < 0.5 ? '0' : '100'}.${Math.floor(Math.random() * 254) + 1}`; }, 30); 
            abortController = new AbortController(); const signal = abortController.signal; 
            try { 
                let subnets = ['192.168.0.', '192.168.100.', '192.168.1.']; 
                if (SUBRED_PHP && !subnets.includes(SUBRED_PHP) && SUBRED_PHP.startsWith('192')) subnets.unshift(SUBRED_PHP); 
                
                let ipsToScan = []; 
                for(let s of subnets) { for(let i = 10; i <= 40; i++) ipsToScan.push(s + i); }
                for(let s of subnets) { for(let i = 2; i < 10; i++) ipsToScan.push(s + i); }
                for(let s of subnets) { for(let i = 41; i < 255; i++) ipsToScan.push(s + i); }
                
                const BATCH_SIZE = 4; 
                let foundIp = null; 
                for (let i = 0; i < ipsToScan.length; i += BATCH_SIZE) { 
                    if (signal.aborted) break; 
                    const batch = ipsToScan.slice(i, i + BATCH_SIZE); 
                    const promises = batch.map(ip => {
                        const pingController = new AbortController();
                        const id = setTimeout(() => pingController.abort(), 3000); 
                        return fetch(`api/scanner.php?ip=${ip}`, { signal: pingController.signal })
                            .then(res => { clearTimeout(id); return res.json(); })
                            .then(data => { if (data.status === 'success') throw data; return null; })
                            .catch(err => { clearTimeout(id); if (err.status === 'success') return err.ip; return null; });
                    }); 
                    try { const results = await Promise.all(promises); const winner = results.find(res => res !== null); if (winner) { foundIp = winner; break; } } catch(e) {} 
                } 
                if (foundIp) { detenerUI(); document.getElementById('host-ip').value = foundIp; localStorage.setItem('ps4_ip_guardada', foundIp); setPS4State(true); startConnectionMonitor(foundIp); AudioEngine.playSuccess(); ps5Notification(t('j_succ'), "Enlace establecido.", "fa-gamepad"); } else if (!signal.aborted) { detenerUI(); await ps5Alert(t('j_scan_fail'), t('j_scan_fail_m'), 'fa-satellite-dish'); } 
            } catch (e) { detenerUI(); } 
        }

        function connectManualIP() { const ip = document.getElementById('host-ip').value.trim(); if(ip) { localStorage.setItem('ps4_ip_guardada', ip); setPS4State(true); startConnectionMonitor(ip); ps5Notification(t('j_succ'), "IP Manual enlazada.", "fa-gamepad"); } }

        // ==========================================
        // 10. INICIALIZADOR GENERAL
        // ==========================================
        document.addEventListener('DOMContentLoaded', () => {
            const notifToggle = document.getElementById('toggle_notifications');
            if (notifToggle) { let savedNotif = localStorage.getItem('ps4_ui_notif'); if (savedNotif !== null) notifToggle.checked = (savedNotif === 'true'); notifToggle.addEventListener('change', (e) => { localStorage.setItem('ps4_ui_notif', e.target.checked); if(e.target.checked) ps5Notification("SISTEMA", "Notificaciones encendidas.", "fa-message"); }); }
            document.querySelectorAll('.dock-item').forEach(btn => { btn.addEventListener('click', function(e) { let ripple = document.createElement('div'); ripple.className = 'dock-ripple'; this.appendChild(ripple); setTimeout(() => ripple.remove(), 500); }); });
            if(localStorage.getItem('ps4_custom_username')) customUserName = localStorage.getItem('ps4_custom_username');
            const savedIp = localStorage.getItem('ps4_ip_guardada');
            if(savedIp) { document.getElementById('host-ip').value = savedIp; setPS4State(true); startConnectionMonitor(savedIp); }
            const savedFolders = JSON.parse(localStorage.getItem('ps4_custom_folders')) || [];
            savedFolders.forEach(folder => crearBotonCarpeta(folder, false));
            renderShortcuts(); actualizarGaleria(); actualizarPayloads(); renderCategorias(); cargarBibliotecaLocal(); 
            
            // Cargar estado de sonido desde localstorage y Anti-Robo check
            AudioEngine.loadSettings();
            if(!document.querySelector('.footer-sig')) { console.warn(atob('QWR2ZXJ0ZW5jaWEgZGUgU2VndXJpZGFk')); }
        });
    </script>
</body>
</html>